﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public class DrawingAndDisplay
    {
        const int MAXheightCard = 276;
        const int MAXwidthCard = 155;
        const int panelTopHeight = 50;
        const double XtoYcardProportion = (double)MAXwidthCard / (double)MAXheightCard;
        const double YtoXcardProportion = (double)MAXheightCard / (double)MAXwidthCard;
        const double cardToSpaceProportionY = 0.8;
        const double cardToSpaceProportionX = 0.85;
        List<MyRectangle> scoutPositions = new List<MyRectangle>();
        List<Scout> printedScouts = new List<Scout>();
        Scout blankScout = new Scout("");
        bool isPatrolMasterBlank = false;
        bool isPatrolHelperBlank = false;
        

        //print settings
        bool drawPath = true;
        bool drawShadow = true;
        bool drawImage = true;
        Color[] pathColor = {Color.DarkBlue, Color.DarkGreen, Color.Brown, Color.RosyBrown};
        Color[] shadowColor = { Color.DarkBlue, Color.DarkGreen, Color.Brown, Color.RosyBrown, Color.DarkGray, Color.Gray };
        bool[] pathLayer = {true, true, true, true};
        bool[] shadowLayer = { true, true, true, true, true, true };
        bool ignoreFirstLayerLine = false;
        bool useOptimalRegion = true;
        bool useOptimalCardSize = true;
        int shadowMargin = 4;
        int pathWidth = 2;
        const int warningMargin = 4;

        //card images containers
        PictureBox Card1 = new PictureBox();
        PictureBox Card2 = new PictureBox();
        PictureBox Card3i = new PictureBox();
        PictureBox Card3r = new PictureBox();
        PictureBox Card4i = new PictureBox();
        PictureBox Card4r = new PictureBox();
        PictureBox Card5i = new PictureBox();
        PictureBox Card5r = new PictureBox();

        public DrawingAndDisplay()
        {
            blankScout.stage = 6;
            blankScout.isPatrolHelper = true;
        }

        public void setDeckImage(Image c1, Image c2, Image c3i, Image c3r, Image c4i, Image c4r, Image c5i, Image c5r)
        {
            Card1.BackgroundImage = c1;
            Card2.BackgroundImage = c2;
            Card3i.BackgroundImage = c3i;
            Card3r.BackgroundImage = c3r;
            Card4i.BackgroundImage = c4i;
            Card4r.BackgroundImage = c4r;
            Card5i.BackgroundImage = c5i;
            Card5r.BackgroundImage = c5r;
        }

        bool patrolMasterHelperTest(int num)
        {
            bool test = true;
            switch (num)
            {
                case 2:
                    if (isPatrolMasterBlank) test = false;
                    break;
                case 3:
                    if (isPatrolHelperBlank) test = false;
                    break;
                default:
                    test = true;
                    break;
            }
            return test;
        }

        void checkIfPatrolMHblank(ScoutTroop sp)
        {
            if (sp.PatrolMasters.Count() > 0) isPatrolMasterBlank = false;
            else isPatrolMasterBlank = true;

            if (sp.PatrolHelpers.Count() > 0) isPatrolHelperBlank = false;
            else isPatrolHelperBlank = true;
        }

        void setCardSize(out int width, out int height, int spaceWidth, int spaceHeight, int columns, int rows)
        {
            height = (int)(spaceHeight / rows * cardToSpaceProportionY);
            width = (int)(height * XtoYcardProportion);

            if (width - 2*warningMargin > spaceWidth / columns)
            {
                width = (int)(spaceWidth / columns * cardToSpaceProportionX);
                height = (int)(width * YtoXcardProportion);
            }

            if (height > MAXheightCard || width > MAXwidthCard)
            {
                height = MAXheightCard;
                width = MAXwidthCard;
            }
        }

        void optimalCardSize(out int width, out int height, int spaceWidth, int spaceHeight, out int columns, out int rows, int howMany)
        {
            MyRectangle rec = new MyRectangle(0, 0, spaceWidth, spaceHeight);
            rows = findHowManyRows(rec, howMany);
            columns = howMany / rows;
            if (howMany % rows > 0) columns++;
            setCardSize(out width, out height, spaceWidth, spaceHeight, columns, rows);
        }

        void setCardSizeWithChoice(out int width, out int height, int spaceWidth, int spaceHeight, ref int columns, ref int rows, int howMany)
        {
            if (useOptimalCardSize == true)
            {
                optimalCardSize(out width, out height, spaceWidth, spaceHeight, out columns, out rows, howMany);
            }
            else
            {
                setCardSize(out width, out height, spaceWidth, spaceHeight, columns, rows);
            }
        }

    void findSpace3D(ScoutTroop scoutTroop, MyRectangle[] rectLayer, int howManyFreeSouls, out MyRectangle[,,] space3D, out int[,] scoutsInSpace3D)
        {
            int howManyPatrols = scoutTroop.Patrols.Count();
            int arraySize = howManyPatrols;
            if (arraySize < 1) arraySize = 1;
            /// <summary>
            ///[0,,] - space for boss
            ///[1,,] - space for Adjutant
            ///[2,,] - space for PatrolMasters
            ///[3,,] - space for PatrolHelpers
            ///[4,,] - space for Patrol members
            ///[5,,] - space for other scouts
            /// </summary>
            space3D = new MyRectangle[6, arraySize, 300];
            /// <summary>
            ///[layer (function), patrol] contains information how many scouts of this type will be printed on this layer
            /// </summary>
            scoutsInSpace3D = new int[6, arraySize];
            MyRectangle r = new MyRectangle();
            int heightCardBoss;
            int widthCardBoss;
            int spaceHeightBoss;
            int spaceWidthBoss;

            //boss card size
            spaceHeightBoss = rectLayer[0].leftDown.Y - rectLayer[0].leftHigh.Y;
            spaceWidthBoss = rectLayer[0].rightHigh.X - rectLayer[0].leftHigh.X;
            int rowsBoss = 1;
            int columsBoss = 1;
            setCardSizeWithChoice(out widthCardBoss, out heightCardBoss, spaceWidthBoss, spaceHeightBoss, ref rowsBoss, ref columsBoss, 1);
            MyTest.proportionTest(XtoYcardProportion, widthCardBoss, heightCardBoss);

            //boss card position
            r.leftHigh.X = rectLayer[0].leftHigh.X + (spaceWidthBoss - widthCardBoss) / 2;
            r.leftHigh.Y = rectLayer[0].leftHigh.Y + (spaceHeightBoss - heightCardBoss) / 2;
            r.rightDown.X = r.leftHigh.X + widthCardBoss;
            r.rightDown.Y = r.leftHigh.Y + heightCardBoss;
            //save
            space3D[0, 0, 0] = new MyRectangle(r);
            scoutsInSpace3D[0, 0] = 1;
            MyTest.fastConsoleWrite("położenie drużynowego (LH.X LH.Y RD.X RD.Y): " + r.leftHigh.X + " " + r.leftHigh.Y + " " + r.rightDown.X + " " + r.rightDown.Y);

            //*************************************************************
            if (scoutTroop.Adjutants.Count() > 0)
            {
                //Adjutant card size
                //first check how many rows
                int spaceHeightAdjutant;
                int spaceWidthAdjutant;
                int heightCardAdjutant;
                int widthCardAdjutant;
                int rowsAdjutant;
                int howManyAdjutants;
                int columnsAdjutants;
                int interspaceXAdjutants;
                int interspaceYAdjutants;
                //similar metod to boss size
                spaceHeightAdjutant = rectLayer[1].leftDown.Y - rectLayer[1].leftHigh.Y;
                spaceWidthAdjutant = rectLayer[1].rightHigh.X - rectLayer[1].leftHigh.X;

                //boss height is the smallest
                rowsAdjutant = spaceHeightAdjutant / spaceHeightBoss;
                if (rowsAdjutant == 0) rowsAdjutant = 1;

                //now we have to find how many adjutants in one row (how many spaces for columns)
                howManyAdjutants = scoutTroop.Adjutants.Count();
                columnsAdjutants = howManyAdjutants / rowsAdjutant;
                if (howManyAdjutants % rowsAdjutant != 0) columnsAdjutants++;
                //We have everything to set Adjutant card size!
                setCardSizeWithChoice(out widthCardAdjutant, out heightCardAdjutant, spaceWidthAdjutant, spaceHeightAdjutant, ref columnsAdjutants, ref rowsAdjutant, howManyAdjutants);
                //some other numbers... (constant spaces)
                interspaceXAdjutants = (spaceWidthAdjutant - columnsAdjutants * widthCardAdjutant) / (columnsAdjutants + 1) + widthCardAdjutant;
                interspaceYAdjutants = (spaceHeightAdjutant - rowsAdjutant * heightCardAdjutant) / (rowsAdjutant + 1) + heightCardAdjutant;
                //now is what the tigers like the best
                //just fill the table

                //start position
                r.leftHigh.Y = rectLayer[1].leftHigh.Y + interspaceYAdjutants - heightCardAdjutant;
                r.rightDown.Y = rectLayer[1].leftHigh.Y + interspaceYAdjutants;
                r.leftHigh.X = rectLayer[1].leftHigh.X + interspaceXAdjutants - widthCardAdjutant;
                r.rightDown.X = rectLayer[1].leftHigh.X + interspaceXAdjutants;
                for (int i = 0; i < rowsAdjutant; i++)
                {
                    for (int j = 0; j < columnsAdjutants && j + i * columnsAdjutants < howManyAdjutants; j++)
                    {
                        //save
                        space3D[1, 0, j + i * columnsAdjutants] = new MyRectangle(r);
                        r.leftHigh.X += interspaceXAdjutants;
                        r.rightDown.X += interspaceXAdjutants;
                    }

                    r.leftHigh.Y += interspaceYAdjutants;
                    r.rightDown.Y += interspaceYAdjutants;
                    r.leftHigh.X = rectLayer[1].leftHigh.X + interspaceXAdjutants - widthCardAdjutant;
                    r.rightDown.X = rectLayer[1].leftHigh.X + interspaceXAdjutants;
                }
                scoutsInSpace3D[1, 0] = howManyAdjutants;
            }
            else
                scoutsInSpace3D[1, 0] = 0;

            //*************************************************************
            //Foreach patrol...
            for (int patrolNum = 0; patrolNum < howManyPatrols; patrolNum++)
            {
                //PatrolMaster

                //PatrolMaster card size
                int spaceHeightPatrolMaster = rectLayer[2].leftDown.Y - rectLayer[2].leftHigh.Y;
                int spaceWidthPatrolMaster = (rectLayer[2].rightHigh.X - rectLayer[2].leftHigh.X) / howManyPatrols;
                int widthCardPatrolMaster;
                int heightCardPatrolMaster;
                int rowsPatrolMaster = 1;
                int columnsPatrolMaster = 1;
                setCardSizeWithChoice(out widthCardPatrolMaster, out heightCardPatrolMaster, spaceWidthPatrolMaster, spaceHeightPatrolMaster, ref rowsPatrolMaster, ref columnsPatrolMaster, 1);
                //PatrolMaster card position
                r.leftHigh.X = rectLayer[2].leftHigh.X + (spaceWidthPatrolMaster - widthCardPatrolMaster) / 2 + patrolNum * spaceWidthPatrolMaster;
                r.leftHigh.Y = rectLayer[2].leftHigh.Y + (spaceHeightPatrolMaster - heightCardPatrolMaster) / 2;
                r.rightDown.X = r.leftHigh.X + widthCardPatrolMaster;
                r.rightDown.Y = r.leftHigh.Y + heightCardPatrolMaster;
                //save
                space3D[2, patrolNum, 0] = new MyRectangle(r);
                scoutsInSpace3D[2, patrolNum] = 1;

                //PatrolHelper (easy, because it looks the same)
                r.leftHigh.Y += spaceHeightPatrolMaster;
                r.rightDown.Y += spaceHeightPatrolMaster;
                //save
                space3D[3, patrolNum, 0] = new MyRectangle(r);
                scoutsInSpace3D[3, patrolNum] = 1;



                //*************************************************************
                int howManyPatrolMembersInThis = scoutTroop.Patrols[patrolNum].Members.Count();
                if (scoutTroop.Patrols[patrolNum].patrolMaster != null) howManyPatrolMembersInThis--;
                if (scoutTroop.Patrols[patrolNum].patrolHelper != null) howManyPatrolMembersInThis--;
                if (howManyPatrolMembersInThis > 0)
                {
                    //PatrolMembers card size
                    //first check how many rows
                    int spaceHeightPatrolMembers;
                    int spaceWidthPatrolMembers;
                    int heightCardPatrolMembers;
                    int widthCardPatrolMembers;
                    int rowsPatrolMembers;
                    int columnsPatrolMembers;
                    int interspaceXPatrolMembers;
                    int interspaceYPatrolMembers;
                    //similar metod to boss size
                    spaceHeightPatrolMembers = rectLayer[4].leftDown.Y - rectLayer[4].leftHigh.Y;
                    spaceWidthPatrolMembers = spaceWidthPatrolMaster; //because it's the same patrol

                    //boss height is the smallest
                    rowsPatrolMembers = spaceHeightPatrolMembers / spaceHeightBoss;
                    if (rowsPatrolMembers == 0) rowsPatrolMembers = 1;

                    //now we have to find how many patrol members in one row (how many spaces for columns)
                    //IT'S DIFFERENT FOR EACH PATROL!   
                    columnsPatrolMembers = howManyPatrolMembersInThis / rowsPatrolMembers;
                    if (howManyPatrolMembersInThis % rowsPatrolMembers != 0) columnsPatrolMembers++;
                    //We have everything to set Patrol card size!
                    setCardSizeWithChoice(out widthCardPatrolMembers, out heightCardPatrolMembers, spaceWidthPatrolMembers, spaceHeightPatrolMembers, ref columnsPatrolMembers, ref rowsPatrolMembers, howManyPatrolMembersInThis);
                    //some other numbers... (constant spaces)
                    interspaceXPatrolMembers = (spaceWidthPatrolMembers - columnsPatrolMembers * widthCardPatrolMembers) / (columnsPatrolMembers + 1) + widthCardPatrolMembers;
                    interspaceYPatrolMembers = (spaceHeightPatrolMembers - rowsPatrolMembers * heightCardPatrolMembers) / (rowsPatrolMembers + 1) + heightCardPatrolMembers;
                    //now is what the tigers like the best
                    //just fill the table

                    //start position
                    r.leftHigh.Y = rectLayer[4].leftHigh.Y + interspaceYPatrolMembers - heightCardPatrolMembers;
                    r.rightDown.Y = rectLayer[4].leftHigh.Y + interspaceYPatrolMembers;
                    r.leftHigh.X = rectLayer[4].leftHigh.X + interspaceXPatrolMembers - widthCardPatrolMembers + patrolNum * spaceWidthPatrolMembers;
                    r.rightDown.X = rectLayer[4].leftHigh.X + interspaceXPatrolMembers + patrolNum * spaceWidthPatrolMembers;
                    for (int i = 0; i < rowsPatrolMembers; i++)
                    {
                        for (int j = 0; j < columnsPatrolMembers && j + i * columnsPatrolMembers < howManyPatrolMembersInThis; j++)
                        {
                            //save
                            space3D[4, patrolNum, j + i * columnsPatrolMembers] = new MyRectangle(r);
                            r.leftHigh.X += interspaceXPatrolMembers;
                            r.rightDown.X += interspaceXPatrolMembers;
                        }

                        r.leftHigh.Y += interspaceYPatrolMembers;
                        r.rightDown.Y += interspaceYPatrolMembers;
                        r.leftHigh.X = rectLayer[4].leftHigh.X + interspaceXPatrolMembers - widthCardPatrolMembers + patrolNum * spaceWidthPatrolMembers;
                        r.rightDown.X = rectLayer[4].leftHigh.X + interspaceXPatrolMembers + patrolNum * spaceWidthPatrolMembers;
                    }
                    scoutsInSpace3D[4, patrolNum] = howManyPatrolMembersInThis;
                }
                else
                    scoutsInSpace3D[4, patrolNum] = 0;

            }


            //*************************************************************
            MyTest.fastConsoleWrite("Tyle jest Free Souls: " + howManyFreeSouls);
            if (howManyFreeSouls > 0)
            {
                //FreeSoul card size
                //first check how many rows
                int spaceHeightFreeSouls;
                int spaceWidthFreeSouls;
                int heightCardFreeSouls;
                int widthCardFreeSouls;
                int rowsFreeSouls;
                int columnsFreeSouls;
                int interspaceXFreeSouls;
                int interspaceYFreeSouls;
                //similar metod to boss size
                spaceHeightFreeSouls = rectLayer[5].leftDown.Y - rectLayer[5].leftHigh.Y;
                spaceWidthFreeSouls = rectLayer[5].rightHigh.X - rectLayer[5].leftHigh.X;

                //boss height is the smallest
                rowsFreeSouls = spaceHeightFreeSouls / spaceHeightBoss;
                if (rowsFreeSouls == 0) rowsFreeSouls = 1;

                //now we have to find how many FreeSouls in one row (how many spaces for columns)
                //We have howManyFreeSouls from second argument of this function
                columnsFreeSouls = howManyFreeSouls / rowsFreeSouls;
                if (howManyFreeSouls % rowsFreeSouls != 0) columnsFreeSouls++;
                //We have everything to set FreeSoul card size!
                setCardSizeWithChoice(out widthCardFreeSouls, out heightCardFreeSouls, spaceWidthFreeSouls, spaceHeightFreeSouls, ref columnsFreeSouls, ref rowsFreeSouls, howManyFreeSouls);
                //some other numbers... (constant spaces)
                interspaceXFreeSouls = (spaceWidthFreeSouls - columnsFreeSouls * widthCardFreeSouls) / (columnsFreeSouls + 1) + widthCardFreeSouls;
                interspaceYFreeSouls = (spaceHeightFreeSouls - rowsFreeSouls * heightCardFreeSouls) / (rowsFreeSouls + 1) + heightCardFreeSouls;
                //now is what the tigers like the best
                //just fill the table

                //start position
                r.leftHigh.Y = rectLayer[5].leftHigh.Y + interspaceYFreeSouls - heightCardFreeSouls;
                r.rightDown.Y = rectLayer[5].leftHigh.Y + interspaceYFreeSouls;
                r.leftHigh.X = rectLayer[5].leftHigh.X + interspaceXFreeSouls - widthCardFreeSouls;
                r.rightDown.X = rectLayer[5].leftHigh.X + interspaceXFreeSouls;
                for (int i = 0; i < rowsFreeSouls; i++)
                {
                    for (int j = 0; j < columnsFreeSouls && j + i * columnsFreeSouls < howManyFreeSouls; j++)
                    {
                        //save
                        space3D[5, 0, j + i * columnsFreeSouls] = new MyRectangle(r);
                        r.leftHigh.X += interspaceXFreeSouls;
                        r.rightDown.X += interspaceXFreeSouls;
                    }

                    r.leftHigh.Y += interspaceYFreeSouls;
                    r.rightDown.Y += interspaceYFreeSouls;
                    r.leftHigh.X = rectLayer[5].leftHigh.X + interspaceXFreeSouls - widthCardFreeSouls;
                    r.rightDown.X = rectLayer[5].leftHigh.X + interspaceXFreeSouls;
                }
                scoutsInSpace3D[5, 0] = howManyFreeSouls;
            }
            else
                scoutsInSpace3D[5, 0] = 0;
        }


        void drawOneCard(Panel panel, Scout s, Rectangle rec)
        {
            Graphics g = panel.CreateGraphics();
            MyTest.drawingPersonInfo(s, rec);

            if (drawShadow == true)
            {
                int colorIndex;
                if (s.isBoss) colorIndex = 0;
                else if (s.isAdjutant) colorIndex = 1;
                else if (s.isPatrolMaster) colorIndex = 2;
                else if (s.isPatrolHelper) colorIndex = 3;
                else if (s.isPatrolMember) colorIndex = 4;
                else colorIndex = 5;

                if (shadowLayer[colorIndex] && patrolMasterHelperTest(colorIndex))
                {
                    Rectangle shadow = new Rectangle(rec.X - shadowMargin, rec.Y - shadowMargin, rec.Width + 2 * shadowMargin, rec.Height + 2 * shadowMargin);
                    SolidBrush sb = new SolidBrush(shadowColor[colorIndex]);
                    g.FillRectangle(sb, shadow);
                }
            }

            if (drawImage == true)
            {
                switch (s.stage)
                {
                    case 1:
                        g.DrawImage(Card1.BackgroundImage, rec);
                        break;
                    case 2:
                        g.DrawImage(Card2.BackgroundImage, rec);
                        break;
                    case 3:
                        if (s.isInstructor)
                            g.DrawImage(Card3i.BackgroundImage, rec);
                        else
                            g.DrawImage(Card3r.BackgroundImage, rec);
                        break;
                    case 4:
                        if (s.isInstructor)
                            g.DrawImage(Card4i.BackgroundImage, rec);
                        else
                            g.DrawImage(Card4r.BackgroundImage, rec);
                        break;
                    case 5:
                        if (s.isInstructor)
                            g.DrawImage(Card5i.BackgroundImage, rec);
                        else
                            g.DrawImage(Card5r.BackgroundImage, rec);
                        break;
                    default:
                        break;
                }
            }

            //save to position list
            scoutPositions.Add(new MyRectangle(rec));
            printedScouts.Add(s);
        }

        int findIndexLastFirstLine(MyRectangle[,,] space3D, int layer, int patrol, int scoutLimit)
        {
            int position = space3D[layer, patrol, 0].topMiddle.X;
            for (int i = 1; i < scoutLimit; i++)
            {
                if (space3D[layer, patrol, i].topMiddle.X <= position) return i - 1;
            }
            return 0;
        }

        int findIndexLastMabylastLine(MyRectangle[,,] space3D, int layer, int patrol, int scoutLimit)
        {
            int position = space3D[layer, patrol, scoutLimit - 1].topMiddle.X;
            for (int i = scoutLimit - 2; i >= 0 ; i--)
            {
                if (space3D[layer, patrol, i].topMiddle.X > position) return i;
            }
            return scoutLimit - 1;
        }

        void connectWithLabel(Graphics g, Pen p, int labelY, Point point)
        {
            Point labelPoint = new Point();
            labelPoint.Y = labelY;
            labelPoint.X = point.X;
            g.DrawLine(p, labelPoint, point);
        }

        void connectGroupWithTopLabel(Graphics g, Pen p, int labelY, MyRectangle[,,] space3D, int layer, int patrol, int howManyCon)
        {
            Point point;
            for (int i = 0; i < howManyCon; i++)
            {
                point = space3D[layer, patrol, i].topMiddle;
                connectWithLabel(g, p, labelY, point);
            }
        }

        void connectGroupWithBottomLabel(Graphics g, Pen p, int labelY, MyRectangle[,,] space3D, int layer, int patrol, int howManyCon)
        {
            Point point;
            for (int i = 0; i < howManyCon; i++)
            {
                point = space3D[layer, patrol, i].bottomMiddle;
                connectWithLabel(g, p, labelY, point);
            }
        }

        void connectPoints(Graphics g, Pen p, Point basePoint, Point point)
        {
            g.DrawLine(p, basePoint, point);
        }

        void connectGroupWithUpperBoss(Graphics g, Pen p, Point basePoint, MyRectangle[,,] space3D, int layer, int patrol, int howManyCon)
        {
            Point point;
            for (int i = 0; i < howManyCon; i++)
            {
                point = space3D[layer, patrol, i].topMiddle;
                connectPoints(g, p, basePoint, point);
            }
        }

        void connectGroupWithLowerBoss(Graphics g, Pen p, Point basePoint, MyRectangle[,,] space3D, int layer, int patrol, int howManyCon)
        {
            Point point;
            for (int i = 0; i < howManyCon; i++)
            {
                point = space3D[layer, patrol, i].bottomMiddle;
                connectPoints(g, p, basePoint, point);
            }
        }


        void pathPrint(Panel panel, MyRectangle[,,] space3D, int[,] scoutsIn3D, int howManyPatrols)
        {
            //Find Layer Lines
            bool[] isLayerLine = new bool[5];
            if (scoutsIn3D[0, 0] > 0) isLayerLine[0] = true;
            if (scoutsIn3D[1, 0] > 0) isLayerLine[1] = true;
            for (int i = 2; i < 5; i++)
            {
                //zeros for first
                isLayerLine[i] = false;
                for (int j = 0; j < howManyPatrols; j++)
                {
                    if (scoutsIn3D[i, j] > 0) isLayerLine[i] = true;
                }
            }
            if (!patrolMasterHelperTest(2)) isLayerLine[2] = false;
            if (!patrolMasterHelperTest(3)) isLayerLine[3] = false;


            Point[,] layerLine = new Point[2, 2];
            bool[] doesLineExist = {false, false};
          
            int index;
            if (isLayerLine[1] && scoutsIn3D[1,0] > 1)
            {
                //first line
                layerLine[0, 0].Y = (space3D[1, 0, 0].topMiddle.Y - space3D[0, 0, 0].bottomMiddle.Y)/2 + space3D[0, 0, 0].bottomMiddle.Y;
                layerLine[0, 1].Y = layerLine[0, 0].Y;
                layerLine[0, 0].X = space3D[1, 0, 0].topMiddle.X;
                index = findIndexLastFirstLine(space3D, 1, 0, scoutsIn3D[1,0]);
                layerLine[0, 1].X = space3D[1, 0, index].topMiddle.X;
                doesLineExist[0] = true;

                //second line
                if (isLayerLine[2] && howManyPatrols > 1)
                {
                    //index of last adjutant
                    index = findIndexLastMabylastLine(space3D, 1, 0, scoutsIn3D[1, 0]);
                    layerLine[1, 0].Y = (space3D[2, 0, 0].topMiddle.Y - space3D[1, 0, 0].bottomMiddle.Y) / 2 + space3D[1, 0, 0].bottomMiddle.Y;
                    layerLine[1, 1].Y = layerLine[1, 0].Y;

                    layerLine[1, 0].X = space3D[2, 0, 0].topMiddle.X;
                    layerLine[1, 1].X = space3D[2, howManyPatrols - 1, 0].topMiddle.X;

                    int X0 = space3D[1, 0, 0].topMiddle.X;
                    int X1 = space3D[1, 0, index].topMiddle.X;

                    if (X0 < layerLine[1, 0].X) layerLine[1, 0].X = X0;
                    if (X1 > layerLine[1, 1].X) layerLine[1, 1].X = X1;

                    doesLineExist[1] = true;
                }
                else if (isLayerLine[3] && howManyPatrols > 1)
                {
                    //index of last adjutant
                    index = findIndexLastMabylastLine(space3D, 1, 0, scoutsIn3D[1, 0]);
                    layerLine[1, 0].Y = (space3D[3, 0, 0].topMiddle.Y - space3D[1, 0, 0].bottomMiddle.Y) / 2 + space3D[1, 0, 0].bottomMiddle.Y;
                    layerLine[1, 1].Y = layerLine[1, 0].Y;

                    layerLine[1, 0].X = space3D[3, 0, 0].topMiddle.X;
                    layerLine[1, 1].X = space3D[3, howManyPatrols - 1, 0].topMiddle.X;

                    int X0 = space3D[1, 0, 0].topMiddle.X;
                    int X1 = space3D[1, 0, index].topMiddle.X;

                    if (X0 < layerLine[1, 0].X) layerLine[1, 0].X = X0;
                    if (X1 > layerLine[1, 1].X) layerLine[1, 1].X = X1;

                    doesLineExist[1] = true;
                }
            }
            else if (isLayerLine[2] && howManyPatrols > 1 && !isLayerLine[1])
            {
                //first and the only one line
                layerLine[0, 0].Y = (space3D[2, 0, 0].topMiddle.Y - space3D[0, 0, 0].bottomMiddle.Y) / 2 + space3D[0, 0, 0].bottomMiddle.Y;
                layerLine[0, 1].Y = layerLine[0, 0].Y;
                layerLine[0, 0].X = space3D[2, 0, 0].topMiddle.X;
                layerLine[0, 1].X = space3D[2, howManyPatrols - 1, 0].topMiddle.X;
                doesLineExist[0] = true;
            }
            else if (isLayerLine[3] && howManyPatrols > 1 && !isLayerLine[1])
            {
                //first and the only one line
                layerLine[0, 0].Y = (space3D[3, 0, 0].topMiddle.Y - space3D[0, 0, 0].bottomMiddle.Y) / 2 + space3D[0, 0, 0].bottomMiddle.Y;
                layerLine[0, 1].Y = layerLine[0, 0].Y;
                layerLine[0, 0].X = space3D[3, 0, 0].topMiddle.X;
                layerLine[0, 1].X = space3D[3, howManyPatrols - 1, 0].topMiddle.X;
                doesLineExist[0] = true;
            }
            else if (isLayerLine[1])
            {
                if (isLayerLine[2] && howManyPatrols > 1)
                {
                    layerLine[1, 0].Y = (space3D[2, 0, 0].topMiddle.Y - space3D[1, 0, 0].bottomMiddle.Y) / 2 + space3D[1, 0, 0].bottomMiddle.Y;
                    layerLine[1, 1].Y = layerLine[1, 0].Y;

                    layerLine[1, 0].X = space3D[2, 0, 0].topMiddle.X;
                    layerLine[1, 1].X = space3D[2, howManyPatrols - 1, 0].topMiddle.X;

                    doesLineExist[1] = true;
                }
                else if (isLayerLine[3] && howManyPatrols > 1)
                {
                    layerLine[1, 0].Y = (space3D[3, 0, 0].topMiddle.Y - space3D[1, 0, 0].bottomMiddle.Y) / 2 + space3D[1, 0, 0].bottomMiddle.Y;
                    layerLine[1, 1].Y = layerLine[1, 0].Y;

                    layerLine[1, 0].X = space3D[3, 0, 0].topMiddle.X;
                    layerLine[1, 1].X = space3D[3, howManyPatrols - 1, 0].topMiddle.X;

                    doesLineExist[1] = true;
                }
            }



            //START DRAWING
            Graphics g = panel.CreateGraphics();
            //boss path
            Pen p = new Pen(pathColor[0], pathWidth);
            if (pathLayer[0] == true)
            {
                if (doesLineExist[0] && ignoreFirstLayerLine == false)
                {
                    g.DrawLine(p, space3D[0, 0, 0].bottomMiddle.X, space3D[0, 0, 0].bottomMiddle.Y, space3D[0, 0, 0].bottomMiddle.X, layerLine[0, 0].Y);
                    g.DrawLine(p, layerLine[0, 0], layerLine[0, 1]);
                    if (isLayerLine[1])
                    {
                        int n = 1;
                        int howManyConnections = scoutsIn3D[n,0];
                        connectGroupWithTopLabel(g, p, layerLine[0,0].Y, space3D, n, 0, howManyConnections);
                    }
                    else if (isLayerLine[2])
                    {
                        int n = 2;
                        int howManyConnections;
                        for (int i = 0; i < howManyPatrols; i++)
                        {
                            howManyConnections = scoutsIn3D[n, i];
                            connectGroupWithTopLabel(g, p, layerLine[0, 0].Y, space3D, n, i, howManyConnections);
                        }
                    }
                    else if (isLayerLine[3])
                    {
                        int n = 3;
                        int howManyConnections;
                        for (int i = 0; i < howManyPatrols; i++)
                        {
                            howManyConnections = scoutsIn3D[n, i];
                            connectGroupWithTopLabel(g, p, layerLine[0, 0].Y, space3D, n, i, howManyConnections);
                        }
                    }
                }
                else
                {
                    if (isLayerLine[1])
                    {
                        int n = 1;
                        int howManyConnections = scoutsIn3D[n, 0];
                        connectGroupWithUpperBoss(g, p, space3D[0,0,0].bottomMiddle, space3D, n, 0, howManyConnections);
                    }
                    else if (isLayerLine[2])
                    {
                        int n = 2;
                        int howManyConnections;
                        for (int i = 0; i < howManyPatrols; i++)
                        {
                            howManyConnections = scoutsIn3D[n, i];
                            connectGroupWithUpperBoss(g, p, space3D[0, 0, 0].bottomMiddle, space3D, n, i, howManyConnections);
                        }
                    }
                    else if (isLayerLine[3])
                    {
                        int n = 3;
                        int howManyConnections;
                        for (int i = 0; i < howManyPatrols; i++)
                        {
                            howManyConnections = scoutsIn3D[n, i];
                            connectGroupWithUpperBoss(g, p, space3D[0, 0, 0].bottomMiddle, space3D, n, i, howManyConnections);
                        }
                    }
                    else if (isLayerLine[4])
                    {
                        Random rnd = new Random();
                        int n = 4;
                        for (int i = 0; i < howManyPatrols; i++)
                        {
                            Color randomColor = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));
                            p.Color = randomColor;
                            for (int j = 0; j < scoutsIn3D[4, i]; j++)
                            {
                                connectPoints(g, p, space3D[0, 0, 0].bottomMiddle, space3D[n, i, j].topMiddle);
                            }
                        }
                    }
                }
            }
            //********************************************************************
            //Adjutant Path
            p.Color = pathColor[1];
            if (pathLayer[1] == true && isLayerLine[1])
            {
                if (doesLineExist[1])
                {
                    connectGroupWithBottomLabel(g, p, layerLine[1, 0].Y, space3D, 1, 0, scoutsIn3D[1,0]);
                    g.DrawLine(p, layerLine[1, 0], layerLine[1, 1]);
                    if (isLayerLine[2])
                    {
                        int n = 2;
                        int howManyConnections;
                        for (int i = 0; i < howManyPatrols; i++)
                        {
                            howManyConnections = scoutsIn3D[n, i];
                            connectGroupWithTopLabel(g, p, layerLine[1, 0].Y, space3D, n, i, howManyConnections);
                        }
                    }
                    else if (isLayerLine[3])
                    {
                        int n = 3;
                        int howManyConnections;
                        for (int i = 0; i < howManyPatrols; i++)
                        {
                            howManyConnections = scoutsIn3D[n, i];
                            connectGroupWithTopLabel(g, p, layerLine[0, 0].Y, space3D, n, i, howManyConnections);
                        }
                    }
                }
                else if (isLayerLine[2])
                {
                    connectPoints(g, p, space3D[1, 0, 0].bottomMiddle, space3D[2, 0, 0].topMiddle);
                }
                else if (isLayerLine[3])
                {
                    connectPoints(g, p, space3D[1, 0, 0].bottomMiddle, space3D[3, 0, 0].topMiddle);
                }
                else if (isLayerLine[4])
                {
                    int n = 4;
                    for (int i = 0; i < howManyPatrols; i++)
                    {
                        for (int j = 0; j < scoutsIn3D[4, i]; j++)
                        {
                            connectPoints(g, p, space3D[1, 0, 0].bottomMiddle, space3D[n, i, j].topMiddle);
                        }
                    }
                }
            }
            //********************************************************************
            //Patrol Master Path
            p.Color = pathColor[2];
            if (pathLayer[2] == true && isLayerLine[2])
            {
                if (isLayerLine[3])
                {
                    int n = 3;
                    int howManyConnections;
                    for (int i = 0; i < howManyPatrols; i++)
                    {
                        howManyConnections = scoutsIn3D[n, i];
                        connectGroupWithUpperBoss(g, p, space3D[2, i, 0].bottomMiddle, space3D, n, i, howManyConnections);
                    }
                }
                else if (isLayerLine[4])
                {
                    int n = 4;
                    for (int i = 0; i < howManyPatrols; i++)
                    {
                        for (int j = 0; j < scoutsIn3D[4, i]; j++)
                        {
                            connectPoints(g, p, space3D[2, i, 0].bottomMiddle, space3D[n, i, j].topMiddle);
                        }
                    }
                }
            }
            //********************************************************************
            //Patrol Helper Path
            p.Color = pathColor[3];
            if (pathLayer[3] == true && isLayerLine[3])
            {
                if (isLayerLine[4])
                {
                    int n = 4;
                    for (int i = 0; i < howManyPatrols; i++)
                    {
                        for (int j = 0; j < scoutsIn3D[4, i]; j++)
                        {
                            connectPoints(g, p, space3D[3, i, 0].bottomMiddle, space3D[n, i, j].topMiddle);
                        }
                    }
                }
            }

        }
        
        void findBest(int h, out int g, double a, int b, int c, double f, int d, out int x, out int y)
        {
            int e = (int)Math.Ceiling((double)h / (double)d);
            y = (int)Math.Floor((double)b * f / (double)d);
            x = (int)Math.Floor((double)y / a);
            int z = (int)Math.Floor(((double)b / (double)d - y) / 2);
            g = (int)Math.Floor((double)((double)c - e * x) / (double)(e + 1));

            setCardSize(out x, out y, c, b, e, d);
        }

        int OptimalWidth(int h, int g, double a, int b, int c, double f)
        {
            return (int)((-(h * g * a) + Math.Sqrt(Math.Pow(h * g * a, 2) - 4 * h * a * (g * b * f - c * b * f))) / (2 * h * a));
        }

        int findHowManyRows(MyRectangle space, int howManyOnLayer)
        {
            if (howManyOnLayer < 1) return 0;

            int spaceOX = warningMargin;
            int widthCard = OptimalWidth(howManyOnLayer, spaceOX, YtoXcardProportion, space.drawRec.Height, space.drawRec.Width, cardToSpaceProportionY);
            int heightCard;
            int spaceOY = (int)((YtoXcardProportion * widthCard - YtoXcardProportion * cardToSpaceProportionY * widthCard) / (2 * cardToSpaceProportionY));

            int d1 = (int)Math.Floor(space.drawRec.Height / (2 * spaceOY + YtoXcardProportion * widthCard));
            int d2 = (int)Math.Ceiling(space.drawRec.Height / (2 * spaceOY + YtoXcardProportion * widthCard));

            int widthCard2;
            int heightCard2;

            if (d1 >= 1)
                findBest(howManyOnLayer, out spaceOX, YtoXcardProportion, space.drawRec.Height, space.drawRec.Width, cardToSpaceProportionY, d1, out widthCard, out heightCard);
            else widthCard = 0;

            if (d2 >= 1)
                findBest(howManyOnLayer, out spaceOX, YtoXcardProportion, space.drawRec.Height, space.drawRec.Width, cardToSpaceProportionY, d2, out widthCard2, out heightCard2);
            else widthCard2 = 0;

            if (widthCard > widthCard2) return d1;
            else return d2;
        }

        void findNewRegion(ref MyRectangle[] space, int[] howManyOnLayer, int heightEff)
        {
            int[] rowsTab = new int[6];
            rowsTab[0] = 1;
            rowsTab[1] = findHowManyRows(space[1], howManyOnLayer[1]);
            if (howManyOnLayer[2] > 0) rowsTab[2] = 1;
            else rowsTab[2] = 0;
            if (howManyOnLayer[3] > 0) rowsTab[3] = 1;
            else rowsTab[3] = 0;
            rowsTab[4] = findHowManyRows(space[4], howManyOnLayer[4]);
            rowsTab[5] = findHowManyRows(space[5], howManyOnLayer[5]);

            int sumRows = 0;
            foreach (int r in rowsTab)
                sumRows += r;


            int panelWidth = space[0].rightHigh.X - space[0].leftHigh.X;
            Point[] bufPoints = new Point[4];
            Point panelStartVertex = space[0].leftHigh;
            //line down - Must have!
            bufPoints[1] = panelStartVertex;
            for (int i = 0; i < 6; i++)
            {
                bufPoints[0] = bufPoints[1];
                bufPoints[1].X = bufPoints[0].X;
                bufPoints[1].Y = bufPoints[0].Y + (heightEff * rowsTab[i] / sumRows);
                bufPoints[2].X = bufPoints[1].X + panelWidth;
                bufPoints[2].Y = bufPoints[1].Y;
                bufPoints[3].X = bufPoints[2].X;
                bufPoints[3].Y = bufPoints[0].Y;

                space[i] = new MyRectangle(bufPoints[0], bufPoints[1], bufPoints[2], bufPoints[3]);
            }
        }
        
        public void drawScoutTroop(Panel panel, ScoutTroop scoutTroop)
        {
            checkIfPatrolMHblank(scoutTroop);

            scoutPositions.Clear();
            printedScouts.Clear();

            /// <summary>
            ///0 - space for boss
            ///1 - space for Adjutant
            ///2 - space for PatrolMasters
            ///3 - space for PatrolHelpers
            ///4 - space for Patrol members
            ///5 - space for other scouts
            /// </summary>
            MyRectangle[] space = new MyRectangle[6];

            bool areAnyAdjutants = false;
            bool areAnyPatrolMasters = false;
            bool areAnyPatrolHelpers = false;
            bool areAnyPatrolMembers = false;
            bool areAnyFreeSouls = false;

            int howManyPatrolMembers = 0;
            int howManyFreeSouls = 0;

            if (scoutTroop.Adjutants.Count() > 0) areAnyAdjutants = true;
            if (scoutTroop.PatrolMasters.Count() > 0) areAnyPatrolMasters = true;
            if (scoutTroop.PatrolHelpers.Count() > 0) areAnyPatrolHelpers = true;
            //search in Patrols
            foreach (Patrol p in scoutTroop.Patrols)
            {
                foreach (Scout s in p.Members)
                {
                    if (s != p.patrolMaster && s != p.patrolHelper)
                    {
                        areAnyPatrolMembers = true;
                        howManyPatrolMembers++;
                    }
                }
            }
            //searchFreeSouls...
            foreach (Scout s in scoutTroop.Members)
            {
                if (!s.isBoss && !s.isAdjutant && !s.isPatrolMaster && !s.isPatrolHelper && !s.isPatrolMember)
                {
                    areAnyFreeSouls = true;
                    howManyFreeSouls++;
                }
            }

            //Counting Layers
            int rowMax;
            int layers = 1;
            if (areAnyAdjutants) layers++;
            if (areAnyPatrolMasters) layers++;
            if (areAnyPatrolHelpers) layers++;
            if (areAnyPatrolMembers) layers++;
            if (areAnyFreeSouls) layers++;

            switch (layers)
            {
                case 1:
                    rowMax = 10;
                    break;
                case 2:
                    rowMax = 10;
                    break;
                case 3:
                    rowMax = 15;
                    break;
                case 4:
                    rowMax = 15;
                    break;
                case 5:
                    rowMax = 15;
                    break;
                case 6:
                    rowMax = 30;
                    break;
                default:
                    rowMax = 10;
                    break;
            }

            /// <summary>
            ///giving size points (scaling areas)
            ///the same index like rectangle array
            /// </summary>
            int[] sizePoints = new int[6];

            //clear
            for (int i = 1; i < 6; i++)
                sizePoints[i] = 0;

            sizePoints[0] = 1;
            if (areAnyAdjutants) sizePoints[1] = scoutTroop.Adjutants.Count() / (rowMax + 1) + 1;
            if (areAnyPatrolMasters) sizePoints[2] = 1;
            if (areAnyPatrolHelpers) sizePoints[3] = 1;
            if (areAnyPatrolMembers) sizePoints[4] = howManyPatrolMembers / (rowMax + 1) + 1;
            if (areAnyFreeSouls) sizePoints[5] = howManyFreeSouls / (rowMax + 1) + 1;

            //sum of SizePoints (sum scales od height)
            int sumSizePoints = 0;
            foreach (int i in sizePoints)
                sumSizePoints += i;

            //Dividing Form1 Panel Main by proportion
            Point panelStartVertex = new Point(0, panelTopHeight);
            Point[] bufPoints = new Point[4];
            int heightEff = panel.Height - panelTopHeight;

            //line down - Must have!
            bufPoints[1] = panelStartVertex;
            for (int i = 0; i < 6; i++)
            {
                bufPoints[0] = bufPoints[1];
                bufPoints[1].X = bufPoints[0].X;
                bufPoints[1].Y = bufPoints[0].Y + (heightEff * sizePoints[i] / sumSizePoints);
                bufPoints[2].X = bufPoints[1].X + panel.Width;
                bufPoints[2].Y = bufPoints[1].Y;
                bufPoints[3].X = bufPoints[2].X;
                bufPoints[3].Y = bufPoints[0].Y;

                space[i] = new MyRectangle(bufPoints[0], bufPoints[1], bufPoints[2], bufPoints[3]);
            }

            if (useOptimalRegion)
            {
                int[] howManyOnLayer = { 1, scoutTroop.Adjutants.Count(), scoutTroop.PatrolMasters.Count(), scoutTroop.PatrolHelpers.Count(), howManyPatrolMembers, howManyFreeSouls };
                findNewRegion(ref space, howManyOnLayer, heightEff);
            }

            MyTest.fastConsoleWrite("wysokość panelu: " + panel.Height + " szerokość panelu: " + panel.Width);
            MyTest.layerTest(space);
            MyTest.classCardTest( areAnyAdjutants, areAnyPatrolMasters, areAnyPatrolHelpers, areAnyPatrolMembers, areAnyFreeSouls);

            MyRectangle[,,] space3D;
            int[,] scoutsInSpace3D;
            findSpace3D(scoutTroop ,space, howManyFreeSouls, out space3D, out scoutsInSpace3D);

            //Clear Panel
            Graphics g = panel.CreateGraphics();
            g.Clear(panel.BackColor);

            //Path Print
            if (drawPath)
            pathPrint(panel, space3D, scoutsInSpace3D, scoutTroop.Patrols.Count());

            //boss print
            drawOneCard(panel, scoutTroop.Members[0], space3D[0, 0, 0].drawRec);
            //Adjutants print
            int limit = scoutsInSpace3D[1, 0];
            for (int i = 0; i < limit; i++)
            {
                drawOneCard(panel, scoutTroop.Adjutants[i], space3D[1, 0, i].drawRec);
            }

            //PatrolMembers, PatrolMasters and PatrolHelpers print
            int howManyPatrols = scoutTroop.Patrols.Count();
            for (int i = 0; i < howManyPatrols; i++)
            {
                limit = scoutsInSpace3D[4, i];
                //Print PatrolMasters
                if (scoutTroop.Patrols[i].patrolMaster != null)
                {
                    drawOneCard(panel, scoutTroop.PatrolMasters[i], space3D[2, i, 0].drawRec);
                }
                else
                {
                    drawOneCard(panel, blankScout, space3D[2, i, 0].drawRec);
                }
                //Print PatrolHelpers
                if (scoutTroop.Patrols[i].patrolHelper != null)
                {
                    drawOneCard(panel, scoutTroop.PatrolHelpers[i], space3D[3, i, 0].drawRec);
                }
                else
                {
                    drawOneCard(panel, blankScout, space3D[3, i, 0].drawRec);
                }
                //Print Patrol Members
                for (int j = 0; j < limit; j++)
                {
                    if (scoutTroop.Patrols[i].Members[j] != scoutTroop.Patrols[i].patrolMaster && scoutTroop.Patrols[i].Members[j] != scoutTroop.Patrols[i].patrolHelper)
                        drawOneCard(panel, scoutTroop.Patrols[i].Members[j], space3D[4, i, j].drawRec);
                }
            }
            //FreeSouls print
            limit = scoutsInSpace3D[5, 0];
            int othersCounter = 0;
            for (int i = 0; i < limit + othersCounter; i++)
            {
                Scout s = scoutTroop.Members[i];
                if (!s.isBoss && !s.isAdjutant && !s.isPatrolMaster && !s.isPatrolHelper && !s.isPatrolMember)
                {
                    drawOneCard(panel, s, space3D[5, 0, i - othersCounter].drawRec);
                }
                else
                {
                    othersCounter++;
                }
            }
        }


        public void drawShawl(Panel panel, ScoutTroop scoutTroop, Label labelName)
        {
            //co-ordinates chusty (shawl)
            int a = 5; //tape width
            int c = 75; //triangle height
            Point p0 = new Point(14, 300); //left high vertex
            Point p1 = new Point(p0.X + a + c + (int)(a * 1.414), p0.Y); //middle high vertex
            Point p2 = new Point(p1.X + a + c + (int)(a * 1.414), p1.Y); //right high vertex
            Point p3 = new Point(p1.X - c, p1.Y + a); //left on second row
            Point p4 = new Point(p3.X + c, p3.Y); //middle on second row
            Point p5 = new Point(p4.X + c, p4.Y); //right on second row
            Point p6 = new Point(p4.X, p4.Y + c);
            Point p7 = new Point(p6.X, p6.Y + (int)(a * 1.414)); //middle down vertex

            Graphics g = panel.CreateGraphics();
            g.Clear(panel.BackColor);
            Pen p = new Pen(Color.Black);
            SolidBrush sb = new SolidBrush(scoutTroop.color[4]);
            Point[] trapeziumBufor = { p0, p3, p4, p1 };
            Point[] triangleBufor = { p3, p6, p4 };
            //g.DrawPolygon(p, trapeziumBufor);
            g.FillPolygon(sb, trapeziumBufor);

            sb.Color = scoutTroop.color[5];
            trapeziumBufor[0] = p1;
            trapeziumBufor[1] = p4;
            trapeziumBufor[2] = p5;
            trapeziumBufor[3] = p2;
            //g.DrawPolygon(p, trapeziumBufor);
            g.FillPolygon(sb, trapeziumBufor);

            sb.Color = scoutTroop.color[0];
            trapeziumBufor[0] = p0;
            trapeziumBufor[1] = p7;
            trapeziumBufor[2] = p6;
            trapeziumBufor[3] = p3;
            //g.DrawPolygon(p, trapeziumBufor);
            g.FillPolygon(sb, trapeziumBufor);

            sb.Color = scoutTroop.color[1];
            trapeziumBufor[0] = p6;
            trapeziumBufor[1] = p7;
            trapeziumBufor[2] = p2;
            trapeziumBufor[3] = p5;
            //g.DrawPolygon(p, trapeziumBufor);
            g.FillPolygon(sb, trapeziumBufor);

            sb.Color = scoutTroop.color[2];
            //g.DrawPolygon(p, triangleBufor);
            g.FillPolygon(sb, triangleBufor);

            sb.Color = scoutTroop.color[3];
            triangleBufor[0] = p4;
            triangleBufor[1] = p6;
            triangleBufor[2] = p5;
            //g.DrawPolygon(p, triangleBufor);
            g.FillPolygon(sb, triangleBufor);

            sb.Color = Color.White;
            Font f = new Font("Verdana", (float)9.75, FontStyle.Bold);
            g.DrawString(scoutTroop.nameNum + " " + scoutTroop.name, f, sb, labelName.Left, 327);
        }


        public Scout findPerson(int X, int Y)
        {
            int howManyPrinted = printedScouts.Count();
            for (int i = 0; i < howManyPrinted; i++)
            {
                if (scoutPositions[i].leftHigh.Y < Y && scoutPositions[i].rightDown.Y > Y)
                {
                    if (scoutPositions[i].leftHigh.X < X && scoutPositions[i].rightDown.X > X)
                    {
                        return printedScouts[i];
                    }
                }
            }

            return null;
        }


    }
}
