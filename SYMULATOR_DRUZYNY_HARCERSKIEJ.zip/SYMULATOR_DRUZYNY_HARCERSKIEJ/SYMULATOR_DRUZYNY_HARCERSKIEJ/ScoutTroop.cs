﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public class ScoutTroop
    {
        //constant properties
        public decimal nameNum;
        public string name;
        public System.Drawing.Color[] color = new System.Drawing.Color[6];
        public bool isMaleTeam;
        public string boss;

        //dynamic properties
        public int membersCounter;
        public double points;
        public double age;
        public double actionPoints;
        public string removeRaport;

        //scout names properties
        public int nameCounter = 0;
        private string[,] nameStock = { 
            {
                "Loczek", "Kostka", "Andzia", "Balbina", "Pucia", "Alutek", "Szysza", "Madżągnez", "Budyń", "Kisiel",
                "Kluska", "Konewka", "Piórko", "Rybka", "Malina", "Tęcza", "Fiona", "Dama", "Alutek", "Misia",
                "Hermiona", "Groszek", "Koniczyna", "Truskawka", "Wiedźma", "Czarownica", "Awaria", "Puszcza", "Sarenka", "Niedźwiedzica",
                "Kasztanka", "Szefowa", "Pszczółka", "Anoda", "Katoda", "Bazyl", "Busola", "Fanta", "Pepsi", "Kukurydza",
                "Tomojo", "Jojo", "Iskra", "Refi", "Dolores", "Samanta", "Czilałt", "Knoppers", "Kasialot", "Mania",
                "Gucio", "Mysza", "Haloumi", "Władzio", "Sumik", "Szkrab", "Dąbek", "Wira", "Cezar", "Amazonka",
                "Dżasta", "Nadia", "Romeo", "Bazyl", "Aurora", "Zegarynka", "Zuzu", "Mrówka", "Nelly", "Ruda",
                "Pluto", "Nocny", "Bunia", "Siłacz", "Struś"
            }, 
            {
                "Sienek", "Hidi", "Cyborg", "Rudy", "Pampers", "Kozak", "Gaweł", "Ostry", "Kruchy", "Jajek",
                "Nozo", "Byczek", "Luksus", "Miki", "Goofy", "Pawo", "Grzybek", "Power", "Zorg", "Witek",
                "Młody", "Blaszka", "Broka", "Zegarek", "Lotnik", "Kwapek", "Cygar", "Mały", "Kurczak", "Dziki",
                "Kucharz", "Matiz", "Przemas", "Max", "Bobek", "Bobo", "Zapalniczka", "Listek", "Johnny", "Joker",
                "Cegła", "Kieł", "Świerszcz", "Adi", "Arbuz", "Krecik", "Piżmak", "Niko", "Szpon", "Wściekły Wilk",
                "Krasnal", "Lars", "Chudy", "Cezar", "Zdzisio", "Brzoza", "Hugo", "Magnes", "Rufus", "Ozi",
                "Boguś", "Wiśnia", "Goryl", "Zioło", "Maks", "Cola", "Zawór", "Jokes", "Prezes", "Keslin",
                "Dawcio", "Felek", "Kinder", "Ramzes", "Pussy"
            } };


        //Main Lists
        //Limit of members = 200
        public List<Scout> Members = new List<Scout>();
        public List<Patrol> Patrols = new List<Patrol>();

        //Pointer Lists
        public List<Scout> Adjutants = new List<Scout>();
        public List<Scout> PatrolMasters = new List<Scout>();
        public List<Scout> PatrolHelpers = new List<Scout>();

        //KIM
        public Kim PZ = new Kim("PZ");
        public Kim PP = new Kim("PP");
        public Kim ZS = new Kim("ZS");


        /// <summary>
        /// Add age to all members of the Scout Troop
        /// </summary>
        public void addAge()
        {
            age += 0.5;

            foreach (Scout s in Members)
            {
                s.addAge();
            }

            PZ.addAge();
            PP.addAge();
            ZS.addAge();
        }

        /// <summary>
        /// Add scout to patrol
        /// </summary>
        public bool addToPatrol(Scout s, Patrol p)
        {
            if (s != null && p != null)
            {
                if (!Members.Contains(s)) Members.Add(s);
                s.isPatrolMember = true;
                if (!p.Members.Contains(s))
                {
                    p.Members.Add(s);
                    return true;
                }
                return false;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Remove scout from patrol
        /// </summary>
        public bool removeMaster(Scout s, Patrol p)
        {
            if (s != null && p != null)
            {
                if (p.patrolMaster == s)
                {
                    p.patrolMaster = null;

                    bool isMasterOfAnyP = false;
                    foreach (Patrol p2 in Patrols)
                    {
                        if (p2.patrolMaster == s) isMasterOfAnyP = true;
                    }

                    if (!isMasterOfAnyP)
                    {
                        s.isPatrolMaster = false;
                        PatrolMasters.Remove(s);
                        s.achivement[2, 1] = false;
                    }

                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Add new patrol
        /// </summary>
        public bool addNewPatrol(string name)
        {
            Patrol p = new Patrol(name);
            Patrols.Add(p);
            return true;
        }

        /// <summary>
        /// Makes scout a PatrolHelper of patrol
        /// </summary>
        public bool makeHelper(Scout s, Patrol p)
        {
            if (s != null && p != null)
            {
                addToPatrol(s, p);
                if (!PatrolHelpers.Contains(s)) PatrolHelpers.Add(s);
                Scout s2 = p.patrolHelper;
                if (s2 != null)
                {
                    removeMaster(s2, p);
                }
                s.isPatrolHelper = true;
                p.patrolHelper = s;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Removes patrolHelper
        /// </summary>
        public bool removeHelper(Scout s, Patrol p)
        {
            if (s != null && p != null)
            {
                if (p.patrolHelper == s)
                {
                    p.patrolHelper = null;

                    bool isHelperOfAnyP = false;
                    foreach (Patrol p2 in Patrols)
                    {
                        if (p2.patrolMaster == s) isHelperOfAnyP = true;
                    }

                    if (!isHelperOfAnyP)
                    {
                        s.isPatrolHelper = false;
                        PatrolHelpers.Remove(s);
                    }

                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Removes scout from patrol
        /// </summary>
        public bool removeFromPatrol(Scout s, Patrol p)
        {
            if (s != null && p != null)
            {
                if (p.patrolMaster == s) removeMaster(s, p);
                if (p.patrolHelper == s) removeHelper(s, p);

                if (p.Members.Contains(s))
                {
                    p.Members.Remove(s);

                    bool isMemberOfAnyP = false;
                    foreach (Patrol p2 in Patrols)
                    {
                        if (p2.Members.Contains(s)) isMemberOfAnyP = true;
                    }

                    s.isPatrolMember = isMemberOfAnyP;
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Removes patrol
        /// </summary>
        public bool removePatrol(Patrol p)
        {
            if (p != null)
            {
                int length = p.Members.Count();
                for (int i = 0; i < length; i++)
                {
                    removeFromPatrol(p.Members[i], p);
                    i--;
                    length--;
                }

                if (Patrols.Contains(p))
                {
                    Patrols.Remove(p);
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Makes scout an adjutant
        /// </summary>
        public bool makeAdjutant(Scout s)
        {
            if (s != null)
            {
                if (!Adjutants.Contains(s))
                {
                    Adjutants.Add(s);
                    s.isAdjutant = true;
                    if (!Members.Contains(s)) Members.Add(s);
                    if (s.isInstructor) s.achivement[3, 1] = true;
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Set Boss properties
        /// </summary>
        public bool makeBoss(Scout s)
        {
            if (s != null)
            {
                s.isBoss = true;
                s.isInstructor = true;
                s.stage = 5;
            }
            return false;
        }

        /// <summary>
        /// Removes scout from adjutants
        /// </summary>
        public bool removeFromAdjutants(Scout s)
        {
            if (s != null)
            {
                if (Adjutants.Contains(s))
                {
                    Adjutants.Remove(s);
                    s.isAdjutant = false;
                    if (s.isInstructor) s.achivement[3, 1] = false;
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Makes scout Patrol Master
        /// </summary>
        public bool makeMaster(Scout s, Patrol p)
        {
            if (s != null && p != null)
            {
                addToPatrol(s, p);
                if (!PatrolMasters.Contains(s)) PatrolMasters.Add(s);
                Scout s2 = p.patrolMaster;
                if (s2 != null)
                {
                    removeMaster(s2, p);
                }
                s.isPatrolMaster = true;
                p.patrolMaster = s;
                if (s.isInstructor) s.achivement[2, 1] = true;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Count and add points after round
        /// </summary>
        public double scoutsGeneratePoints()
        {
            double newPoints = 0;

            foreach (Scout s in Members)
            {
                switch (s.stage)
                {
                    case 1:
                        newPoints += 0.5;
                        break;
                    case 2:
                        newPoints += 1;
                        break;
                    case 3:
                        newPoints += 1.5;
                        break;
                    case 4:
                        newPoints += 2;
                        break;
                    case 5:
                        newPoints += 3;
                        break;
                    default:
                        break;
                }
            }

            actionPoints += newPoints;
            return newPoints;
        }

        /// <summary>
        /// Removes Scout from the ScoutTroop
        /// </summary>
        public bool removeScout(Scout s)
        {
            //remove from courses
            if (s.isOnPZ) PZ.Students.Remove(s);
            if (s.isOnPP) PP.Students.Remove(s);
            if (s.isOnZS) ZS.Students.Remove(s);
            //remove from functions
            if (s.isAdjutant) Adjutants.Remove(s);
            if (s.isPatrolMaster) PatrolMasters.Remove(s);
            if (s.isPatrolHelper) PatrolHelpers.Remove(s);
            //remove from patrols
            int length;
            foreach (Patrol p in Patrols)
            {
                if (p.patrolMaster == s)
                {
                    p.patrolMaster = null;
                }
                if (p.patrolHelper == s)
                {
                    p.patrolHelper = null;
                }

                /* Can't use that :(
                foreach (Scout s0 in p.Members)
                {
                    if (s0 == s)
                    {
                        p.Members.Remove(s);
                    }
                }
                */
                length = p.Members.Count();
                for (int i = 0; i < length; i++)
                {
                    if (p.Members[i] == s)
                    {
                        p.Members.RemoveAt(i);
                        length--;
                        i--;
                    }
                }
            }
            //remove from main list
            Members.Remove(s);
            s = null;
            membersCounter--;

            return true;
        }

        /// <summary>
        /// Removes old scouts
        /// </summary>
        public int removeOldScouts()
        {
            int counter = 0;
            string exelled = "";
            int length = Members.Count();

            for (int i = 0; i < length; i++)
            {
                Scout s = Members[i];
                if (s.stage < 3)
                {
                    if (s.ageSameStage > 1)
                    {
                        if (counter == 0)
                            exelled = s.name;
                        else
                            exelled += ", " + s.name;
                        removeScout(s);
                        counter++;
                        length--;
                        i--;
                    }
                }
                else if (s.stage < 5)
                {
                    if (s.ageSameStage > 2)
                    {
                        if (counter == 0)
                            exelled = s.name;
                        else
                            exelled += ", " + s.name;
                        removeScout(s);
                        counter++;
                        length--;
                        i--;
                    }
                }
            }

            if (counter == 1)
            {
                if (isMaleTeam == true)
                {
                    removeRaport = exelled + "wykruszył się.";
                }
                else
                {
                    removeRaport = exelled + "wykruszyła się.";
                }
            }
            else if (counter > 1)
            {
                removeRaport = exelled + " wykruszyli się.";
            }
            else
            {
                removeRaport = "";
            }

            return counter;
        }

        /// <summary>
        /// Reset properties (when its new game)
        /// </summary>
        public void reset()
        {
            //clear courses
            PZ.Students.Clear();
            PP.Students.Clear();
            ZS.Students.Clear();

            //clear pointer lists
            Adjutants.Clear();
            PatrolMasters.Clear();
            PatrolHelpers.Clear();

            //clear lists
            Patrols.Clear();
            Members.Clear();

            //other properties
            nameCounter = 0;
            membersCounter = 0;
            points = 0;
            age = 0;
            actionPoints = 10;
        }

        /// <summary>
        /// Count points
        /// </summary>
        public double countPoints()
        {
            points = 0;

            foreach (Scout s in Members)
            {
                switch (s.stage)
                {
                    case 1:
                        points += 1;
                        break;
                    case 2:
                        points += 3;
                        break;
                    case 3:
                        points += 8;
                        break;
                    case 4:
                        points += 15;
                        break;
                    case 5:
                        points += 25;
                        break;
                    default:
                        break;
                }
            }

            points += actionPoints;
            return points;
        }

        /// <summary>
        /// Add NEW scout to ScoutTroop
        /// </summary>
        public void addScout(int num)
        {
            for (int i = 0; i < num; i++)
            {
                Members.Add(new Scout(randomName()));
                membersCounter++;
            }
        }

        /// <summary>
        ///avoid copies in names, add suffix if there are
        ///NOT USED IN THIS VERSION
        /// </summary>
        private string suffixName(string name)
        {
            //just checking scout troop (do not increment nameCounter!)  
            bool isUsed = false;
            char lastLetter;
            do
            {
                isUsed = false;
                foreach (Scout s in Members)
                {
                    if (s.name == name) isUsed = true;
                }
                if (isUsed == true)
                {
                    lastLetter = name[name.Length - 1];
                    if ((int)lastLetter < 48 || (int)lastLetter > 56)
                        name += 0;
                    else name = name.Substring(0, name.Length - 1) + (char)((int)lastLetter + 1);
                }

            } while (isUsed == true);

            return name;
        }


        /// <summary>
        ///Create unique name (get from table, restrict nameStock from new name, optionally add suffix)
        ///ALSO [in case when there are some blank spaces in nameStock - null, ""]:
        ///it checks if is there already that's scout's name in scoutTroop
        ///if YES => it render another name
        /// </summary>
        private string randomName()
        {
            string nameBuf;
            int sexIndex;
            bool isUsedInTroop;
            Random rnd = new Random();

            if (isMaleTeam)
                sexIndex = 1;
            else sexIndex = 0;

            do
            {
                int nameGeneration = 1;
                int nameStockAvailable = nameStock.Length / 2 - nameCounter;

                while (nameStockAvailable < 1)
                {
                    nameStockAvailable += nameStock.Length / 2;
                    nameGeneration++;
                }

                //random from nameStock
                int indexRND = rnd.Next(nameStockAvailable);
                nameBuf = nameStock[sexIndex, indexRND];

                //to avoid copies
                //swap places and increment nameCounter
                //used names are always beyound range (nameStockAvailable)
                nameStock[sexIndex, indexRND] = nameStock[sexIndex, nameStockAvailable - 1];
                nameStock[sexIndex, nameStockAvailable - 1] = nameBuf;
                nameCounter++;

                if (nameGeneration > 1)
                    nameBuf += nameGeneration;

                //check if is there already that's scout's name in scoutTroop
                //if YES => we must render another name
                isUsedInTroop = false;
                foreach (Scout s in Members)
                {
                    if (s.name == nameBuf) isUsedInTroop = true;
                }

            } while (isUsedInTroop == true);

            return nameBuf;
        }


        public ScoutTroop()
        {
            
        }
    }
}
