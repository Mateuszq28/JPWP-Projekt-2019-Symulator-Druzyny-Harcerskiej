﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public class Scout
    {
        public string name;
        public double age = 0;
        public int stage = 1;
        public double ageSameStage = 0;
        public bool isRover = false;
        public bool isInstructor = false;
        public bool[,] achivement = new bool[4,4];

        //function in scout troop
        public bool isBoss = false;
        public bool isAdjutant = false;
        public bool isPatrolMaster = false;
        public bool isPatrolHelper = false;
        public bool isPatrolMember = false;

        //KIM and ZS
        public bool isOnPZ = false;
        public bool isOnPP = false;
        public bool isOnZS = false;
        public double howLongPZ = 0;
        public double howLongPP = 0;
        public double howLongZS = 0;
        public bool certificatePZ = false;
        public bool certificatePP = false;
        public bool certificateZS = false;

        public Scout(string name)
        {
            this.name = name;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                    achivement[i, j] = false;
            }
        }

        public Scout ShallowCopy()
        {
            return (Scout)this.MemberwiseClone();
        }

        public Scout DeepCopy()
        {
            Scout other = (Scout)this.MemberwiseClone();
            other.achivement = new bool[4,4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                    other.achivement[i, j] = false;
            }
            return other;
        }

        public void addAge()
        {
            age += 0.5;
            ageSameStage += 0.5;
        }

        /// <summary>
        /// Checks if this scout needs to be upgraded
        /// </summary>
        public bool checkIfPromotion()
        {
            switch (stage)
            {
                case 1:
                    if (achivement[0,0] && achivement[0,1])
                    {
                        stage++;
                        ageSameStage = 0;
                        return true;
                    }
                    break;
                case 2:
                    if (achivement[1,0] && achivement[1,1])
                    {
                        if (achivement[1, 2])
                        {
                            stage++;
                            isInstructor = true;
                            ageSameStage = 0;
                            if (isPatrolMaster) achivement[2, 1] = true;
                            return true;
                        }
                        else if (achivement[1,3])
                        {
                            stage++;
                            isRover = true;
                            ageSameStage = 0;
                            return true;
                        }
                    }
                    break;
                case 3:
                    if (isInstructor)
                    {
                        if (achivement[2,0] && achivement [2,1] && achivement[2,2] && achivement[2,3])
                        {
                            stage++;
                            ageSameStage = 0;
                            if (isAdjutant) achivement[3, 1] = true;
                            return true;
                        }
                    }
                    else if (achivement[2,0] && achivement[2,1])
                    {
                        stage++;
                        ageSameStage = 0;
                        return true;
                    }
                    break;
                case 4:
                    if (isInstructor)
                    {
                        if (achivement[3, 0] && achivement[3, 1] && achivement[3, 2])
                        {
                            stage++;
                            ageSameStage = 0;
                            return true;
                        }
                    }
                    else if (achivement[3, 0] && achivement[3, 1])
                    {
                        stage++;
                        ageSameStage = 0;
                        return true;
                    }
                    break;
                default:
                    break;
                    
            }
            return false;
        }





    }

    
}
