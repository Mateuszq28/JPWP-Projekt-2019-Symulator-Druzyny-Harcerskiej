﻿namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    partial class Restarter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Restarter));
            this.labelQuestion = new System.Windows.Forms.Label();
            this.buttonYES = new System.Windows.Forms.Button();
            this.buttonNO = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelQuestion
            // 
            this.labelQuestion.AutoSize = true;
            this.labelQuestion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(87)))), ((int)(((byte)(27)))));
            this.labelQuestion.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelQuestion.ForeColor = System.Drawing.Color.White;
            this.labelQuestion.Location = new System.Drawing.Point(64, 93);
            this.labelQuestion.Name = "labelQuestion";
            this.labelQuestion.Size = new System.Drawing.Size(372, 50);
            this.labelQuestion.TabIndex = 3;
            this.labelQuestion.Text = "Czy na pewno chcesz ropocząć\r\ngrę od nowa?";
            this.labelQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonYES
            // 
            this.buttonYES.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.buttonYES.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold);
            this.buttonYES.Location = new System.Drawing.Point(120, 250);
            this.buttonYES.Name = "buttonYES";
            this.buttonYES.Size = new System.Drawing.Size(100, 100);
            this.buttonYES.TabIndex = 4;
            this.buttonYES.Text = "TAK";
            this.buttonYES.UseVisualStyleBackColor = false;
            this.buttonYES.Click += new System.EventHandler(this.buttonYES_Click);
            this.buttonYES.MouseEnter += new System.EventHandler(this.buttonYES_MouseEnter);
            this.buttonYES.MouseLeave += new System.EventHandler(this.buttonYES_MouseLeave);
            // 
            // buttonNO
            // 
            this.buttonNO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.buttonNO.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold);
            this.buttonNO.Location = new System.Drawing.Point(280, 250);
            this.buttonNO.Name = "buttonNO";
            this.buttonNO.Size = new System.Drawing.Size(100, 100);
            this.buttonNO.TabIndex = 5;
            this.buttonNO.Text = "NIE";
            this.buttonNO.UseVisualStyleBackColor = false;
            this.buttonNO.Click += new System.EventHandler(this.buttonNO_Click);
            this.buttonNO.MouseEnter += new System.EventHandler(this.button1_MouseEnter);
            this.buttonNO.MouseLeave += new System.EventHandler(this.buttonNO_MouseLeave);
            // 
            // Restarter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(181)))), ((int)(((byte)(68)))));
            this.ClientSize = new System.Drawing.Size(500, 500);
            this.Controls.Add(this.buttonNO);
            this.Controls.Add(this.buttonYES);
            this.Controls.Add(this.labelQuestion);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Restarter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelQuestion;
        private System.Windows.Forms.Button buttonYES;
        private System.Windows.Forms.Button buttonNO;
    }
}