﻿namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    partial class DiceRoller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DiceRoller));
            this.labelQuestion = new System.Windows.Forms.Label();
            this.pictureDice = new System.Windows.Forms.PictureBox();
            this.buttonZrezygnuj = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDice)).BeginInit();
            this.SuspendLayout();
            // 
            // labelQuestion
            // 
            this.labelQuestion.AutoSize = true;
            this.labelQuestion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(87)))), ((int)(((byte)(27)))));
            this.labelQuestion.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelQuestion.ForeColor = System.Drawing.Color.White;
            this.labelQuestion.Location = new System.Drawing.Point(12, 50);
            this.labelQuestion.Name = "labelQuestion";
            this.labelQuestion.Size = new System.Drawing.Size(478, 75);
            this.labelQuestion.TabIndex = 4;
            this.labelQuestion.Text = "Raz na półrocze (na jego zakończenie)\r\ngracz rzuca kostką sześcienną. Ilość\r\nocze" +
    "k na kostce oznacza pozyskane PR.";
            this.labelQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureDice
            // 
            this.pictureDice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureDice.BackgroundImage")));
            this.pictureDice.Location = new System.Drawing.Point(97, 182);
            this.pictureDice.Name = "pictureDice";
            this.pictureDice.Size = new System.Drawing.Size(307, 255);
            this.pictureDice.TabIndex = 5;
            this.pictureDice.TabStop = false;
            this.pictureDice.Click += new System.EventHandler(this.pictureDice_Click);
            // 
            // buttonZrezygnuj
            // 
            this.buttonZrezygnuj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.buttonZrezygnuj.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonZrezygnuj.ForeColor = System.Drawing.Color.White;
            this.buttonZrezygnuj.Location = new System.Drawing.Point(162, 450);
            this.buttonZrezygnuj.Name = "buttonZrezygnuj";
            this.buttonZrezygnuj.Size = new System.Drawing.Size(177, 23);
            this.buttonZrezygnuj.TabIndex = 6;
            this.buttonZrezygnuj.Text = "Zrezygnuj z Mobilizacji";
            this.buttonZrezygnuj.UseVisualStyleBackColor = false;
            this.buttonZrezygnuj.Visible = false;
            this.buttonZrezygnuj.Click += new System.EventHandler(this.buttonZrezygnuj_Click);
            this.buttonZrezygnuj.MouseEnter += new System.EventHandler(this.buttonZrezygnuj_MouseEnter);
            this.buttonZrezygnuj.MouseLeave += new System.EventHandler(this.buttonZrezygnuj_MouseLeave);
            // 
            // DiceRoller
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(181)))), ((int)(((byte)(68)))));
            this.ClientSize = new System.Drawing.Size(500, 500);
            this.Controls.Add(this.buttonZrezygnuj);
            this.Controls.Add(this.pictureDice);
            this.Controls.Add(this.labelQuestion);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DiceRoller";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Load += new System.EventHandler(this.DiceRoller_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureDice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelQuestion;
        private System.Windows.Forms.PictureBox pictureDice;
        private System.Windows.Forms.Button buttonZrezygnuj;
    }
}