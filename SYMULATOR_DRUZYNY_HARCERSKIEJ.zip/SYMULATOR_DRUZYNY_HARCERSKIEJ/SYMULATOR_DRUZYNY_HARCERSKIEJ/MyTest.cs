﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public class MyTest
    {
        static bool mainSwitchTest = false;
        static bool userSwitchTest = false;
        static bool wereTestUsed = false;

        public static void turnON()
        {
            userSwitchTest = true;
            wereTestUsed = true;
        }

        public static void turnOFF()
        {
            userSwitchTest = false;
        }

        public static void reset()
        {
            userSwitchTest = false;
            wereTestUsed = false;
        }


        static bool isON(string name)
        {
            if (mainSwitchTest && userSwitchTest)
            {
                switch (name)
                {
                    case "TEST SYSTEMU PRZYDZIALANIA MIEJSCA WARSTWOM":
                        return true;
                    case "TEST SYSTEMU PRZYDZIALANIA IMION":
                        return true;
                    case "TEST PROPORCJI SZEROKOŚCI I WYSOKOŚCI (sprawdzenie mnożenia double)":
                        return true;
                    case "TEST OBECNOŚCI DANEGO TYPU KART W TALII":
                        return true;
                    case "INNY TEST (SZYBKI CONSOLE WRITE LINE)":
                        return true;
                    case "INFORMACJE O DRUKOWANEJ OSOBIE":
                        return true;
                    case "freeActionPoints":
                        return true;

                }
            }
            
            return false;
        }

        public static void fastConsoleWrite(string text)
        {
            string name = "INNY TEST (SZYBKI CONSOLE WRITE LINE)";
            if (isON(name))
            {
                Console.WriteLine("--------------------------------------------");
                Console.WriteLine(name);
                Console.WriteLine(text);
                Console.WriteLine("--------------------------------------------");
            }
        }

        public static void drawingPersonInfo(Scout s, Rectangle rec)
        {
            string name = "INFORMACJE O DRUKOWANEJ OSOBIE";
            if (isON(name))
            {
                Console.WriteLine("--------------------------------------------");
                Console.WriteLine(name);
                Console.WriteLine("imie + stage + isBoss + isAdjutant + isPatrolMaster + isPatrolHelper + isPatrolMember");
                Console.WriteLine(s.name + s.stage + s.isBoss + s.isAdjutant + s.isPatrolMaster + s.isPatrolHelper + s.isPatrolMember);
                Console.WriteLine("prostokąt (X Y width height): " + rec.X + " " + rec.Y + " " + rec.Width + " " + rec.Height);
                Console.WriteLine("--------------------------------------------");
            }
        }

        public static void classCardTest(bool areAnyAdjutants, bool areAnyPatrolMasters, bool areAnyPatrolHelpers, bool areAnyPatrolMembers, bool areAnyFreeSouls)
        {
            string name = "TEST OBECNOŚCI DANEGO TYPU KART W TALII";
            if (isON(name))
            {
                Console.WriteLine("--------------------------------------------");
                Console.WriteLine(name);
                Console.WriteLine("czy są przyboczni: " + areAnyAdjutants);
                Console.WriteLine("czy są zastępowi: " + areAnyPatrolMasters);
                Console.WriteLine("czy są podzastępowi: " + areAnyPatrolHelpers);
                Console.WriteLine("czy są zwykli członkowie zastępów: " + areAnyPatrolMembers);
                Console.WriteLine("czy są wolne dusze: " + areAnyFreeSouls);
                Console.WriteLine("--------------------------------------------");
            }
        }

        public static void proportionTest(double proportion, int width, int height)
        {
            string name = "TEST PROPORCJI SZEROKOŚCI I WYSOKOŚCI (sprawdzenie mnożenia double)";
            if (isON(name))
            {
                Console.WriteLine("--------------------------------------------");
                Console.WriteLine(name);
                Console.WriteLine("proporcja: " + proportion);
                Console.WriteLine("wysokość: " + height);
                Console.WriteLine("szerokość: " + width);
                Console.WriteLine("--------------------------------------------");
            }
        }

        public static void layerTest(MyRectangle[] space)
        {
            string name = "TEST SYSTEMU PRZYDZIALANIA MIEJSCA WARSTWOM";
            if (isON(name))
            {
                int i = 0;
                Console.WriteLine("--------------------------------------------");
                Console.WriteLine(name);
                Console.WriteLine("LEWY GÓRNY.X  LEWY GÓRNY.Y  PRAWY DOLNY.X  PRAWY DOLNY.Y");
                foreach (MyRectangle r in space)
                {
                    Console.WriteLine("Space layer " + i + ": " + r.leftHigh.X + " " + r.leftHigh.Y + " " + r.rightDown.X + " " + r.rightDown.Y);
                    i++;
                }
                Console.WriteLine("--------------------------------------------");
            }
        }

        public static void nameSystemTest(ScoutTroop st)
        {
            string name = "TEST SYSTEMU PRZYDZIALANIA IMION";
            if (isON(name))
            {
                st.addScout(12);
                Console.WriteLine("--------------------------------------------");
                Console.WriteLine(name);
                foreach (Scout s in st.Members)
                    Console.WriteLine(s.name);
                Console.WriteLine("--------------------------------------------");
            }
        }

        public static void freeActionPoints(ScoutTroop sp)
        {
            string name = "freeActionPoints";
            if (isON(name))
            {
                sp.actionPoints += 100;
            }
        }

    }
}
