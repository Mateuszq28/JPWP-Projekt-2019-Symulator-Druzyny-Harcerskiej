﻿namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    partial class ProsectTroop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle281 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle282 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle283 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle284 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle285 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle286 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle287 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle288 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle289 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle290 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle291 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle292 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle293 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle294 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle295 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle296 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle297 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle298 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle299 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle300 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProsectTroop));
            this.panelLeft = new System.Windows.Forms.Panel();
            this.labelTroop = new System.Windows.Forms.Label();
            this.panelLeftBottom = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.labelPatrols = new System.Windows.Forms.Label();
            this.panelRight = new System.Windows.Forms.Panel();
            this.panelRightBottom = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.labelMasters = new System.Windows.Forms.Label();
            this.panelMain = new System.Windows.Forms.Panel();
            this.panelHelpers = new System.Windows.Forms.Panel();
            this.dataGridViewHelpers = new System.Windows.Forms.DataGridView();
            this.panelAdjutants = new System.Windows.Forms.Panel();
            this.dataGridViewAdjutants = new System.Windows.Forms.DataGridView();
            this.panelMasters = new System.Windows.Forms.Panel();
            this.dataGridViewMasters = new System.Windows.Forms.DataGridView();
            this.panelPatrols = new System.Windows.Forms.Panel();
            this.dataGridViewPatrols = new System.Windows.Forms.DataGridView();
            this.panelTop = new System.Windows.Forms.Panel();
            this.firstOpen = new System.Windows.Forms.PictureBox();
            this.transparent = new System.Windows.Forms.PictureBox();
            this.dataGridViewTroop = new System.Windows.Forms.DataGridView();
            this.shawl = new System.Windows.Forms.PictureBox();
            this.firstGive = new System.Windows.Forms.PictureBox();
            this.cross = new System.Windows.Forms.PictureBox();
            this.PZinvite = new System.Windows.Forms.PictureBox();
            this.ZSinvite = new System.Windows.Forms.PictureBox();
            this.secondGiven = new System.Windows.Forms.PictureBox();
            this.secondOpen = new System.Windows.Forms.PictureBox();
            this.ZSGiven = new System.Windows.Forms.PictureBox();
            this.brownMaster = new System.Windows.Forms.PictureBox();
            this.PZGiven = new System.Windows.Forms.PictureBox();
            this.PPOpen = new System.Windows.Forms.PictureBox();
            this.epaulet = new System.Windows.Forms.PictureBox();
            this.greenAdjutant = new System.Windows.Forms.PictureBox();
            this.PPGiven = new System.Windows.Forms.PictureBox();
            this.trophy = new System.Windows.Forms.PictureBox();
            this.pictureChecked = new System.Windows.Forms.PictureBox();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.removeHelper = new System.Windows.Forms.Button();
            this.makeHelper = new System.Windows.Forms.Button();
            this.addToPatrol = new System.Windows.Forms.Button();
            this.removeFromPatrol = new System.Windows.Forms.Button();
            this.makeAdjutant = new System.Windows.Forms.Button();
            this.removeAdjutant = new System.Windows.Forms.Button();
            this.makeMaster = new System.Windows.Forms.Button();
            this.removeMaster = new System.Windows.Forms.Button();
            this.addPatrol = new System.Windows.Forms.Button();
            this.removePatrol = new System.Windows.Forms.Button();
            this.removeMember = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ZSstart = new System.Windows.Forms.Button();
            this.PZstart = new System.Windows.Forms.Button();
            this.PPstart = new System.Windows.Forms.Button();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.scoutTroopBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.scoutTroopBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.scoutTroopBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.scoutBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.scoutBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.scoutTroopBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.scoutTroopBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.panelLeft.SuspendLayout();
            this.panelLeftBottom.SuspendLayout();
            this.panelRight.SuspendLayout();
            this.panelRightBottom.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.panelHelpers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHelpers)).BeginInit();
            this.panelAdjutants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdjutants)).BeginInit();
            this.panelMasters.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMasters)).BeginInit();
            this.panelPatrols.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPatrols)).BeginInit();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.firstOpen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.transparent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTroop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shawl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstGive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cross)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PZinvite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZSinvite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondGiven)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondOpen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZSGiven)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brownMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PZGiven)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PPOpen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.epaulet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenAdjutant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PPGiven)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trophy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureChecked)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scoutTroopBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutTroopBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutTroopBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutTroopBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutTroopBindingSource4)).BeginInit();
            this.SuspendLayout();
            // 
            // panelLeft
            // 
            this.panelLeft.Controls.Add(this.panel1);
            this.panelLeft.Controls.Add(this.label3);
            this.panelLeft.Controls.Add(this.labelTroop);
            this.panelLeft.Controls.Add(this.panelLeftBottom);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Location = new System.Drawing.Point(0, 0);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(200, 681);
            this.panelLeft.TabIndex = 0;
            // 
            // labelTroop
            // 
            this.labelTroop.AutoSize = true;
            this.labelTroop.BackColor = System.Drawing.Color.DarkBlue;
            this.labelTroop.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelTroop.ForeColor = System.Drawing.Color.White;
            this.labelTroop.Location = new System.Drawing.Point(141, 0);
            this.labelTroop.Name = "labelTroop";
            this.labelTroop.Size = new System.Drawing.Size(61, 13);
            this.labelTroop.TabIndex = 1;
            this.labelTroop.Text = "Drużyna";
            // 
            // panelLeftBottom
            // 
            this.panelLeftBottom.Controls.Add(this.panel2);
            this.panelLeftBottom.Controls.Add(this.label4);
            this.panelLeftBottom.Controls.Add(this.label2);
            this.panelLeftBottom.Controls.Add(this.labelPatrols);
            this.panelLeftBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelLeftBottom.Location = new System.Drawing.Point(0, 341);
            this.panelLeftBottom.Name = "panelLeftBottom";
            this.panelLeftBottom.Size = new System.Drawing.Size(200, 340);
            this.panelLeftBottom.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Green;
            this.label2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(124, 170);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Przyboczni";
            // 
            // labelPatrols
            // 
            this.labelPatrols.AutoSize = true;
            this.labelPatrols.BackColor = System.Drawing.Color.Brown;
            this.labelPatrols.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelPatrols.ForeColor = System.Drawing.Color.White;
            this.labelPatrols.Location = new System.Drawing.Point(141, 0);
            this.labelPatrols.Name = "labelPatrols";
            this.labelPatrols.Size = new System.Drawing.Size(59, 13);
            this.labelPatrols.TabIndex = 2;
            this.labelPatrols.Text = "Zastępy";
            // 
            // panelRight
            // 
            this.panelRight.Controls.Add(this.panelRightBottom);
            this.panelRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelRight.Location = new System.Drawing.Point(1064, 0);
            this.panelRight.Name = "panelRight";
            this.panelRight.Size = new System.Drawing.Size(200, 681);
            this.panelRight.TabIndex = 1;
            // 
            // panelRightBottom
            // 
            this.panelRightBottom.Controls.Add(this.label1);
            this.panelRightBottom.Controls.Add(this.labelMasters);
            this.panelRightBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelRightBottom.Location = new System.Drawing.Point(0, 341);
            this.panelRightBottom.Name = "panelRightBottom";
            this.panelRightBottom.Size = new System.Drawing.Size(200, 340);
            this.panelRightBottom.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.RosyBrown;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(-3, 170);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Podzastępowi";
            // 
            // labelMasters
            // 
            this.labelMasters.AutoSize = true;
            this.labelMasters.BackColor = System.Drawing.Color.Brown;
            this.labelMasters.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelMasters.ForeColor = System.Drawing.Color.White;
            this.labelMasters.Location = new System.Drawing.Point(-3, -1);
            this.labelMasters.Name = "labelMasters";
            this.labelMasters.Size = new System.Drawing.Size(73, 13);
            this.labelMasters.TabIndex = 3;
            this.labelMasters.Text = "Zastępowi";
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.panelHelpers);
            this.panelMain.Controls.Add(this.panelAdjutants);
            this.panelMain.Controls.Add(this.panelMasters);
            this.panelMain.Controls.Add(this.panelPatrols);
            this.panelMain.Controls.Add(this.panelTop);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(200, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(864, 681);
            this.panelMain.TabIndex = 2;
            // 
            // panelHelpers
            // 
            this.panelHelpers.BackColor = System.Drawing.Color.RosyBrown;
            this.panelHelpers.Controls.Add(this.dataGridViewHelpers);
            this.panelHelpers.Location = new System.Drawing.Point(432, 511);
            this.panelHelpers.Name = "panelHelpers";
            this.panelHelpers.Size = new System.Drawing.Size(432, 170);
            this.panelHelpers.TabIndex = 4;
            // 
            // dataGridViewHelpers
            // 
            dataGridViewCellStyle281.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(213)))));
            dataGridViewCellStyle281.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle281.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle281.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(165)))), ((int)(((byte)(129)))));
            dataGridViewCellStyle281.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewHelpers.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle281;
            this.dataGridViewHelpers.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(238)))), ((int)(((byte)(231)))));
            this.dataGridViewHelpers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewHelpers.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle282.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle282.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(87)))), ((int)(((byte)(27)))));
            dataGridViewCellStyle282.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle282.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle282.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(143)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle282.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle282.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewHelpers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle282;
            this.dataGridViewHelpers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHelpers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.Column24});
            dataGridViewCellStyle283.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle283.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle283.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle283.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle283.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(165)))), ((int)(((byte)(129)))));
            dataGridViewCellStyle283.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle283.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewHelpers.DefaultCellStyle = dataGridViewCellStyle283;
            this.dataGridViewHelpers.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(213)))));
            this.dataGridViewHelpers.Location = new System.Drawing.Point(4, 4);
            this.dataGridViewHelpers.Name = "dataGridViewHelpers";
            dataGridViewCellStyle284.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle284.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(121)))), ((int)(((byte)(67)))));
            dataGridViewCellStyle284.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle284.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle284.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(143)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle284.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle284.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewHelpers.RowHeadersDefaultCellStyle = dataGridViewCellStyle284;
            this.dataGridViewHelpers.Size = new System.Drawing.Size(424, 162);
            this.dataGridViewHelpers.TabIndex = 3;
            // 
            // panelAdjutants
            // 
            this.panelAdjutants.BackColor = System.Drawing.Color.Green;
            this.panelAdjutants.Controls.Add(this.dataGridViewAdjutants);
            this.panelAdjutants.Location = new System.Drawing.Point(0, 511);
            this.panelAdjutants.Name = "panelAdjutants";
            this.panelAdjutants.Size = new System.Drawing.Size(432, 170);
            this.panelAdjutants.TabIndex = 3;
            // 
            // dataGridViewAdjutants
            // 
            dataGridViewCellStyle285.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(213)))));
            dataGridViewCellStyle285.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle285.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle285.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(165)))), ((int)(((byte)(129)))));
            dataGridViewCellStyle285.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewAdjutants.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle285;
            this.dataGridViewAdjutants.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(238)))), ((int)(((byte)(231)))));
            this.dataGridViewAdjutants.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewAdjutants.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle286.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle286.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(87)))), ((int)(((byte)(27)))));
            dataGridViewCellStyle286.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle286.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle286.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(143)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle286.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle286.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewAdjutants.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle286;
            this.dataGridViewAdjutants.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAdjutants.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.Column23});
            dataGridViewCellStyle287.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle287.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle287.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle287.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle287.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(165)))), ((int)(((byte)(129)))));
            dataGridViewCellStyle287.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle287.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewAdjutants.DefaultCellStyle = dataGridViewCellStyle287;
            this.dataGridViewAdjutants.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(213)))));
            this.dataGridViewAdjutants.Location = new System.Drawing.Point(4, 4);
            this.dataGridViewAdjutants.Name = "dataGridViewAdjutants";
            dataGridViewCellStyle288.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle288.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(121)))), ((int)(((byte)(67)))));
            dataGridViewCellStyle288.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle288.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle288.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(143)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle288.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle288.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewAdjutants.RowHeadersDefaultCellStyle = dataGridViewCellStyle288;
            this.dataGridViewAdjutants.Size = new System.Drawing.Size(424, 162);
            this.dataGridViewAdjutants.TabIndex = 3;
            // 
            // panelMasters
            // 
            this.panelMasters.BackColor = System.Drawing.Color.Brown;
            this.panelMasters.Controls.Add(this.dataGridViewMasters);
            this.panelMasters.Location = new System.Drawing.Point(432, 341);
            this.panelMasters.Name = "panelMasters";
            this.panelMasters.Size = new System.Drawing.Size(432, 170);
            this.panelMasters.TabIndex = 2;
            // 
            // dataGridViewMasters
            // 
            dataGridViewCellStyle289.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(213)))));
            dataGridViewCellStyle289.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle289.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle289.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(165)))), ((int)(((byte)(129)))));
            dataGridViewCellStyle289.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewMasters.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle289;
            this.dataGridViewMasters.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(238)))), ((int)(((byte)(231)))));
            this.dataGridViewMasters.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewMasters.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle290.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle290.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(87)))), ((int)(((byte)(27)))));
            dataGridViewCellStyle290.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle290.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle290.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(143)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle290.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle290.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewMasters.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle290;
            this.dataGridViewMasters.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMasters.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Column22});
            dataGridViewCellStyle291.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle291.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle291.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle291.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle291.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(165)))), ((int)(((byte)(129)))));
            dataGridViewCellStyle291.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle291.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewMasters.DefaultCellStyle = dataGridViewCellStyle291;
            this.dataGridViewMasters.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(213)))));
            this.dataGridViewMasters.Location = new System.Drawing.Point(4, 4);
            this.dataGridViewMasters.Name = "dataGridViewMasters";
            dataGridViewCellStyle292.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle292.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(121)))), ((int)(((byte)(67)))));
            dataGridViewCellStyle292.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle292.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle292.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(143)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle292.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle292.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewMasters.RowHeadersDefaultCellStyle = dataGridViewCellStyle292;
            this.dataGridViewMasters.Size = new System.Drawing.Size(424, 162);
            this.dataGridViewMasters.TabIndex = 2;
            // 
            // panelPatrols
            // 
            this.panelPatrols.BackColor = System.Drawing.Color.Brown;
            this.panelPatrols.Controls.Add(this.dataGridViewPatrols);
            this.panelPatrols.Location = new System.Drawing.Point(0, 341);
            this.panelPatrols.Name = "panelPatrols";
            this.panelPatrols.Size = new System.Drawing.Size(432, 170);
            this.panelPatrols.TabIndex = 1;
            // 
            // dataGridViewPatrols
            // 
            dataGridViewCellStyle293.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(213)))));
            dataGridViewCellStyle293.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle293.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle293.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(165)))), ((int)(((byte)(129)))));
            dataGridViewCellStyle293.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewPatrols.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle293;
            this.dataGridViewPatrols.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(238)))), ((int)(((byte)(231)))));
            this.dataGridViewPatrols.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewPatrols.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle294.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle294.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(87)))), ((int)(((byte)(27)))));
            dataGridViewCellStyle294.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle294.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle294.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(143)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle294.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle294.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewPatrols.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle294;
            this.dataGridViewPatrols.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPatrols.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column21});
            dataGridViewCellStyle295.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle295.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle295.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle295.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle295.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(165)))), ((int)(((byte)(129)))));
            dataGridViewCellStyle295.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle295.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewPatrols.DefaultCellStyle = dataGridViewCellStyle295;
            this.dataGridViewPatrols.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(213)))));
            this.dataGridViewPatrols.Location = new System.Drawing.Point(4, 4);
            this.dataGridViewPatrols.Name = "dataGridViewPatrols";
            dataGridViewCellStyle296.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle296.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(121)))), ((int)(((byte)(67)))));
            dataGridViewCellStyle296.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle296.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle296.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(143)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle296.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle296.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewPatrols.RowHeadersDefaultCellStyle = dataGridViewCellStyle296;
            this.dataGridViewPatrols.Size = new System.Drawing.Size(423, 162);
            this.dataGridViewPatrols.TabIndex = 1;
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.DarkBlue;
            this.panelTop.Controls.Add(this.pictureChecked);
            this.panelTop.Controls.Add(this.trophy);
            this.panelTop.Controls.Add(this.PPGiven);
            this.panelTop.Controls.Add(this.greenAdjutant);
            this.panelTop.Controls.Add(this.epaulet);
            this.panelTop.Controls.Add(this.PPOpen);
            this.panelTop.Controls.Add(this.PZGiven);
            this.panelTop.Controls.Add(this.brownMaster);
            this.panelTop.Controls.Add(this.ZSGiven);
            this.panelTop.Controls.Add(this.secondOpen);
            this.panelTop.Controls.Add(this.secondGiven);
            this.panelTop.Controls.Add(this.ZSinvite);
            this.panelTop.Controls.Add(this.PZinvite);
            this.panelTop.Controls.Add(this.cross);
            this.panelTop.Controls.Add(this.firstGive);
            this.panelTop.Controls.Add(this.shawl);
            this.panelTop.Controls.Add(this.firstOpen);
            this.panelTop.Controls.Add(this.transparent);
            this.panelTop.Controls.Add(this.dataGridViewTroop);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(864, 341);
            this.panelTop.TabIndex = 0;
            // 
            // firstOpen
            // 
            this.firstOpen.BackColor = System.Drawing.Color.White;
            this.firstOpen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("firstOpen.BackgroundImage")));
            this.firstOpen.Location = new System.Drawing.Point(24, 128);
            this.firstOpen.Name = "firstOpen";
            this.firstOpen.Size = new System.Drawing.Size(32, 28);
            this.firstOpen.TabIndex = 2;
            this.firstOpen.TabStop = false;
            this.firstOpen.Visible = false;
            // 
            // transparent
            // 
            this.transparent.BackColor = System.Drawing.Color.White;
            this.transparent.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("transparent.BackgroundImage")));
            this.transparent.Location = new System.Drawing.Point(24, 94);
            this.transparent.Name = "transparent";
            this.transparent.Size = new System.Drawing.Size(32, 28);
            this.transparent.TabIndex = 1;
            this.transparent.TabStop = false;
            this.transparent.Visible = false;
            // 
            // dataGridViewTroop
            // 
            dataGridViewCellStyle297.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle297.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(213)))));
            dataGridViewCellStyle297.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle297.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle297.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(165)))), ((int)(((byte)(129)))));
            dataGridViewCellStyle297.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewTroop.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle297;
            this.dataGridViewTroop.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(238)))), ((int)(((byte)(231)))));
            this.dataGridViewTroop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewTroop.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle298.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle298.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(87)))), ((int)(((byte)(27)))));
            dataGridViewCellStyle298.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle298.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle298.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(143)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle298.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle298.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTroop.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle298;
            this.dataGridViewTroop.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTroop.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column20});
            dataGridViewCellStyle299.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle299.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle299.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle299.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle299.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(165)))), ((int)(((byte)(129)))));
            dataGridViewCellStyle299.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle299.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTroop.DefaultCellStyle = dataGridViewCellStyle299;
            this.dataGridViewTroop.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(213)))));
            this.dataGridViewTroop.Location = new System.Drawing.Point(4, 4);
            this.dataGridViewTroop.Name = "dataGridViewTroop";
            dataGridViewCellStyle300.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle300.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(121)))), ((int)(((byte)(67)))));
            dataGridViewCellStyle300.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle300.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle300.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(143)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle300.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle300.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTroop.RowHeadersDefaultCellStyle = dataGridViewCellStyle300;
            this.dataGridViewTroop.Size = new System.Drawing.Size(857, 333);
            this.dataGridViewTroop.TabIndex = 0;
            this.dataGridViewTroop.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // shawl
            // 
            this.shawl.BackColor = System.Drawing.Color.White;
            this.shawl.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("shawl.BackgroundImage")));
            this.shawl.Location = new System.Drawing.Point(24, 162);
            this.shawl.Name = "shawl";
            this.shawl.Size = new System.Drawing.Size(32, 28);
            this.shawl.TabIndex = 3;
            this.shawl.TabStop = false;
            this.shawl.Visible = false;
            // 
            // firstGive
            // 
            this.firstGive.BackColor = System.Drawing.Color.White;
            this.firstGive.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("firstGive.BackgroundImage")));
            this.firstGive.Location = new System.Drawing.Point(24, 196);
            this.firstGive.Name = "firstGive";
            this.firstGive.Size = new System.Drawing.Size(32, 28);
            this.firstGive.TabIndex = 4;
            this.firstGive.TabStop = false;
            this.firstGive.Visible = false;
            // 
            // cross
            // 
            this.cross.BackColor = System.Drawing.Color.White;
            this.cross.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cross.BackgroundImage")));
            this.cross.Location = new System.Drawing.Point(24, 230);
            this.cross.Name = "cross";
            this.cross.Size = new System.Drawing.Size(32, 28);
            this.cross.TabIndex = 5;
            this.cross.TabStop = false;
            this.cross.Visible = false;
            // 
            // PZinvite
            // 
            this.PZinvite.BackColor = System.Drawing.Color.White;
            this.PZinvite.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PZinvite.BackgroundImage")));
            this.PZinvite.Location = new System.Drawing.Point(24, 264);
            this.PZinvite.Name = "PZinvite";
            this.PZinvite.Size = new System.Drawing.Size(32, 28);
            this.PZinvite.TabIndex = 6;
            this.PZinvite.TabStop = false;
            this.PZinvite.Visible = false;
            // 
            // ZSinvite
            // 
            this.ZSinvite.BackColor = System.Drawing.Color.White;
            this.ZSinvite.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ZSinvite.BackgroundImage")));
            this.ZSinvite.Location = new System.Drawing.Point(62, 94);
            this.ZSinvite.Name = "ZSinvite";
            this.ZSinvite.Size = new System.Drawing.Size(32, 28);
            this.ZSinvite.TabIndex = 7;
            this.ZSinvite.TabStop = false;
            this.ZSinvite.Visible = false;
            // 
            // secondGiven
            // 
            this.secondGiven.BackColor = System.Drawing.Color.White;
            this.secondGiven.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("secondGiven.BackgroundImage")));
            this.secondGiven.Location = new System.Drawing.Point(62, 128);
            this.secondGiven.Name = "secondGiven";
            this.secondGiven.Size = new System.Drawing.Size(32, 28);
            this.secondGiven.TabIndex = 8;
            this.secondGiven.TabStop = false;
            this.secondGiven.Visible = false;
            // 
            // secondOpen
            // 
            this.secondOpen.BackColor = System.Drawing.Color.White;
            this.secondOpen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("secondOpen.BackgroundImage")));
            this.secondOpen.Location = new System.Drawing.Point(62, 162);
            this.secondOpen.Name = "secondOpen";
            this.secondOpen.Size = new System.Drawing.Size(32, 28);
            this.secondOpen.TabIndex = 9;
            this.secondOpen.TabStop = false;
            this.secondOpen.Visible = false;
            // 
            // ZSGiven
            // 
            this.ZSGiven.BackColor = System.Drawing.Color.White;
            this.ZSGiven.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ZSGiven.BackgroundImage")));
            this.ZSGiven.Location = new System.Drawing.Point(62, 196);
            this.ZSGiven.Name = "ZSGiven";
            this.ZSGiven.Size = new System.Drawing.Size(32, 28);
            this.ZSGiven.TabIndex = 10;
            this.ZSGiven.TabStop = false;
            this.ZSGiven.Visible = false;
            // 
            // brownMaster
            // 
            this.brownMaster.BackColor = System.Drawing.Color.White;
            this.brownMaster.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("brownMaster.BackgroundImage")));
            this.brownMaster.Location = new System.Drawing.Point(62, 230);
            this.brownMaster.Name = "brownMaster";
            this.brownMaster.Size = new System.Drawing.Size(32, 28);
            this.brownMaster.TabIndex = 11;
            this.brownMaster.TabStop = false;
            this.brownMaster.Visible = false;
            // 
            // PZGiven
            // 
            this.PZGiven.BackColor = System.Drawing.Color.White;
            this.PZGiven.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PZGiven.BackgroundImage")));
            this.PZGiven.Location = new System.Drawing.Point(62, 264);
            this.PZGiven.Name = "PZGiven";
            this.PZGiven.Size = new System.Drawing.Size(32, 28);
            this.PZGiven.TabIndex = 12;
            this.PZGiven.TabStop = false;
            this.PZGiven.Visible = false;
            // 
            // PPOpen
            // 
            this.PPOpen.BackColor = System.Drawing.Color.White;
            this.PPOpen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PPOpen.BackgroundImage")));
            this.PPOpen.Location = new System.Drawing.Point(100, 94);
            this.PPOpen.Name = "PPOpen";
            this.PPOpen.Size = new System.Drawing.Size(32, 28);
            this.PPOpen.TabIndex = 13;
            this.PPOpen.TabStop = false;
            this.PPOpen.Visible = false;
            // 
            // epaulet
            // 
            this.epaulet.BackColor = System.Drawing.Color.White;
            this.epaulet.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("epaulet.BackgroundImage")));
            this.epaulet.Location = new System.Drawing.Point(100, 128);
            this.epaulet.Name = "epaulet";
            this.epaulet.Size = new System.Drawing.Size(32, 28);
            this.epaulet.TabIndex = 14;
            this.epaulet.TabStop = false;
            this.epaulet.Visible = false;
            // 
            // greenAdjutant
            // 
            this.greenAdjutant.BackColor = System.Drawing.Color.White;
            this.greenAdjutant.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("greenAdjutant.BackgroundImage")));
            this.greenAdjutant.Location = new System.Drawing.Point(100, 162);
            this.greenAdjutant.Name = "greenAdjutant";
            this.greenAdjutant.Size = new System.Drawing.Size(32, 28);
            this.greenAdjutant.TabIndex = 15;
            this.greenAdjutant.TabStop = false;
            this.greenAdjutant.Visible = false;
            // 
            // PPGiven
            // 
            this.PPGiven.BackColor = System.Drawing.Color.White;
            this.PPGiven.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PPGiven.BackgroundImage")));
            this.PPGiven.Location = new System.Drawing.Point(100, 196);
            this.PPGiven.Name = "PPGiven";
            this.PPGiven.Size = new System.Drawing.Size(32, 28);
            this.PPGiven.TabIndex = 16;
            this.PPGiven.TabStop = false;
            this.PPGiven.Visible = false;
            // 
            // trophy
            // 
            this.trophy.BackColor = System.Drawing.Color.White;
            this.trophy.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("trophy.BackgroundImage")));
            this.trophy.Location = new System.Drawing.Point(100, 230);
            this.trophy.Name = "trophy";
            this.trophy.Size = new System.Drawing.Size(32, 28);
            this.trophy.TabIndex = 17;
            this.trophy.TabStop = false;
            this.trophy.Visible = false;
            // 
            // pictureChecked
            // 
            this.pictureChecked.BackColor = System.Drawing.Color.White;
            this.pictureChecked.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureChecked.BackgroundImage")));
            this.pictureChecked.Location = new System.Drawing.Point(100, 264);
            this.pictureChecked.Name = "pictureChecked";
            this.pictureChecked.Size = new System.Drawing.Size(32, 28);
            this.pictureChecked.TabIndex = 18;
            this.pictureChecked.TabStop = false;
            this.pictureChecked.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 355F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Ksywka/Imię";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 380;
            // 
            // Column22
            // 
            this.Column22.HeaderText = "Index";
            this.Column22.Name = "Column22";
            this.Column22.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 355F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Ksywka/Imię";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 380;
            // 
            // Column24
            // 
            this.Column24.HeaderText = "Index";
            this.Column24.Name = "Column24";
            this.Column24.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 355F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Ksywka/Imię";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 380;
            // 
            // Column23
            // 
            this.Column23.HeaderText = "Index";
            this.Column23.Name = "Column23";
            this.Column23.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(12, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Przyciski zarądzające";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.removeMember);
            this.panel1.Controls.Add(this.removeHelper);
            this.panel1.Controls.Add(this.makeHelper);
            this.panel1.Controls.Add(this.addToPatrol);
            this.panel1.Controls.Add(this.removeFromPatrol);
            this.panel1.Controls.Add(this.makeAdjutant);
            this.panel1.Controls.Add(this.removeAdjutant);
            this.panel1.Controls.Add(this.makeMaster);
            this.panel1.Controls.Add(this.removeMaster);
            this.panel1.Controls.Add(this.addPatrol);
            this.panel1.Controls.Add(this.removePatrol);
            this.panel1.Location = new System.Drawing.Point(0, 44);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 301);
            this.panel1.TabIndex = 12;
            // 
            // removeHelper
            // 
            this.removeHelper.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.removeHelper.Dock = System.Windows.Forms.DockStyle.Top;
            this.removeHelper.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.removeHelper.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.removeHelper.ForeColor = System.Drawing.Color.White;
            this.removeHelper.Location = new System.Drawing.Point(0, 189);
            this.removeHelper.Name = "removeHelper";
            this.removeHelper.Size = new System.Drawing.Size(200, 21);
            this.removeHelper.TabIndex = 11;
            this.removeHelper.Text = "Usuń podzastępowego";
            this.removeHelper.UseVisualStyleBackColor = false;
            this.removeHelper.Click += new System.EventHandler(this.removeHelper_Click);
            // 
            // makeHelper
            // 
            this.makeHelper.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.makeHelper.Dock = System.Windows.Forms.DockStyle.Top;
            this.makeHelper.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.makeHelper.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.makeHelper.ForeColor = System.Drawing.Color.White;
            this.makeHelper.Location = new System.Drawing.Point(0, 168);
            this.makeHelper.Name = "makeHelper";
            this.makeHelper.Size = new System.Drawing.Size(200, 21);
            this.makeHelper.TabIndex = 10;
            this.makeHelper.Text = "Mianuj podzastępowym";
            this.makeHelper.UseVisualStyleBackColor = false;
            this.makeHelper.Click += new System.EventHandler(this.makeHelper_Click);
            // 
            // addToPatrol
            // 
            this.addToPatrol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.addToPatrol.Dock = System.Windows.Forms.DockStyle.Top;
            this.addToPatrol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addToPatrol.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.addToPatrol.ForeColor = System.Drawing.Color.White;
            this.addToPatrol.Location = new System.Drawing.Point(0, 147);
            this.addToPatrol.Name = "addToPatrol";
            this.addToPatrol.Size = new System.Drawing.Size(200, 21);
            this.addToPatrol.TabIndex = 9;
            this.addToPatrol.Text = "Dodaj do zastępu";
            this.addToPatrol.UseVisualStyleBackColor = false;
            this.addToPatrol.Click += new System.EventHandler(this.addToPatrol_Click);
            // 
            // removeFromPatrol
            // 
            this.removeFromPatrol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.removeFromPatrol.Dock = System.Windows.Forms.DockStyle.Top;
            this.removeFromPatrol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.removeFromPatrol.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.removeFromPatrol.ForeColor = System.Drawing.Color.White;
            this.removeFromPatrol.Location = new System.Drawing.Point(0, 126);
            this.removeFromPatrol.Name = "removeFromPatrol";
            this.removeFromPatrol.Size = new System.Drawing.Size(200, 21);
            this.removeFromPatrol.TabIndex = 8;
            this.removeFromPatrol.Text = "Usuń z zastępu";
            this.removeFromPatrol.UseVisualStyleBackColor = false;
            this.removeFromPatrol.Click += new System.EventHandler(this.removeFromPatrol_Click);
            // 
            // makeAdjutant
            // 
            this.makeAdjutant.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.makeAdjutant.Dock = System.Windows.Forms.DockStyle.Top;
            this.makeAdjutant.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.makeAdjutant.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.makeAdjutant.ForeColor = System.Drawing.Color.White;
            this.makeAdjutant.Location = new System.Drawing.Point(0, 105);
            this.makeAdjutant.Name = "makeAdjutant";
            this.makeAdjutant.Size = new System.Drawing.Size(200, 21);
            this.makeAdjutant.TabIndex = 7;
            this.makeAdjutant.Text = "Mianuj przybocznym";
            this.makeAdjutant.UseVisualStyleBackColor = false;
            this.makeAdjutant.Click += new System.EventHandler(this.makeAdjutant_Click);
            // 
            // removeAdjutant
            // 
            this.removeAdjutant.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.removeAdjutant.Dock = System.Windows.Forms.DockStyle.Top;
            this.removeAdjutant.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.removeAdjutant.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.removeAdjutant.ForeColor = System.Drawing.Color.White;
            this.removeAdjutant.Location = new System.Drawing.Point(0, 84);
            this.removeAdjutant.Name = "removeAdjutant";
            this.removeAdjutant.Size = new System.Drawing.Size(200, 21);
            this.removeAdjutant.TabIndex = 6;
            this.removeAdjutant.Text = "Usuń przybocznego";
            this.removeAdjutant.UseVisualStyleBackColor = false;
            this.removeAdjutant.Click += new System.EventHandler(this.removeAdjutant_Click);
            // 
            // makeMaster
            // 
            this.makeMaster.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.makeMaster.Dock = System.Windows.Forms.DockStyle.Top;
            this.makeMaster.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.makeMaster.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.makeMaster.ForeColor = System.Drawing.Color.White;
            this.makeMaster.Location = new System.Drawing.Point(0, 63);
            this.makeMaster.Name = "makeMaster";
            this.makeMaster.Size = new System.Drawing.Size(200, 21);
            this.makeMaster.TabIndex = 5;
            this.makeMaster.Text = "Mianuj zastępowym";
            this.makeMaster.UseVisualStyleBackColor = false;
            this.makeMaster.Click += new System.EventHandler(this.makeMaster_Click);
            // 
            // removeMaster
            // 
            this.removeMaster.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.removeMaster.Dock = System.Windows.Forms.DockStyle.Top;
            this.removeMaster.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.removeMaster.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.removeMaster.ForeColor = System.Drawing.Color.White;
            this.removeMaster.Location = new System.Drawing.Point(0, 42);
            this.removeMaster.Name = "removeMaster";
            this.removeMaster.Size = new System.Drawing.Size(200, 21);
            this.removeMaster.TabIndex = 4;
            this.removeMaster.Text = "Usuń zastępowego";
            this.removeMaster.UseVisualStyleBackColor = false;
            this.removeMaster.Click += new System.EventHandler(this.removeMaster_Click);
            // 
            // addPatrol
            // 
            this.addPatrol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.addPatrol.Dock = System.Windows.Forms.DockStyle.Top;
            this.addPatrol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addPatrol.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.addPatrol.ForeColor = System.Drawing.Color.White;
            this.addPatrol.Location = new System.Drawing.Point(0, 21);
            this.addPatrol.Name = "addPatrol";
            this.addPatrol.Size = new System.Drawing.Size(200, 21);
            this.addPatrol.TabIndex = 3;
            this.addPatrol.Text = "Dodaj zastęp";
            this.addPatrol.UseVisualStyleBackColor = false;
            this.addPatrol.Click += new System.EventHandler(this.addPatrol_Click);
            // 
            // removePatrol
            // 
            this.removePatrol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.removePatrol.Dock = System.Windows.Forms.DockStyle.Top;
            this.removePatrol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.removePatrol.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.removePatrol.ForeColor = System.Drawing.Color.White;
            this.removePatrol.Location = new System.Drawing.Point(0, 0);
            this.removePatrol.Name = "removePatrol";
            this.removePatrol.Size = new System.Drawing.Size(200, 21);
            this.removePatrol.TabIndex = 2;
            this.removePatrol.Text = "Usuń zastęp";
            this.removePatrol.UseVisualStyleBackColor = false;
            this.removePatrol.Click += new System.EventHandler(this.removePatrol_Click);
            // 
            // removeMember
            // 
            this.removeMember.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.removeMember.Dock = System.Windows.Forms.DockStyle.Top;
            this.removeMember.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.removeMember.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.removeMember.ForeColor = System.Drawing.Color.White;
            this.removeMember.Location = new System.Drawing.Point(0, 210);
            this.removeMember.Name = "removeMember";
            this.removeMember.Size = new System.Drawing.Size(200, 21);
            this.removeMember.TabIndex = 12;
            this.removeMember.Text = "Usuń z drużyny";
            this.removeMember.UseVisualStyleBackColor = false;
            this.removeMember.Click += new System.EventHandler(this.removeMember_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 16);
            this.label4.TabIndex = 12;
            this.label4.Text = "Przyciski akcji";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.ZSstart);
            this.panel2.Controls.Add(this.PZstart);
            this.panel2.Controls.Add(this.PPstart);
            this.panel2.Location = new System.Drawing.Point(0, 27);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 111);
            this.panel2.TabIndex = 13;
            // 
            // ZSstart
            // 
            this.ZSstart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.ZSstart.Dock = System.Windows.Forms.DockStyle.Top;
            this.ZSstart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ZSstart.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ZSstart.ForeColor = System.Drawing.Color.White;
            this.ZSstart.Location = new System.Drawing.Point(0, 42);
            this.ZSstart.Name = "ZSstart";
            this.ZSstart.Size = new System.Drawing.Size(200, 21);
            this.ZSstart.TabIndex = 5;
            this.ZSstart.Text = "Wyślij na ZS";
            this.ZSstart.UseVisualStyleBackColor = false;
            this.ZSstart.Click += new System.EventHandler(this.ZSstart_Click);
            // 
            // PZstart
            // 
            this.PZstart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.PZstart.Dock = System.Windows.Forms.DockStyle.Top;
            this.PZstart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.PZstart.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PZstart.ForeColor = System.Drawing.Color.White;
            this.PZstart.Location = new System.Drawing.Point(0, 21);
            this.PZstart.Name = "PZstart";
            this.PZstart.Size = new System.Drawing.Size(200, 21);
            this.PZstart.TabIndex = 4;
            this.PZstart.Text = "Wyślij na PZ";
            this.PZstart.UseVisualStyleBackColor = false;
            this.PZstart.Click += new System.EventHandler(this.PZstart_Click);
            // 
            // PPstart
            // 
            this.PPstart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.PPstart.Dock = System.Windows.Forms.DockStyle.Top;
            this.PPstart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.PPstart.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PPstart.ForeColor = System.Drawing.Color.White;
            this.PPstart.Location = new System.Drawing.Point(0, 0);
            this.PPstart.Name = "PPstart";
            this.PPstart.Size = new System.Drawing.Size(200, 21);
            this.PPstart.TabIndex = 3;
            this.PPstart.Text = "Wyślij na PP";
            this.PPstart.UseVisualStyleBackColor = false;
            this.PPstart.Click += new System.EventHandler(this.PPstart_Click);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Ksywka/Imię";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Wiek";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 50;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Etap";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 50;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Czas bez rozwoju";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 75;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Instruktor?";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 85;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Wędrownik?";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 95;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "";
            this.Column7.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column7.Width = 22;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "";
            this.Column8.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column8.Width = 22;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "";
            this.Column9.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column9.Width = 22;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "";
            this.Column10.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column10.Width = 22;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Drużynowy?";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 95;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "Przyboczny?";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 95;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Zastępowy?";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Width = 95;
            // 
            // Column14
            // 
            this.Column14.FillWeight = 110F;
            this.Column14.HeaderText = "Podzastępowy?";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.Width = 110;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "Członek zastępu?";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Width = 95;
            // 
            // Column20
            // 
            this.Column20.HeaderText = "Index";
            this.Column20.Name = "Column20";
            // 
            // Column16
            // 
            this.Column16.HeaderText = "Nazwa";
            this.Column16.Name = "Column16";
            this.Column16.Width = 200;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Zastępowy";
            this.Column17.Name = "Column17";
            // 
            // Column18
            // 
            this.Column18.FillWeight = 110F;
            this.Column18.HeaderText = "Podzastępowy";
            this.Column18.Name = "Column18";
            this.Column18.Width = 110;
            // 
            // Column19
            // 
            this.Column19.HeaderText = "Członkowie";
            this.Column19.Name = "Column19";
            this.Column19.Text = "Zobacz";
            // 
            // Column21
            // 
            this.Column21.HeaderText = "Index";
            this.Column21.Name = "Column21";
            // 
            // scoutTroopBindingSource1
            // 
            this.scoutTroopBindingSource1.DataSource = typeof(SYMULATOR_DRUZYNY_HARCERSKIEJ.ScoutTroop);
            // 
            // scoutTroopBindingSource
            // 
            this.scoutTroopBindingSource.DataSource = typeof(SYMULATOR_DRUZYNY_HARCERSKIEJ.ScoutTroop);
            // 
            // scoutTroopBindingSource2
            // 
            this.scoutTroopBindingSource2.DataSource = typeof(SYMULATOR_DRUZYNY_HARCERSKIEJ.ScoutTroop);
            // 
            // scoutBindingSource
            // 
            this.scoutBindingSource.DataSource = typeof(SYMULATOR_DRUZYNY_HARCERSKIEJ.Scout);
            // 
            // scoutBindingSource1
            // 
            this.scoutBindingSource1.DataSource = typeof(SYMULATOR_DRUZYNY_HARCERSKIEJ.Scout);
            // 
            // scoutTroopBindingSource3
            // 
            this.scoutTroopBindingSource3.DataSource = typeof(SYMULATOR_DRUZYNY_HARCERSKIEJ.ScoutTroop);
            // 
            // scoutTroopBindingSource4
            // 
            this.scoutTroopBindingSource4.DataSource = typeof(SYMULATOR_DRUZYNY_HARCERSKIEJ.ScoutTroop);
            // 
            // ProsectTroop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(181)))), ((int)(((byte)(68)))));
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelRight);
            this.Controls.Add(this.panelLeft);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ProsectTroop";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ProsectTroop";
            this.Shown += new System.EventHandler(this.ProsectTroop_Shown);
            this.panelLeft.ResumeLayout(false);
            this.panelLeft.PerformLayout();
            this.panelLeftBottom.ResumeLayout(false);
            this.panelLeftBottom.PerformLayout();
            this.panelRight.ResumeLayout(false);
            this.panelRightBottom.ResumeLayout(false);
            this.panelRightBottom.PerformLayout();
            this.panelMain.ResumeLayout(false);
            this.panelHelpers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHelpers)).EndInit();
            this.panelAdjutants.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdjutants)).EndInit();
            this.panelMasters.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMasters)).EndInit();
            this.panelPatrols.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPatrols)).EndInit();
            this.panelTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.firstOpen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.transparent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTroop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shawl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstGive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cross)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PZinvite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZSinvite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondGiven)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondOpen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZSGiven)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brownMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PZGiven)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PPOpen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.epaulet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenAdjutant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PPGiven)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trophy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureChecked)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scoutTroopBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutTroopBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutTroopBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutTroopBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scoutTroopBindingSource4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Panel panelLeftBottom;
        private System.Windows.Forms.Panel panelRight;
        private System.Windows.Forms.Panel panelRightBottom;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel panelHelpers;
        private System.Windows.Forms.Panel panelAdjutants;
        private System.Windows.Forms.Panel panelMasters;
        private System.Windows.Forms.Panel panelPatrols;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.DataGridView dataGridViewTroop;
        private System.Windows.Forms.BindingSource scoutTroopBindingSource;
        private System.Windows.Forms.BindingSource scoutTroopBindingSource1;
        private System.Windows.Forms.Label labelPatrols;
        private System.Windows.Forms.Label labelTroop;
        private System.Windows.Forms.Label labelMasters;
        private System.Windows.Forms.DataGridView dataGridViewPatrols;
        private System.Windows.Forms.DataGridView dataGridViewMasters;
        private System.Windows.Forms.DataGridView dataGridViewHelpers;
        private System.Windows.Forms.DataGridView dataGridViewAdjutants;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox firstOpen;
        private System.Windows.Forms.PictureBox transparent;
        private System.Windows.Forms.PictureBox trophy;
        private System.Windows.Forms.PictureBox PPGiven;
        private System.Windows.Forms.PictureBox greenAdjutant;
        private System.Windows.Forms.PictureBox epaulet;
        private System.Windows.Forms.PictureBox PPOpen;
        private System.Windows.Forms.PictureBox PZGiven;
        private System.Windows.Forms.PictureBox brownMaster;
        private System.Windows.Forms.PictureBox ZSGiven;
        private System.Windows.Forms.PictureBox secondOpen;
        private System.Windows.Forms.PictureBox secondGiven;
        private System.Windows.Forms.PictureBox ZSinvite;
        private System.Windows.Forms.PictureBox PZinvite;
        private System.Windows.Forms.PictureBox cross;
        private System.Windows.Forms.PictureBox firstGive;
        private System.Windows.Forms.PictureBox shawl;
        private System.Windows.Forms.PictureBox pictureChecked;
        private System.Windows.Forms.BindingSource scoutTroopBindingSource2;
        private System.Windows.Forms.BindingSource scoutBindingSource;
        private System.Windows.Forms.BindingSource scoutBindingSource1;
        private System.Windows.Forms.BindingSource scoutTroopBindingSource3;
        private System.Windows.Forms.BindingSource scoutTroopBindingSource4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button removeMember;
        private System.Windows.Forms.Button removeHelper;
        private System.Windows.Forms.Button makeHelper;
        private System.Windows.Forms.Button addToPatrol;
        private System.Windows.Forms.Button removeFromPatrol;
        private System.Windows.Forms.Button makeAdjutant;
        private System.Windows.Forms.Button removeAdjutant;
        private System.Windows.Forms.Button makeMaster;
        private System.Windows.Forms.Button removeMaster;
        private System.Windows.Forms.Button addPatrol;
        private System.Windows.Forms.Button removePatrol;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button ZSstart;
        private System.Windows.Forms.Button PZstart;
        private System.Windows.Forms.Button PPstart;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewImageColumn Column7;
        private System.Windows.Forms.DataGridViewImageColumn Column8;
        private System.Windows.Forms.DataGridViewImageColumn Column9;
        private System.Windows.Forms.DataGridViewImageColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewButtonColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
    }
}