﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public class Patrol
    {
        public string name;

        /// <summary>
        ///Pointer to one Scout in list in scout troop
        /// </summary>
        public Scout patrolMaster = null;
        public Scout patrolHelper = null;

        /// <summary>
        ///Pointer list to members of this patrol
        /// </summary>
        public List<Scout> Members = new List<Scout>();

        public Patrol(string name)
        {
            this.name = name;
        }
    }
}
