﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public partial class DiceRoller : Form
    {
        Game game;
        int dicePoints;
        string raport;
        int diceCounter;
        Random rnd = new Random();
        string word;

        public DiceRoller(Game game)
        {
            InitializeComponent();
            this.game = game;
            this.Text = game.randomAdage();
            diceCounter = 0;
        }

        private void pictureDice_Click(object sender, EventArgs e)
        {
            dicePoints = rnd.Next(6) + 1;
            diceCounter++;

            if (dicePoints == 1) word = " oczko.";
            else if (dicePoints > 1 && dicePoints < 5) word = " oczka.";
            else word = " oczek.";

            if (diceCounter == 1)
            {
                game.scoutTroop.actionPoints += dicePoints;
                buttonZrezygnuj.Visible = true;
                raport = "Wyrzucono " + dicePoints + word + " Za 2 PR\nmożna dokupić jeden dodatkowy\nrzut na półrocze (Mobilizacja).";
            }
            else if (diceCounter == 2)
            {
                if (game.scoutTroop.actionPoints >= 2)
                {
                    game.scoutTroop.actionPoints += dicePoints - 2;
                    raport = "Wyrzucono " + dicePoints + word;
                }
                else
                {
                    raport = "Masz za mało punktów!";
                }
                buttonZrezygnuj.Text = "Zostaw kostkę w spokoju";
            }

            labelQuestion.Text = raport;
            labelQuestion.Left = (500 - labelQuestion.Width) / 2;
            game.scoutTroop.countPoints();
        }

        private void buttonZrezygnuj_MouseEnter(object sender, EventArgs e)
        {
            buttonZrezygnuj.BackColor = Color.FromArgb(194, 210, 242);
        }

        private void buttonZrezygnuj_MouseLeave(object sender, EventArgs e)
        {
            buttonZrezygnuj.BackColor = Color.FromArgb(81, 118, 166);
        }

        private void buttonZrezygnuj_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void DiceRoller_Load(object sender, EventArgs e)
        {

        }
    }
}
