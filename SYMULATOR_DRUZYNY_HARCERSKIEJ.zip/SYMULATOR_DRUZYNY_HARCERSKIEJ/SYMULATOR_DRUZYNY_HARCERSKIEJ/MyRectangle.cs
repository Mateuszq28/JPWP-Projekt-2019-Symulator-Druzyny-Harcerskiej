﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public class MyRectangle
    {
        public Point leftHigh;
        public Point leftDown;
        public Point rightDown;
        public Point rightHigh;
        public int memory = 0;
        public Rectangle drawRec;

        //path Points
        public Point topMiddle;
        public Point bottomMiddle;
        public Point leftMiddle;
        public Point rightMiddle;

        private void makePathPoints()
        {
            topMiddle.Y = leftHigh.Y;
            topMiddle.X = (rightHigh.X - leftHigh.X)/2 + leftHigh.X;
            bottomMiddle.Y = leftDown.Y;
            bottomMiddle.X = (rightDown.X - leftDown.X)/2 + leftDown.X;

            leftMiddle.X = leftHigh.X;
            leftMiddle.Y = (leftDown.Y - leftHigh.Y)/2 + leftHigh.Y;
            rightMiddle.X = rightDown.X;
            rightMiddle.Y = (rightDown.Y - rightHigh.Y)/2 + rightHigh.Y;
        }

        private void makeDrawRec()
        {
            drawRec.Location = leftHigh;
            drawRec.Width = rightHigh.X - leftHigh.X;
            drawRec.Height = leftDown.Y - leftHigh.Y;
        }

        private void setProperties()
        {
            makeDrawRec();
            makePathPoints();
        }

        public MyRectangle()
        {

        }

        public MyRectangle(int x, int y, int width, int height)
        {
            this.leftHigh.X = x;
            this.leftHigh.Y = y;

            this.leftDown.X = x;
            this.leftDown.Y = y + height;

            this.rightDown.X = x + width;
            this.rightDown.Y = y + height;

            this.rightHigh.X = x + width;
            this.rightHigh.Y = y;

            setProperties();
        }

        public MyRectangle(Point leftHigh, Point leftDown, Point rightDown, Point rightHigh)
        {
            this.leftHigh = leftHigh;
            this.leftDown = leftDown;
            this.rightDown = rightDown;
            this.rightHigh = rightHigh;
            setProperties();
        }
        public MyRectangle(MyRectangle r)
        {
            this.leftHigh = r.leftHigh;
            this.rightDown = r.rightDown;
            this.leftDown.X = r.leftHigh.X;
            this.leftDown.Y = r.rightDown.Y;
            this.rightHigh.X = r.rightDown.X;
            this.rightHigh.Y = r.leftHigh.Y;
            setProperties();
        }

        public MyRectangle(int num)
        {
            this.memory = num;
        }

        public MyRectangle(Rectangle r)
        {
            this.leftHigh = r.Location;
            this.leftDown.X = r.Left;
            this.leftDown.Y = r.Bottom;
            this.rightDown.X = r.Right;
            this.rightDown.Y = r.Bottom;
            this.rightHigh.X = r.Right;
            this.rightHigh.Y = r.Top;
            setProperties();
        }

    }
}
