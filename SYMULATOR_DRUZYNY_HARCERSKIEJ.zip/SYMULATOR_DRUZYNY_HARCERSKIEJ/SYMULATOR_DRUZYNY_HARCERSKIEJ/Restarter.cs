﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public partial class Restarter : Form
    {
        Game game;
        public Restarter(Game game)
        {
            InitializeComponent();
            this.game = game;
            this.Text = game.randomAdage();

            MessageBox.Show("Brawo! Udało Ci się zdobyć " + game.scoutTroop.points + " punktów, a Twoja drużyna liczy " + game.scoutTroop.membersCounter + "osób.", "KONIEC GRY");
        }

        private void buttonYES_MouseEnter(object sender, EventArgs e)
        {
            buttonYES.BackColor = Color.FromArgb(194, 210, 242);
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            buttonNO.BackColor = Color.FromArgb(194, 210, 242);
        }

        private void buttonYES_MouseLeave(object sender, EventArgs e)
        {
            buttonYES.BackColor = Color.FromArgb(81, 118, 166);
        }

        private void buttonNO_MouseLeave(object sender, EventArgs e)
        {
            buttonNO.BackColor = Color.FromArgb(81, 118, 166);
        }

        private void buttonNO_Click(object sender, EventArgs e)
        {
            game.isRunning = true;
            this.DialogResult = DialogResult.OK;
        }

        private void buttonYES_Click(object sender, EventArgs e)
        {
            game.isStarted = false;
            this.DialogResult = DialogResult.OK;
        }
    }
}
