﻿namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    partial class home
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(home));
            this.panelSide = new System.Windows.Forms.Panel();
            this.card12 = new System.Windows.Forms.PictureBox();
            this.card11 = new System.Windows.Forms.PictureBox();
            this.card24 = new System.Windows.Forms.PictureBox();
            this.card23 = new System.Windows.Forms.PictureBox();
            this.card22 = new System.Windows.Forms.PictureBox();
            this.card21 = new System.Windows.Forms.PictureBox();
            this.card3r2 = new System.Windows.Forms.PictureBox();
            this.card3r1 = new System.Windows.Forms.PictureBox();
            this.card4r2 = new System.Windows.Forms.PictureBox();
            this.card4r1 = new System.Windows.Forms.PictureBox();
            this.card5 = new System.Windows.Forms.PictureBox();
            this.card4i3 = new System.Windows.Forms.PictureBox();
            this.card4i2 = new System.Windows.Forms.PictureBox();
            this.card4i1 = new System.Windows.Forms.PictureBox();
            this.card3i1 = new System.Windows.Forms.PictureBox();
            this.card3i2 = new System.Windows.Forms.PictureBox();
            this.card3i3 = new System.Windows.Forms.PictureBox();
            this.card3i4 = new System.Windows.Forms.PictureBox();
            this.labelExp = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelPoints = new System.Windows.Forms.Label();
            this.labelActionPoints = new System.Windows.Forms.Label();
            this.labelMemCount = new System.Windows.Forms.Label();
            this.labelAge = new System.Windows.Forms.Label();
            this.labelAlias = new System.Windows.Forms.Label();
            this.buttonPolrocze = new System.Windows.Forms.Button();
            this.buttonKursy = new System.Windows.Forms.Button();
            this.buttonAkcje = new System.Windows.Forms.Button();
            this.buttonDruzyna = new System.Windows.Forms.Button();
            this.buttonNewGame = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureLogo = new System.Windows.Forms.PictureBox();
            this.cardFrame = new System.Windows.Forms.PictureBox();
            this.picturePodglad0 = new System.Windows.Forms.PictureBox();
            this.panelMain = new System.Windows.Forms.Panel();
            this.GIRL1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxBuforing = new System.Windows.Forms.PictureBox();
            this.panelTop = new System.Windows.Forms.Panel();
            this.MAN5r = new System.Windows.Forms.PictureBox();
            this.MAN5i = new System.Windows.Forms.PictureBox();
            this.MAN4r = new System.Windows.Forms.PictureBox();
            this.MAN4i = new System.Windows.Forms.PictureBox();
            this.MAN3r = new System.Windows.Forms.PictureBox();
            this.MAN3i = new System.Windows.Forms.PictureBox();
            this.MAN2 = new System.Windows.Forms.PictureBox();
            this.MAN1 = new System.Windows.Forms.PictureBox();
            this.GIRL5r = new System.Windows.Forms.PictureBox();
            this.GIRL5i = new System.Windows.Forms.PictureBox();
            this.GIRL4r = new System.Windows.Forms.PictureBox();
            this.GIRL4i = new System.Windows.Forms.PictureBox();
            this.GIRL3r = new System.Windows.Forms.PictureBox();
            this.GIRL3i = new System.Windows.Forms.PictureBox();
            this.GIRL2 = new System.Windows.Forms.PictureBox();
            this.PPzdany = new System.Windows.Forms.PictureBox();
            this.zielonySznur = new System.Windows.Forms.PictureBox();
            this.PPproba = new System.Windows.Forms.PictureBox();
            this.PZzdany = new System.Windows.Forms.PictureBox();
            this.brazowySznur = new System.Windows.Forms.PictureBox();
            this.pagon = new System.Windows.Forms.PictureBox();
            this.IIzdany = new System.Windows.Forms.PictureBox();
            this.ZSzdany = new System.Windows.Forms.PictureBox();
            this.IIstopien = new System.Windows.Forms.PictureBox();
            this.ZSproba = new System.Windows.Forms.PictureBox();
            this.PZproba = new System.Windows.Forms.PictureBox();
            this.krzyz = new System.Windows.Forms.PictureBox();
            this.Izdany = new System.Windows.Forms.PictureBox();
            this.chusta = new System.Windows.Forms.PictureBox();
            this.Istopien = new System.Windows.Forms.PictureBox();
            this.checkSymbol = new System.Windows.Forms.PictureBox();
            this.Card5r = new System.Windows.Forms.PictureBox();
            this.Card5i = new System.Windows.Forms.PictureBox();
            this.Card4r = new System.Windows.Forms.PictureBox();
            this.Card4i = new System.Windows.Forms.PictureBox();
            this.Card3r = new System.Windows.Forms.PictureBox();
            this.Card3i = new System.Windows.Forms.PictureBox();
            this.Card2 = new System.Windows.Forms.PictureBox();
            this.Card1 = new System.Windows.Forms.PictureBox();
            this.labelTimer = new System.Windows.Forms.Label();
            this.pictureBoxStop = new System.Windows.Forms.PictureBox();
            this.pictureBoxFloor = new System.Windows.Forms.PictureBox();
            this.pictureBoxExit = new System.Windows.Forms.PictureBox();
            this.labelTitle = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelSide.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.card12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3r2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3r1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4r2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4r1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4i3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4i2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4i1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3i1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3i2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3i3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3i4)).BeginInit();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cardFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picturePodglad0)).BeginInit();
            this.panelMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBuforing)).BeginInit();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MAN5r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN5i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN4r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN4i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN3r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN3i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL5r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL5i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL4r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL4i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL3r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL3i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PPzdany)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zielonySznur)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PPproba)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PZzdany)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brazowySznur)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pagon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IIzdany)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZSzdany)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IIstopien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZSproba)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PZproba)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.krzyz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Izdany)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chusta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Istopien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkSymbol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card5r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card5i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card4r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card4i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card3r)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card3i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFloor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).BeginInit();
            this.SuspendLayout();
            // 
            // panelSide
            // 
            this.panelSide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(107)))), ((int)(((byte)(140)))));
            this.panelSide.Controls.Add(this.card12);
            this.panelSide.Controls.Add(this.card11);
            this.panelSide.Controls.Add(this.card24);
            this.panelSide.Controls.Add(this.card23);
            this.panelSide.Controls.Add(this.card22);
            this.panelSide.Controls.Add(this.card21);
            this.panelSide.Controls.Add(this.card3r2);
            this.panelSide.Controls.Add(this.card3r1);
            this.panelSide.Controls.Add(this.card4r2);
            this.panelSide.Controls.Add(this.card4r1);
            this.panelSide.Controls.Add(this.card5);
            this.panelSide.Controls.Add(this.card4i3);
            this.panelSide.Controls.Add(this.card4i2);
            this.panelSide.Controls.Add(this.card4i1);
            this.panelSide.Controls.Add(this.card3i1);
            this.panelSide.Controls.Add(this.card3i2);
            this.panelSide.Controls.Add(this.card3i3);
            this.panelSide.Controls.Add(this.card3i4);
            this.panelSide.Controls.Add(this.labelExp);
            this.panelSide.Controls.Add(this.labelName);
            this.panelSide.Controls.Add(this.labelPoints);
            this.panelSide.Controls.Add(this.labelActionPoints);
            this.panelSide.Controls.Add(this.labelMemCount);
            this.panelSide.Controls.Add(this.labelAge);
            this.panelSide.Controls.Add(this.labelAlias);
            this.panelSide.Controls.Add(this.buttonPolrocze);
            this.panelSide.Controls.Add(this.buttonKursy);
            this.panelSide.Controls.Add(this.buttonAkcje);
            this.panelSide.Controls.Add(this.buttonDruzyna);
            this.panelSide.Controls.Add(this.buttonNewGame);
            this.panelSide.Controls.Add(this.panelLogo);
            this.panelSide.Controls.Add(this.cardFrame);
            this.panelSide.Controls.Add(this.picturePodglad0);
            this.panelSide.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSide.Location = new System.Drawing.Point(0, 0);
            this.panelSide.Name = "panelSide";
            this.panelSide.Size = new System.Drawing.Size(200, 720);
            this.panelSide.TabIndex = 0;
            // 
            // card12
            // 
            this.card12.BackColor = System.Drawing.Color.White;
            this.card12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card12.BackgroundImage")));
            this.card12.Location = new System.Drawing.Point(70, 588);
            this.card12.Name = "card12";
            this.card12.Size = new System.Drawing.Size(60, 60);
            this.card12.TabIndex = 34;
            this.card12.TabStop = false;
            this.card12.Visible = false;
            this.card12.MouseClick += new System.Windows.Forms.MouseEventHandler(this.card12_MouseClick);
            // 
            // card11
            // 
            this.card11.BackColor = System.Drawing.Color.White;
            this.card11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card11.BackgroundImage")));
            this.card11.Location = new System.Drawing.Point(70, 476);
            this.card11.Name = "card11";
            this.card11.Size = new System.Drawing.Size(60, 60);
            this.card11.TabIndex = 33;
            this.card11.TabStop = false;
            this.card11.Visible = false;
            this.card11.Click += new System.EventHandler(this.card11_Click);
            // 
            // card24
            // 
            this.card24.BackColor = System.Drawing.Color.White;
            this.card24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card24.BackgroundImage")));
            this.card24.Location = new System.Drawing.Point(105, 616);
            this.card24.Name = "card24";
            this.card24.Size = new System.Drawing.Size(60, 60);
            this.card24.TabIndex = 32;
            this.card24.TabStop = false;
            this.card24.Visible = false;
            // 
            // card23
            // 
            this.card23.BackColor = System.Drawing.Color.White;
            this.card23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card23.BackgroundImage")));
            this.card23.Location = new System.Drawing.Point(34, 616);
            this.card23.Name = "card23";
            this.card23.Size = new System.Drawing.Size(60, 60);
            this.card23.TabIndex = 31;
            this.card23.TabStop = false;
            this.card23.Visible = false;
            // 
            // card22
            // 
            this.card22.BackColor = System.Drawing.Color.White;
            this.card22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card22.BackgroundImage")));
            this.card22.Location = new System.Drawing.Point(70, 532);
            this.card22.Name = "card22";
            this.card22.Size = new System.Drawing.Size(60, 60);
            this.card22.TabIndex = 30;
            this.card22.TabStop = false;
            this.card22.Visible = false;
            this.card22.Click += new System.EventHandler(this.card22_Click);
            // 
            // card21
            // 
            this.card21.BackColor = System.Drawing.Color.White;
            this.card21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card21.BackgroundImage")));
            this.card21.Location = new System.Drawing.Point(70, 448);
            this.card21.Name = "card21";
            this.card21.Size = new System.Drawing.Size(60, 60);
            this.card21.TabIndex = 29;
            this.card21.TabStop = false;
            this.card21.Visible = false;
            this.card21.Click += new System.EventHandler(this.card21_Click);
            // 
            // card3r2
            // 
            this.card3r2.BackColor = System.Drawing.Color.White;
            this.card3r2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card3r2.BackgroundImage")));
            this.card3r2.Location = new System.Drawing.Point(70, 588);
            this.card3r2.Name = "card3r2";
            this.card3r2.Size = new System.Drawing.Size(60, 60);
            this.card3r2.TabIndex = 28;
            this.card3r2.TabStop = false;
            this.card3r2.Visible = false;
            // 
            // card3r1
            // 
            this.card3r1.BackColor = System.Drawing.Color.White;
            this.card3r1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card3r1.BackgroundImage")));
            this.card3r1.Location = new System.Drawing.Point(70, 476);
            this.card3r1.Name = "card3r1";
            this.card3r1.Size = new System.Drawing.Size(60, 60);
            this.card3r1.TabIndex = 27;
            this.card3r1.TabStop = false;
            this.card3r1.Visible = false;
            this.card3r1.Click += new System.EventHandler(this.card3r1_Click);
            // 
            // card4r2
            // 
            this.card4r2.BackColor = System.Drawing.Color.White;
            this.card4r2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card4r2.BackgroundImage")));
            this.card4r2.Location = new System.Drawing.Point(70, 588);
            this.card4r2.Name = "card4r2";
            this.card4r2.Size = new System.Drawing.Size(60, 60);
            this.card4r2.TabIndex = 26;
            this.card4r2.TabStop = false;
            this.card4r2.Visible = false;
            this.card4r2.Click += new System.EventHandler(this.card4r2_Click);
            // 
            // card4r1
            // 
            this.card4r1.BackColor = System.Drawing.Color.White;
            this.card4r1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card4r1.BackgroundImage")));
            this.card4r1.Location = new System.Drawing.Point(70, 476);
            this.card4r1.Name = "card4r1";
            this.card4r1.Size = new System.Drawing.Size(60, 60);
            this.card4r1.TabIndex = 25;
            this.card4r1.TabStop = false;
            this.card4r1.Visible = false;
            this.card4r1.Click += new System.EventHandler(this.card4r1_Click);
            // 
            // card5
            // 
            this.card5.BackColor = System.Drawing.Color.White;
            this.card5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card5.BackgroundImage")));
            this.card5.Location = new System.Drawing.Point(70, 532);
            this.card5.Name = "card5";
            this.card5.Size = new System.Drawing.Size(60, 60);
            this.card5.TabIndex = 24;
            this.card5.TabStop = false;
            this.card5.Visible = false;
            this.card5.Click += new System.EventHandler(this.card5_Click);
            // 
            // card4i3
            // 
            this.card4i3.BackColor = System.Drawing.Color.White;
            this.card4i3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card4i3.BackgroundImage")));
            this.card4i3.Location = new System.Drawing.Point(70, 616);
            this.card4i3.Name = "card4i3";
            this.card4i3.Size = new System.Drawing.Size(60, 60);
            this.card4i3.TabIndex = 23;
            this.card4i3.TabStop = false;
            this.card4i3.Visible = false;
            // 
            // card4i2
            // 
            this.card4i2.BackColor = System.Drawing.Color.White;
            this.card4i2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card4i2.BackgroundImage")));
            this.card4i2.Location = new System.Drawing.Point(70, 532);
            this.card4i2.Name = "card4i2";
            this.card4i2.Size = new System.Drawing.Size(60, 60);
            this.card4i2.TabIndex = 22;
            this.card4i2.TabStop = false;
            this.card4i2.Visible = false;
            // 
            // card4i1
            // 
            this.card4i1.BackColor = System.Drawing.Color.White;
            this.card4i1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card4i1.BackgroundImage")));
            this.card4i1.Location = new System.Drawing.Point(70, 448);
            this.card4i1.Name = "card4i1";
            this.card4i1.Size = new System.Drawing.Size(60, 60);
            this.card4i1.TabIndex = 21;
            this.card4i1.TabStop = false;
            this.card4i1.Visible = false;
            this.card4i1.Click += new System.EventHandler(this.card4i1_Click);
            // 
            // card3i1
            // 
            this.card3i1.BackColor = System.Drawing.Color.White;
            this.card3i1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card3i1.BackgroundImage")));
            this.card3i1.Location = new System.Drawing.Point(70, 435);
            this.card3i1.Name = "card3i1";
            this.card3i1.Size = new System.Drawing.Size(60, 60);
            this.card3i1.TabIndex = 20;
            this.card3i1.TabStop = false;
            this.card3i1.Visible = false;
            this.card3i1.Click += new System.EventHandler(this.card3i1_Click);
            // 
            // card3i2
            // 
            this.card3i2.BackColor = System.Drawing.Color.White;
            this.card3i2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card3i2.BackgroundImage")));
            this.card3i2.Location = new System.Drawing.Point(70, 498);
            this.card3i2.Name = "card3i2";
            this.card3i2.Size = new System.Drawing.Size(60, 60);
            this.card3i2.TabIndex = 19;
            this.card3i2.TabStop = false;
            this.card3i2.Visible = false;
            // 
            // card3i3
            // 
            this.card3i3.BackColor = System.Drawing.Color.White;
            this.card3i3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card3i3.BackgroundImage")));
            this.card3i3.Location = new System.Drawing.Point(70, 566);
            this.card3i3.Name = "card3i3";
            this.card3i3.Size = new System.Drawing.Size(60, 60);
            this.card3i3.TabIndex = 18;
            this.card3i3.TabStop = false;
            this.card3i3.Visible = false;
            // 
            // card3i4
            // 
            this.card3i4.BackColor = System.Drawing.Color.White;
            this.card3i4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("card3i4.BackgroundImage")));
            this.card3i4.Location = new System.Drawing.Point(70, 633);
            this.card3i4.Name = "card3i4";
            this.card3i4.Size = new System.Drawing.Size(60, 60);
            this.card3i4.TabIndex = 17;
            this.card3i4.TabStop = false;
            this.card3i4.Visible = false;
            // 
            // labelExp
            // 
            this.labelExp.AutoSize = true;
            this.labelExp.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelExp.ForeColor = System.Drawing.Color.White;
            this.labelExp.Location = new System.Drawing.Point(18, 405);
            this.labelExp.Name = "labelExp";
            this.labelExp.Size = new System.Drawing.Size(57, 16);
            this.labelExp.TabIndex = 13;
            this.labelExp.Text = "Staż: 0";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.BackColor = System.Drawing.Color.Transparent;
            this.labelName.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelName.ForeColor = System.Drawing.Color.White;
            this.labelName.Location = new System.Drawing.Point(3, 342);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(0, 16);
            this.labelName.TabIndex = 12;
            this.labelName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelPoints
            // 
            this.labelPoints.AutoSize = true;
            this.labelPoints.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelPoints.ForeColor = System.Drawing.Color.White;
            this.labelPoints.Location = new System.Drawing.Point(30, 228);
            this.labelPoints.Name = "labelPoints";
            this.labelPoints.Size = new System.Drawing.Size(136, 16);
            this.labelPoints.TabIndex = 11;
            this.labelPoints.Text = "Punkty właściwe: 0";
            // 
            // labelActionPoints
            // 
            this.labelActionPoints.AutoSize = true;
            this.labelActionPoints.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelActionPoints.ForeColor = System.Drawing.Color.White;
            this.labelActionPoints.Location = new System.Drawing.Point(38, 260);
            this.labelActionPoints.Name = "labelActionPoints";
            this.labelActionPoints.Size = new System.Drawing.Size(128, 16);
            this.labelActionPoints.TabIndex = 10;
            this.labelActionPoints.Text = "Punkty rozwoju: 0";
            // 
            // labelMemCount
            // 
            this.labelMemCount.AutoSize = true;
            this.labelMemCount.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelMemCount.ForeColor = System.Drawing.Color.White;
            this.labelMemCount.Location = new System.Drawing.Point(33, 244);
            this.labelMemCount.Name = "labelMemCount";
            this.labelMemCount.Size = new System.Drawing.Size(133, 16);
            this.labelMemCount.TabIndex = 9;
            this.labelMemCount.Text = "Liczba członków: 0";
            // 
            // labelAge
            // 
            this.labelAge.AutoSize = true;
            this.labelAge.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelAge.ForeColor = System.Drawing.Color.White;
            this.labelAge.Location = new System.Drawing.Point(51, 276);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(115, 16);
            this.labelAge.TabIndex = 8;
            this.labelAge.Text = "Wiek drużyny: 0";
            // 
            // labelAlias
            // 
            this.labelAlias.AutoSize = true;
            this.labelAlias.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelAlias.ForeColor = System.Drawing.Color.White;
            this.labelAlias.Location = new System.Drawing.Point(18, 389);
            this.labelAlias.Name = "labelAlias";
            this.labelAlias.Size = new System.Drawing.Size(50, 16);
            this.labelAlias.TabIndex = 7;
            this.labelAlias.Text = "Ksywa";
            this.labelAlias.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonPolrocze
            // 
            this.buttonPolrocze.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.buttonPolrocze.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonPolrocze.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonPolrocze.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonPolrocze.ForeColor = System.Drawing.Color.White;
            this.buttonPolrocze.Location = new System.Drawing.Point(0, 190);
            this.buttonPolrocze.Name = "buttonPolrocze";
            this.buttonPolrocze.Size = new System.Drawing.Size(200, 35);
            this.buttonPolrocze.TabIndex = 5;
            this.buttonPolrocze.Text = "Następne Półrocze!";
            this.buttonPolrocze.UseVisualStyleBackColor = false;
            this.buttonPolrocze.Click += new System.EventHandler(this.buttonPolrocze_Click);
            this.buttonPolrocze.MouseEnter += new System.EventHandler(this.buttonObrzed_MouseEnter);
            this.buttonPolrocze.MouseLeave += new System.EventHandler(this.buttonObrzed_MouseLeave);
            // 
            // buttonKursy
            // 
            this.buttonKursy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.buttonKursy.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonKursy.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonKursy.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonKursy.ForeColor = System.Drawing.Color.White;
            this.buttonKursy.Location = new System.Drawing.Point(0, 155);
            this.buttonKursy.Name = "buttonKursy";
            this.buttonKursy.Size = new System.Drawing.Size(200, 35);
            this.buttonKursy.TabIndex = 4;
            this.buttonKursy.Text = "Nabór";
            this.buttonKursy.UseVisualStyleBackColor = false;
            this.buttonKursy.Click += new System.EventHandler(this.buttonKursy_Click);
            this.buttonKursy.MouseEnter += new System.EventHandler(this.buttonKursy_MouseEnter);
            this.buttonKursy.MouseLeave += new System.EventHandler(this.buttonKursy_MouseLeave);
            // 
            // buttonAkcje
            // 
            this.buttonAkcje.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.buttonAkcje.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonAkcje.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAkcje.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonAkcje.ForeColor = System.Drawing.Color.White;
            this.buttonAkcje.Location = new System.Drawing.Point(0, 120);
            this.buttonAkcje.Name = "buttonAkcje";
            this.buttonAkcje.Size = new System.Drawing.Size(200, 35);
            this.buttonAkcje.TabIndex = 3;
            this.buttonAkcje.Text = "Biwak";
            this.buttonAkcje.UseVisualStyleBackColor = false;
            this.buttonAkcje.Click += new System.EventHandler(this.button2_Click);
            this.buttonAkcje.MouseEnter += new System.EventHandler(this.buttonAkcje_MouseEnter);
            this.buttonAkcje.MouseLeave += new System.EventHandler(this.buttonAkcje_MouseLeave);
            // 
            // buttonDruzyna
            // 
            this.buttonDruzyna.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.buttonDruzyna.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonDruzyna.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDruzyna.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonDruzyna.ForeColor = System.Drawing.Color.White;
            this.buttonDruzyna.Location = new System.Drawing.Point(0, 85);
            this.buttonDruzyna.Name = "buttonDruzyna";
            this.buttonDruzyna.Size = new System.Drawing.Size(200, 35);
            this.buttonDruzyna.TabIndex = 2;
            this.buttonDruzyna.Text = "Drużyna";
            this.buttonDruzyna.UseVisualStyleBackColor = false;
            this.buttonDruzyna.Click += new System.EventHandler(this.buttonDruzyna_Click);
            this.buttonDruzyna.MouseEnter += new System.EventHandler(this.buttonDruzyna_MouseEnter);
            this.buttonDruzyna.MouseLeave += new System.EventHandler(this.buttonDruzyna_MouseLeave);
            // 
            // buttonNewGame
            // 
            this.buttonNewGame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.buttonNewGame.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonNewGame.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonNewGame.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonNewGame.ForeColor = System.Drawing.Color.White;
            this.buttonNewGame.Location = new System.Drawing.Point(0, 50);
            this.buttonNewGame.Name = "buttonNewGame";
            this.buttonNewGame.Size = new System.Drawing.Size(200, 35);
            this.buttonNewGame.TabIndex = 1;
            this.buttonNewGame.Text = "Nowa Gra";
            this.buttonNewGame.UseVisualStyleBackColor = false;
            this.buttonNewGame.Click += new System.EventHandler(this.buttonNewGame_Click);
            this.buttonNewGame.MouseEnter += new System.EventHandler(this.buttonNewGame_MouseEnter);
            this.buttonNewGame.MouseLeave += new System.EventHandler(this.buttonNewGame_MouseLeave);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(52)))), ((int)(((byte)(27)))));
            this.panelLogo.Controls.Add(this.pictureLogo);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(200, 50);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureLogo
            // 
            this.pictureLogo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureLogo.BackgroundImage")));
            this.pictureLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureLogo.Location = new System.Drawing.Point(0, 0);
            this.pictureLogo.Name = "pictureLogo";
            this.pictureLogo.Size = new System.Drawing.Size(200, 50);
            this.pictureLogo.TabIndex = 0;
            this.pictureLogo.TabStop = false;
            this.pictureLogo.Click += new System.EventHandler(this.pictureLogo_Click);
            // 
            // cardFrame
            // 
            this.cardFrame.BackColor = System.Drawing.Color.White;
            this.cardFrame.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cardFrame.BackgroundImage")));
            this.cardFrame.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cardFrame.Image = ((System.Drawing.Image)(resources.GetObject("cardFrame.Image")));
            this.cardFrame.Location = new System.Drawing.Point(22, 424);
            this.cardFrame.Name = "cardFrame";
            this.cardFrame.Size = new System.Drawing.Size(155, 276);
            this.cardFrame.TabIndex = 35;
            this.cardFrame.TabStop = false;
            this.cardFrame.Visible = false;
            // 
            // picturePodglad0
            // 
            this.picturePodglad0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picturePodglad0.BackgroundImage")));
            this.picturePodglad0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picturePodglad0.Location = new System.Drawing.Point(22, 424);
            this.picturePodglad0.Name = "picturePodglad0";
            this.picturePodglad0.Size = new System.Drawing.Size(155, 276);
            this.picturePodglad0.TabIndex = 6;
            this.picturePodglad0.TabStop = false;
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(181)))), ((int)(((byte)(68)))));
            this.panelMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panelMain.Controls.Add(this.GIRL1);
            this.panelMain.Controls.Add(this.pictureBoxBuforing);
            this.panelMain.Controls.Add(this.panelTop);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(200, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(1080, 720);
            this.panelMain.TabIndex = 1;
            this.panelMain.Click += new System.EventHandler(this.panelMain_Click);
            this.panelMain.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelMain_MouseMove);
            // 
            // GIRL1
            // 
            this.GIRL1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GIRL1.BackgroundImage")));
            this.GIRL1.Location = new System.Drawing.Point(6, 29);
            this.GIRL1.Name = "GIRL1";
            this.GIRL1.Size = new System.Drawing.Size(29, 18);
            this.GIRL1.TabIndex = 29;
            this.GIRL1.TabStop = false;
            this.GIRL1.Visible = false;
            // 
            // pictureBoxBuforing
            // 
            this.pictureBoxBuforing.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxBuforing.BackgroundImage")));
            this.pictureBoxBuforing.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxBuforing.Location = new System.Drawing.Point(0, 50);
            this.pictureBoxBuforing.Name = "pictureBoxBuforing";
            this.pictureBoxBuforing.Size = new System.Drawing.Size(1080, 670);
            this.pictureBoxBuforing.TabIndex = 1;
            this.pictureBoxBuforing.TabStop = false;
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(87)))), ((int)(((byte)(27)))));
            this.panelTop.Controls.Add(this.MAN5r);
            this.panelTop.Controls.Add(this.MAN5i);
            this.panelTop.Controls.Add(this.MAN4r);
            this.panelTop.Controls.Add(this.MAN4i);
            this.panelTop.Controls.Add(this.MAN3r);
            this.panelTop.Controls.Add(this.MAN3i);
            this.panelTop.Controls.Add(this.MAN2);
            this.panelTop.Controls.Add(this.MAN1);
            this.panelTop.Controls.Add(this.GIRL5r);
            this.panelTop.Controls.Add(this.GIRL5i);
            this.panelTop.Controls.Add(this.GIRL4r);
            this.panelTop.Controls.Add(this.GIRL4i);
            this.panelTop.Controls.Add(this.GIRL3r);
            this.panelTop.Controls.Add(this.GIRL3i);
            this.panelTop.Controls.Add(this.GIRL2);
            this.panelTop.Controls.Add(this.PPzdany);
            this.panelTop.Controls.Add(this.zielonySznur);
            this.panelTop.Controls.Add(this.PPproba);
            this.panelTop.Controls.Add(this.PZzdany);
            this.panelTop.Controls.Add(this.brazowySznur);
            this.panelTop.Controls.Add(this.pagon);
            this.panelTop.Controls.Add(this.IIzdany);
            this.panelTop.Controls.Add(this.ZSzdany);
            this.panelTop.Controls.Add(this.IIstopien);
            this.panelTop.Controls.Add(this.ZSproba);
            this.panelTop.Controls.Add(this.PZproba);
            this.panelTop.Controls.Add(this.krzyz);
            this.panelTop.Controls.Add(this.Izdany);
            this.panelTop.Controls.Add(this.chusta);
            this.panelTop.Controls.Add(this.Istopien);
            this.panelTop.Controls.Add(this.checkSymbol);
            this.panelTop.Controls.Add(this.Card5r);
            this.panelTop.Controls.Add(this.Card5i);
            this.panelTop.Controls.Add(this.Card4r);
            this.panelTop.Controls.Add(this.Card4i);
            this.panelTop.Controls.Add(this.Card3r);
            this.panelTop.Controls.Add(this.Card3i);
            this.panelTop.Controls.Add(this.Card2);
            this.panelTop.Controls.Add(this.Card1);
            this.panelTop.Controls.Add(this.labelTimer);
            this.panelTop.Controls.Add(this.pictureBoxStop);
            this.panelTop.Controls.Add(this.pictureBoxFloor);
            this.panelTop.Controls.Add(this.pictureBoxExit);
            this.panelTop.Controls.Add(this.labelTitle);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1080, 50);
            this.panelTop.TabIndex = 0;
            // 
            // MAN5r
            // 
            this.MAN5r.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MAN5r.BackgroundImage")));
            this.MAN5r.Location = new System.Drawing.Point(531, 27);
            this.MAN5r.Name = "MAN5r";
            this.MAN5r.Size = new System.Drawing.Size(29, 17);
            this.MAN5r.TabIndex = 42;
            this.MAN5r.TabStop = false;
            this.MAN5r.Visible = false;
            // 
            // MAN5i
            // 
            this.MAN5i.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MAN5i.BackgroundImage")));
            this.MAN5i.Location = new System.Drawing.Point(496, 29);
            this.MAN5i.Name = "MAN5i";
            this.MAN5i.Size = new System.Drawing.Size(29, 16);
            this.MAN5i.TabIndex = 41;
            this.MAN5i.TabStop = false;
            this.MAN5i.Visible = false;
            // 
            // MAN4r
            // 
            this.MAN4r.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MAN4r.BackgroundImage")));
            this.MAN4r.Location = new System.Drawing.Point(461, 28);
            this.MAN4r.Name = "MAN4r";
            this.MAN4r.Size = new System.Drawing.Size(29, 16);
            this.MAN4r.TabIndex = 40;
            this.MAN4r.TabStop = false;
            this.MAN4r.Visible = false;
            // 
            // MAN4i
            // 
            this.MAN4i.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MAN4i.BackgroundImage")));
            this.MAN4i.Location = new System.Drawing.Point(426, 29);
            this.MAN4i.Name = "MAN4i";
            this.MAN4i.Size = new System.Drawing.Size(29, 17);
            this.MAN4i.TabIndex = 39;
            this.MAN4i.TabStop = false;
            this.MAN4i.Visible = false;
            // 
            // MAN3r
            // 
            this.MAN3r.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MAN3r.BackgroundImage")));
            this.MAN3r.Location = new System.Drawing.Point(391, 28);
            this.MAN3r.Name = "MAN3r";
            this.MAN3r.Size = new System.Drawing.Size(29, 17);
            this.MAN3r.TabIndex = 38;
            this.MAN3r.TabStop = false;
            this.MAN3r.Visible = false;
            // 
            // MAN3i
            // 
            this.MAN3i.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MAN3i.BackgroundImage")));
            this.MAN3i.Location = new System.Drawing.Point(356, 27);
            this.MAN3i.Name = "MAN3i";
            this.MAN3i.Size = new System.Drawing.Size(29, 17);
            this.MAN3i.TabIndex = 37;
            this.MAN3i.TabStop = false;
            this.MAN3i.Visible = false;
            // 
            // MAN2
            // 
            this.MAN2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MAN2.BackgroundImage")));
            this.MAN2.Location = new System.Drawing.Point(321, 29);
            this.MAN2.Name = "MAN2";
            this.MAN2.Size = new System.Drawing.Size(29, 17);
            this.MAN2.TabIndex = 36;
            this.MAN2.TabStop = false;
            this.MAN2.Visible = false;
            // 
            // MAN1
            // 
            this.MAN1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MAN1.BackgroundImage")));
            this.MAN1.Location = new System.Drawing.Point(286, 29);
            this.MAN1.Name = "MAN1";
            this.MAN1.Size = new System.Drawing.Size(29, 18);
            this.MAN1.TabIndex = 30;
            this.MAN1.TabStop = false;
            this.MAN1.Visible = false;
            // 
            // GIRL5r
            // 
            this.GIRL5r.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GIRL5r.BackgroundImage")));
            this.GIRL5r.Location = new System.Drawing.Point(251, 27);
            this.GIRL5r.Name = "GIRL5r";
            this.GIRL5r.Size = new System.Drawing.Size(29, 17);
            this.GIRL5r.TabIndex = 35;
            this.GIRL5r.TabStop = false;
            this.GIRL5r.Visible = false;
            // 
            // GIRL5i
            // 
            this.GIRL5i.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GIRL5i.BackgroundImage")));
            this.GIRL5i.Location = new System.Drawing.Point(216, 28);
            this.GIRL5i.Name = "GIRL5i";
            this.GIRL5i.Size = new System.Drawing.Size(29, 16);
            this.GIRL5i.TabIndex = 34;
            this.GIRL5i.TabStop = false;
            this.GIRL5i.Visible = false;
            // 
            // GIRL4r
            // 
            this.GIRL4r.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GIRL4r.BackgroundImage")));
            this.GIRL4r.Location = new System.Drawing.Point(181, 30);
            this.GIRL4r.Name = "GIRL4r";
            this.GIRL4r.Size = new System.Drawing.Size(29, 16);
            this.GIRL4r.TabIndex = 33;
            this.GIRL4r.TabStop = false;
            this.GIRL4r.Visible = false;
            // 
            // GIRL4i
            // 
            this.GIRL4i.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GIRL4i.BackgroundImage")));
            this.GIRL4i.Location = new System.Drawing.Point(146, 29);
            this.GIRL4i.Name = "GIRL4i";
            this.GIRL4i.Size = new System.Drawing.Size(29, 17);
            this.GIRL4i.TabIndex = 32;
            this.GIRL4i.TabStop = false;
            this.GIRL4i.Visible = false;
            // 
            // GIRL3r
            // 
            this.GIRL3r.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GIRL3r.BackgroundImage")));
            this.GIRL3r.Location = new System.Drawing.Point(111, 29);
            this.GIRL3r.Name = "GIRL3r";
            this.GIRL3r.Size = new System.Drawing.Size(29, 17);
            this.GIRL3r.TabIndex = 31;
            this.GIRL3r.TabStop = false;
            this.GIRL3r.Visible = false;
            // 
            // GIRL3i
            // 
            this.GIRL3i.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GIRL3i.BackgroundImage")));
            this.GIRL3i.Location = new System.Drawing.Point(76, 29);
            this.GIRL3i.Name = "GIRL3i";
            this.GIRL3i.Size = new System.Drawing.Size(29, 17);
            this.GIRL3i.TabIndex = 30;
            this.GIRL3i.TabStop = false;
            this.GIRL3i.Visible = false;
            // 
            // GIRL2
            // 
            this.GIRL2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GIRL2.BackgroundImage")));
            this.GIRL2.Location = new System.Drawing.Point(41, 29);
            this.GIRL2.Name = "GIRL2";
            this.GIRL2.Size = new System.Drawing.Size(29, 17);
            this.GIRL2.TabIndex = 29;
            this.GIRL2.TabStop = false;
            this.GIRL2.Visible = false;
            // 
            // PPzdany
            // 
            this.PPzdany.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PPzdany.BackgroundImage")));
            this.PPzdany.Location = new System.Drawing.Point(811, 6);
            this.PPzdany.Name = "PPzdany";
            this.PPzdany.Size = new System.Drawing.Size(29, 17);
            this.PPzdany.TabIndex = 28;
            this.PPzdany.TabStop = false;
            this.PPzdany.Visible = false;
            // 
            // zielonySznur
            // 
            this.zielonySznur.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("zielonySznur.BackgroundImage")));
            this.zielonySznur.Location = new System.Drawing.Point(776, 6);
            this.zielonySznur.Name = "zielonySznur";
            this.zielonySznur.Size = new System.Drawing.Size(29, 17);
            this.zielonySznur.TabIndex = 27;
            this.zielonySznur.TabStop = false;
            this.zielonySznur.Visible = false;
            // 
            // PPproba
            // 
            this.PPproba.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PPproba.BackgroundImage")));
            this.PPproba.Location = new System.Drawing.Point(741, 6);
            this.PPproba.Name = "PPproba";
            this.PPproba.Size = new System.Drawing.Size(29, 17);
            this.PPproba.TabIndex = 26;
            this.PPproba.TabStop = false;
            this.PPproba.Visible = false;
            // 
            // PZzdany
            // 
            this.PZzdany.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PZzdany.BackgroundImage")));
            this.PZzdany.Location = new System.Drawing.Point(706, 7);
            this.PZzdany.Name = "PZzdany";
            this.PZzdany.Size = new System.Drawing.Size(29, 16);
            this.PZzdany.TabIndex = 25;
            this.PZzdany.TabStop = false;
            this.PZzdany.Visible = false;
            // 
            // brazowySznur
            // 
            this.brazowySznur.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("brazowySznur.BackgroundImage")));
            this.brazowySznur.Location = new System.Drawing.Point(671, 7);
            this.brazowySznur.Name = "brazowySznur";
            this.brazowySznur.Size = new System.Drawing.Size(29, 16);
            this.brazowySznur.TabIndex = 24;
            this.brazowySznur.TabStop = false;
            this.brazowySznur.Visible = false;
            // 
            // pagon
            // 
            this.pagon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pagon.BackgroundImage")));
            this.pagon.Location = new System.Drawing.Point(636, 6);
            this.pagon.Name = "pagon";
            this.pagon.Size = new System.Drawing.Size(29, 17);
            this.pagon.TabIndex = 23;
            this.pagon.TabStop = false;
            this.pagon.Visible = false;
            // 
            // IIzdany
            // 
            this.IIzdany.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("IIzdany.BackgroundImage")));
            this.IIzdany.Location = new System.Drawing.Point(601, 6);
            this.IIzdany.Name = "IIzdany";
            this.IIzdany.Size = new System.Drawing.Size(29, 17);
            this.IIzdany.TabIndex = 22;
            this.IIzdany.TabStop = false;
            this.IIzdany.Visible = false;
            // 
            // ZSzdany
            // 
            this.ZSzdany.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ZSzdany.BackgroundImage")));
            this.ZSzdany.Location = new System.Drawing.Point(566, 6);
            this.ZSzdany.Name = "ZSzdany";
            this.ZSzdany.Size = new System.Drawing.Size(29, 17);
            this.ZSzdany.TabIndex = 21;
            this.ZSzdany.TabStop = false;
            this.ZSzdany.Visible = false;
            // 
            // IIstopien
            // 
            this.IIstopien.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("IIstopien.BackgroundImage")));
            this.IIstopien.Location = new System.Drawing.Point(531, 6);
            this.IIstopien.Name = "IIstopien";
            this.IIstopien.Size = new System.Drawing.Size(29, 17);
            this.IIstopien.TabIndex = 20;
            this.IIstopien.TabStop = false;
            this.IIstopien.Visible = false;
            // 
            // ZSproba
            // 
            this.ZSproba.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ZSproba.BackgroundImage")));
            this.ZSproba.Location = new System.Drawing.Point(496, 6);
            this.ZSproba.Name = "ZSproba";
            this.ZSproba.Size = new System.Drawing.Size(29, 17);
            this.ZSproba.TabIndex = 19;
            this.ZSproba.TabStop = false;
            this.ZSproba.Visible = false;
            // 
            // PZproba
            // 
            this.PZproba.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PZproba.BackgroundImage")));
            this.PZproba.Location = new System.Drawing.Point(461, 7);
            this.PZproba.Name = "PZproba";
            this.PZproba.Size = new System.Drawing.Size(29, 16);
            this.PZproba.TabIndex = 18;
            this.PZproba.TabStop = false;
            this.PZproba.Visible = false;
            // 
            // krzyz
            // 
            this.krzyz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("krzyz.BackgroundImage")));
            this.krzyz.Location = new System.Drawing.Point(426, 6);
            this.krzyz.Name = "krzyz";
            this.krzyz.Size = new System.Drawing.Size(29, 17);
            this.krzyz.TabIndex = 17;
            this.krzyz.TabStop = false;
            this.krzyz.Visible = false;
            // 
            // Izdany
            // 
            this.Izdany.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Izdany.BackgroundImage")));
            this.Izdany.Location = new System.Drawing.Point(391, 6);
            this.Izdany.Name = "Izdany";
            this.Izdany.Size = new System.Drawing.Size(29, 17);
            this.Izdany.TabIndex = 16;
            this.Izdany.TabStop = false;
            this.Izdany.Visible = false;
            // 
            // chusta
            // 
            this.chusta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chusta.BackgroundImage")));
            this.chusta.Location = new System.Drawing.Point(356, 6);
            this.chusta.Name = "chusta";
            this.chusta.Size = new System.Drawing.Size(29, 17);
            this.chusta.TabIndex = 15;
            this.chusta.TabStop = false;
            this.chusta.Visible = false;
            // 
            // Istopien
            // 
            this.Istopien.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Istopien.BackgroundImage")));
            this.Istopien.Location = new System.Drawing.Point(321, 6);
            this.Istopien.Name = "Istopien";
            this.Istopien.Size = new System.Drawing.Size(29, 17);
            this.Istopien.TabIndex = 14;
            this.Istopien.TabStop = false;
            this.Istopien.Visible = false;
            // 
            // checkSymbol
            // 
            this.checkSymbol.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("checkSymbol.BackgroundImage")));
            this.checkSymbol.Location = new System.Drawing.Point(286, 6);
            this.checkSymbol.Name = "checkSymbol";
            this.checkSymbol.Size = new System.Drawing.Size(29, 17);
            this.checkSymbol.TabIndex = 13;
            this.checkSymbol.TabStop = false;
            this.checkSymbol.Visible = false;
            // 
            // Card5r
            // 
            this.Card5r.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Card5r.BackgroundImage")));
            this.Card5r.Location = new System.Drawing.Point(251, 6);
            this.Card5r.Name = "Card5r";
            this.Card5r.Size = new System.Drawing.Size(29, 17);
            this.Card5r.TabIndex = 12;
            this.Card5r.TabStop = false;
            this.Card5r.Visible = false;
            // 
            // Card5i
            // 
            this.Card5i.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Card5i.BackgroundImage")));
            this.Card5i.Location = new System.Drawing.Point(216, 7);
            this.Card5i.Name = "Card5i";
            this.Card5i.Size = new System.Drawing.Size(29, 16);
            this.Card5i.TabIndex = 11;
            this.Card5i.TabStop = false;
            this.Card5i.Visible = false;
            // 
            // Card4r
            // 
            this.Card4r.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Card4r.BackgroundImage")));
            this.Card4r.Location = new System.Drawing.Point(181, 7);
            this.Card4r.Name = "Card4r";
            this.Card4r.Size = new System.Drawing.Size(29, 16);
            this.Card4r.TabIndex = 10;
            this.Card4r.TabStop = false;
            this.Card4r.Visible = false;
            // 
            // Card4i
            // 
            this.Card4i.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Card4i.BackgroundImage")));
            this.Card4i.Location = new System.Drawing.Point(146, 6);
            this.Card4i.Name = "Card4i";
            this.Card4i.Size = new System.Drawing.Size(29, 17);
            this.Card4i.TabIndex = 9;
            this.Card4i.TabStop = false;
            this.Card4i.Visible = false;
            // 
            // Card3r
            // 
            this.Card3r.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Card3r.BackgroundImage")));
            this.Card3r.Location = new System.Drawing.Point(111, 6);
            this.Card3r.Name = "Card3r";
            this.Card3r.Size = new System.Drawing.Size(29, 17);
            this.Card3r.TabIndex = 8;
            this.Card3r.TabStop = false;
            this.Card3r.Visible = false;
            // 
            // Card3i
            // 
            this.Card3i.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Card3i.BackgroundImage")));
            this.Card3i.Location = new System.Drawing.Point(76, 6);
            this.Card3i.Name = "Card3i";
            this.Card3i.Size = new System.Drawing.Size(29, 17);
            this.Card3i.TabIndex = 7;
            this.Card3i.TabStop = false;
            this.Card3i.Visible = false;
            // 
            // Card2
            // 
            this.Card2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Card2.BackgroundImage")));
            this.Card2.Location = new System.Drawing.Point(41, 6);
            this.Card2.Name = "Card2";
            this.Card2.Size = new System.Drawing.Size(29, 17);
            this.Card2.TabIndex = 6;
            this.Card2.TabStop = false;
            this.Card2.Visible = false;
            // 
            // Card1
            // 
            this.Card1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Card1.BackgroundImage")));
            this.Card1.Location = new System.Drawing.Point(6, 6);
            this.Card1.Name = "Card1";
            this.Card1.Size = new System.Drawing.Size(29, 17);
            this.Card1.TabIndex = 5;
            this.Card1.TabStop = false;
            this.Card1.Visible = false;
            // 
            // labelTimer
            // 
            this.labelTimer.AutoSize = true;
            this.labelTimer.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelTimer.ForeColor = System.Drawing.Color.White;
            this.labelTimer.Location = new System.Drawing.Point(814, 9);
            this.labelTimer.Name = "labelTimer";
            this.labelTimer.Size = new System.Drawing.Size(102, 32);
            this.labelTimer.TabIndex = 4;
            this.labelTimer.Text = "00:00";
            // 
            // pictureBoxStop
            // 
            this.pictureBoxStop.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxStop.BackgroundImage")));
            this.pictureBoxStop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxStop.Location = new System.Drawing.Point(935, 8);
            this.pictureBoxStop.Name = "pictureBoxStop";
            this.pictureBoxStop.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxStop.TabIndex = 3;
            this.pictureBoxStop.TabStop = false;
            this.pictureBoxStop.Click += new System.EventHandler(this.pictureBoxStop_Click);
            // 
            // pictureBoxFloor
            // 
            this.pictureBoxFloor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxFloor.BackgroundImage")));
            this.pictureBoxFloor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxFloor.Location = new System.Drawing.Point(976, 8);
            this.pictureBoxFloor.Name = "pictureBoxFloor";
            this.pictureBoxFloor.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxFloor.TabIndex = 2;
            this.pictureBoxFloor.TabStop = false;
            this.pictureBoxFloor.Click += new System.EventHandler(this.Floor_Click);
            // 
            // pictureBoxExit
            // 
            this.pictureBoxExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxExit.BackgroundImage")));
            this.pictureBoxExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxExit.Location = new System.Drawing.Point(1017, 8);
            this.pictureBoxExit.Name = "pictureBoxExit";
            this.pictureBoxExit.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxExit.TabIndex = 1;
            this.pictureBoxExit.TabStop = false;
            this.pictureBoxExit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelTitle.ForeColor = System.Drawing.Color.White;
            this.labelTitle.Location = new System.Drawing.Point(8, 12);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(573, 25);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "SYMULATOR ROZWOJU DRUŻYNY HARCERSKIEJ";
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1280, 720);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelSide);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Planer Drużynowego";
            this.panelSide.ResumeLayout(false);
            this.panelSide.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.card12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3r2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3r1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4r2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4r1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4i3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4i2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4i1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3i1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3i2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3i3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3i4)).EndInit();
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cardFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picturePodglad0)).EndInit();
            this.panelMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GIRL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBuforing)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MAN5r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN5i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN4r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN4i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN3r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN3i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MAN1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL5r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL5i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL4r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL4i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL3r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL3i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GIRL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PPzdany)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zielonySznur)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PPproba)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PZzdany)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brazowySznur)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pagon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IIzdany)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZSzdany)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IIstopien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZSproba)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PZproba)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.krzyz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Izdany)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chusta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Istopien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkSymbol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card5r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card5i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card4r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card4i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card3r)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card3i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Card1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFloor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSide;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureLogo;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Button buttonNewGame;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.PictureBox pictureBoxBuforing;
        private System.Windows.Forms.PictureBox pictureBoxStop;
        private System.Windows.Forms.PictureBox pictureBoxFloor;
        private System.Windows.Forms.PictureBox pictureBoxExit;
        private System.Windows.Forms.Button buttonAkcje;
        private System.Windows.Forms.Button buttonDruzyna;
        private System.Windows.Forms.Button buttonPolrocze;
        private System.Windows.Forms.Button buttonKursy;
        private System.Windows.Forms.Label labelAlias;
        private System.Windows.Forms.PictureBox picturePodglad0;
        private System.Windows.Forms.Label labelPoints;
        private System.Windows.Forms.Label labelActionPoints;
        private System.Windows.Forms.Label labelMemCount;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.Label labelName;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label labelExp;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labelTimer;
        private System.Windows.Forms.PictureBox Card5r;
        private System.Windows.Forms.PictureBox Card5i;
        private System.Windows.Forms.PictureBox Card4r;
        private System.Windows.Forms.PictureBox Card4i;
        private System.Windows.Forms.PictureBox Card3r;
        private System.Windows.Forms.PictureBox Card3i;
        private System.Windows.Forms.PictureBox Card2;
        private System.Windows.Forms.PictureBox Card1;
        private System.Windows.Forms.PictureBox card12;
        private System.Windows.Forms.PictureBox card11;
        private System.Windows.Forms.PictureBox card24;
        private System.Windows.Forms.PictureBox card23;
        private System.Windows.Forms.PictureBox card22;
        private System.Windows.Forms.PictureBox card21;
        private System.Windows.Forms.PictureBox card3r2;
        private System.Windows.Forms.PictureBox card3r1;
        private System.Windows.Forms.PictureBox card4r2;
        private System.Windows.Forms.PictureBox card4r1;
        private System.Windows.Forms.PictureBox card5;
        private System.Windows.Forms.PictureBox card4i3;
        private System.Windows.Forms.PictureBox card4i2;
        private System.Windows.Forms.PictureBox card4i1;
        private System.Windows.Forms.PictureBox card3i1;
        private System.Windows.Forms.PictureBox card3i2;
        private System.Windows.Forms.PictureBox card3i3;
        private System.Windows.Forms.PictureBox card3i4;
        private System.Windows.Forms.PictureBox cardFrame;
        private System.Windows.Forms.PictureBox checkSymbol;
        private System.Windows.Forms.PictureBox PPzdany;
        private System.Windows.Forms.PictureBox zielonySznur;
        private System.Windows.Forms.PictureBox PPproba;
        private System.Windows.Forms.PictureBox PZzdany;
        private System.Windows.Forms.PictureBox brazowySznur;
        private System.Windows.Forms.PictureBox pagon;
        private System.Windows.Forms.PictureBox IIzdany;
        private System.Windows.Forms.PictureBox ZSzdany;
        private System.Windows.Forms.PictureBox IIstopien;
        private System.Windows.Forms.PictureBox ZSproba;
        private System.Windows.Forms.PictureBox PZproba;
        private System.Windows.Forms.PictureBox krzyz;
        private System.Windows.Forms.PictureBox Izdany;
        private System.Windows.Forms.PictureBox chusta;
        private System.Windows.Forms.PictureBox Istopien;
        private System.Windows.Forms.PictureBox GIRL1;
        private System.Windows.Forms.PictureBox GIRL5r;
        private System.Windows.Forms.PictureBox GIRL5i;
        private System.Windows.Forms.PictureBox GIRL4r;
        private System.Windows.Forms.PictureBox GIRL4i;
        private System.Windows.Forms.PictureBox GIRL3r;
        private System.Windows.Forms.PictureBox GIRL3i;
        private System.Windows.Forms.PictureBox GIRL2;
        private System.Windows.Forms.PictureBox MAN5r;
        private System.Windows.Forms.PictureBox MAN5i;
        private System.Windows.Forms.PictureBox MAN4r;
        private System.Windows.Forms.PictureBox MAN4i;
        private System.Windows.Forms.PictureBox MAN3r;
        private System.Windows.Forms.PictureBox MAN3i;
        private System.Windows.Forms.PictureBox MAN2;
        private System.Windows.Forms.PictureBox MAN1;
    }
}

