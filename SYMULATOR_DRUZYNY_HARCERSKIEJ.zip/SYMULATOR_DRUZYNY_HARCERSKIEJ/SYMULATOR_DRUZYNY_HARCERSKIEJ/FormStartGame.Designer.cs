﻿namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    partial class FormStartGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormStartGame));
            this.panelTop = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.panelHome = new System.Windows.Forms.Panel();
            this.buttonStworz = new System.Windows.Forms.Button();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.textBoxBoss = new System.Windows.Forms.TextBox();
            this.labelBoss = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboRightMiddle = new System.Windows.Forms.ComboBox();
            this.comboLeftMiddle = new System.Windows.Forms.ComboBox();
            this.comboRightDown = new System.Windows.Forms.ComboBox();
            this.comboLeftDown = new System.Windows.Forms.ComboBox();
            this.comboLeftHigh = new System.Windows.Forms.ComboBox();
            this.comboRightHigh = new System.Windows.Forms.ComboBox();
            this.labelColors = new System.Windows.Forms.Label();
            this.pictureShawl = new System.Windows.Forms.PictureBox();
            this.labelNum = new System.Windows.Forms.Label();
            this.numericNum = new System.Windows.Forms.NumericUpDown();
            this.labelName = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.colorDialog2 = new System.Windows.Forms.ColorDialog();
            this.panelTop.SuspendLayout();
            this.panelHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureShawl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericNum)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(87)))), ((int)(((byte)(27)))));
            this.panelTop.Controls.Add(this.labelTitle);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(500, 50);
            this.panelTop.TabIndex = 0;
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelTitle.ForeColor = System.Drawing.Color.White;
            this.labelTitle.Location = new System.Drawing.Point(62, 12);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(377, 25);
            this.labelTitle.TabIndex = 2;
            this.labelTitle.Text = "ZAKŁADANIE NOWEJ DRUŻYNY";
            // 
            // panelHome
            // 
            this.panelHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(181)))), ((int)(((byte)(68)))));
            this.panelHome.Controls.Add(this.buttonStworz);
            this.panelHome.Controls.Add(this.radioButton2);
            this.panelHome.Controls.Add(this.radioButton1);
            this.panelHome.Controls.Add(this.textBoxBoss);
            this.panelHome.Controls.Add(this.labelBoss);
            this.panelHome.Controls.Add(this.button2);
            this.panelHome.Controls.Add(this.button1);
            this.panelHome.Controls.Add(this.comboRightMiddle);
            this.panelHome.Controls.Add(this.comboLeftMiddle);
            this.panelHome.Controls.Add(this.comboRightDown);
            this.panelHome.Controls.Add(this.comboLeftDown);
            this.panelHome.Controls.Add(this.comboLeftHigh);
            this.panelHome.Controls.Add(this.comboRightHigh);
            this.panelHome.Controls.Add(this.labelColors);
            this.panelHome.Controls.Add(this.pictureShawl);
            this.panelHome.Controls.Add(this.labelNum);
            this.panelHome.Controls.Add(this.numericNum);
            this.panelHome.Controls.Add(this.labelName);
            this.panelHome.Controls.Add(this.textBoxName);
            this.panelHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHome.Location = new System.Drawing.Point(0, 50);
            this.panelHome.Name = "panelHome";
            this.panelHome.Size = new System.Drawing.Size(500, 450);
            this.panelHome.TabIndex = 1;
            // 
            // buttonStworz
            // 
            this.buttonStworz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(118)))), ((int)(((byte)(166)))));
            this.buttonStworz.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonStworz.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStworz.Location = new System.Drawing.Point(200, 398);
            this.buttonStworz.Name = "buttonStworz";
            this.buttonStworz.Size = new System.Drawing.Size(100, 40);
            this.buttonStworz.TabIndex = 25;
            this.buttonStworz.Text = "Stwórz!";
            this.buttonStworz.UseVisualStyleBackColor = false;
            this.buttonStworz.Click += new System.EventHandler(this.buttonStworz_Click);
            this.buttonStworz.MouseEnter += new System.EventHandler(this.button3_MouseEnter);
            this.buttonStworz.MouseLeave += new System.EventHandler(this.buttonStworz_MouseLeave);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(290, 111);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(56, 17);
            this.radioButton2.TabIndex = 24;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "męska";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(145, 111);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(59, 17);
            this.radioButton1.TabIndex = 23;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "żeńska";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // textBoxBoss
            // 
            this.textBoxBoss.Location = new System.Drawing.Point(50, 158);
            this.textBoxBoss.Name = "textBoxBoss";
            this.textBoxBoss.Size = new System.Drawing.Size(400, 20);
            this.textBoxBoss.TabIndex = 22;
            // 
            // labelBoss
            // 
            this.labelBoss.AutoSize = true;
            this.labelBoss.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelBoss.ForeColor = System.Drawing.Color.White;
            this.labelBoss.Location = new System.Drawing.Point(196, 137);
            this.labelBoss.Name = "labelBoss";
            this.labelBoss.Size = new System.Drawing.Size(108, 18);
            this.labelBoss.TabIndex = 21;
            this.labelBoss.Text = "Drużynowy";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(259, 215);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 20;
            this.button2.Text = "Barwa 2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(170, 215);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 19;
            this.button1.Text = "Barwa 1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboRightMiddle
            // 
            this.comboRightMiddle.FormattingEnabled = true;
            this.comboRightMiddle.Items.AddRange(new object[] {
            "1",
            "2"});
            this.comboRightMiddle.Location = new System.Drawing.Point(266, 326);
            this.comboRightMiddle.Name = "comboRightMiddle";
            this.comboRightMiddle.Size = new System.Drawing.Size(35, 21);
            this.comboRightMiddle.TabIndex = 18;
            this.comboRightMiddle.SelectedIndexChanged += new System.EventHandler(this.comboRightMiddle_SelectedIndexChanged);
            // 
            // comboLeftMiddle
            // 
            this.comboLeftMiddle.FormattingEnabled = true;
            this.comboLeftMiddle.Items.AddRange(new object[] {
            "1",
            "2"});
            this.comboLeftMiddle.Location = new System.Drawing.Point(204, 326);
            this.comboLeftMiddle.Name = "comboLeftMiddle";
            this.comboLeftMiddle.Size = new System.Drawing.Size(35, 21);
            this.comboLeftMiddle.TabIndex = 17;
            this.comboLeftMiddle.SelectedIndexChanged += new System.EventHandler(this.comboLeftMiddle_SelectedIndexChanged);
            // 
            // comboRightDown
            // 
            this.comboRightDown.FormattingEnabled = true;
            this.comboRightDown.Items.AddRange(new object[] {
            "1",
            "2"});
            this.comboRightDown.Location = new System.Drawing.Point(290, 361);
            this.comboRightDown.Name = "comboRightDown";
            this.comboRightDown.Size = new System.Drawing.Size(35, 21);
            this.comboRightDown.TabIndex = 16;
            this.comboRightDown.SelectedIndexChanged += new System.EventHandler(this.comboRightDown_SelectedIndexChanged);
            // 
            // comboLeftDown
            // 
            this.comboLeftDown.FormattingEnabled = true;
            this.comboLeftDown.Items.AddRange(new object[] {
            "1",
            "2"});
            this.comboLeftDown.Location = new System.Drawing.Point(181, 361);
            this.comboLeftDown.Name = "comboLeftDown";
            this.comboLeftDown.Size = new System.Drawing.Size(35, 21);
            this.comboLeftDown.TabIndex = 15;
            this.comboLeftDown.SelectedIndexChanged += new System.EventHandler(this.comboLeftDown_SelectedIndexChanged);
            // 
            // comboLeftHigh
            // 
            this.comboLeftHigh.FormattingEnabled = true;
            this.comboLeftHigh.Items.AddRange(new object[] {
            "1",
            "2"});
            this.comboLeftHigh.Location = new System.Drawing.Point(199, 285);
            this.comboLeftHigh.Name = "comboLeftHigh";
            this.comboLeftHigh.Size = new System.Drawing.Size(35, 21);
            this.comboLeftHigh.TabIndex = 14;
            this.comboLeftHigh.SelectedIndexChanged += new System.EventHandler(this.comboLeftHigh_SelectedIndexChanged);
            // 
            // comboRightHigh
            // 
            this.comboRightHigh.FormattingEnabled = true;
            this.comboRightHigh.Items.AddRange(new object[] {
            "1",
            "2"});
            this.comboRightHigh.Location = new System.Drawing.Point(269, 285);
            this.comboRightHigh.Name = "comboRightHigh";
            this.comboRightHigh.Size = new System.Drawing.Size(35, 21);
            this.comboRightHigh.TabIndex = 13;
            this.comboRightHigh.SelectedIndexChanged += new System.EventHandler(this.comboRightHigh_SelectedIndexChanged);
            // 
            // labelColors
            // 
            this.labelColors.AutoSize = true;
            this.labelColors.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelColors.ForeColor = System.Drawing.Color.White;
            this.labelColors.Location = new System.Drawing.Point(178, 190);
            this.labelColors.Name = "labelColors";
            this.labelColors.Size = new System.Drawing.Size(143, 18);
            this.labelColors.TabIndex = 12;
            this.labelColors.Text = "Barwy Drużyny";
            // 
            // pictureShawl
            // 
            this.pictureShawl.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureShawl.BackgroundImage")));
            this.pictureShawl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureShawl.Location = new System.Drawing.Point(123, 253);
            this.pictureShawl.Name = "pictureShawl";
            this.pictureShawl.Size = new System.Drawing.Size(244, 129);
            this.pictureShawl.TabIndex = 11;
            this.pictureShawl.TabStop = false;
            // 
            // labelNum
            // 
            this.labelNum.AutoSize = true;
            this.labelNum.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelNum.ForeColor = System.Drawing.Color.White;
            this.labelNum.Location = new System.Drawing.Point(177, 58);
            this.labelNum.Name = "labelNum";
            this.labelNum.Size = new System.Drawing.Size(145, 18);
            this.labelNum.TabIndex = 10;
            this.labelNum.Text = "Numer Drużyny";
            // 
            // numericNum
            // 
            this.numericNum.Location = new System.Drawing.Point(212, 82);
            this.numericNum.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericNum.Name = "numericNum";
            this.numericNum.Size = new System.Drawing.Size(62, 20);
            this.numericNum.TabIndex = 9;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelName.ForeColor = System.Drawing.Color.White;
            this.labelName.Location = new System.Drawing.Point(176, 10);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(147, 18);
            this.labelName.TabIndex = 8;
            this.labelName.Text = "Nazwa Drużyny";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(50, 31);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(400, 20);
            this.textBoxName.TabIndex = 1;
            // 
            // colorDialog2
            // 
            this.colorDialog2.Color = System.Drawing.Color.Green;
            // 
            // FormStartGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(500, 500);
            this.Controls.Add(this.panelHome);
            this.Controls.Add(this.panelTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormStartGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Load += new System.EventHandler(this.FormStartGame_Load);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelHome.ResumeLayout(false);
            this.panelHome.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureShawl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericNum)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelHome;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label labelNum;
        private System.Windows.Forms.NumericUpDown numericNum;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.PictureBox pictureShawl;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboRightMiddle;
        private System.Windows.Forms.ComboBox comboLeftMiddle;
        private System.Windows.Forms.ComboBox comboRightDown;
        private System.Windows.Forms.ComboBox comboLeftDown;
        private System.Windows.Forms.ComboBox comboLeftHigh;
        private System.Windows.Forms.ComboBox comboRightHigh;
        private System.Windows.Forms.Label labelColors;
        private System.Windows.Forms.Label labelBoss;
        private System.Windows.Forms.Button buttonStworz;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.TextBox textBoxBoss;
        private System.Windows.Forms.ColorDialog colorDialog2;
    }
}