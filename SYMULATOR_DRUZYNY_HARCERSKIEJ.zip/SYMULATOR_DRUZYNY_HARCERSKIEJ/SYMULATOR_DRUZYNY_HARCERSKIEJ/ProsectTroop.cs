﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public partial class ProsectTroop : Form
    {
        Game game;

        public ProsectTroop(Game game)
        {
            InitializeComponent();
            this.game = game;
            this.Text = game.randomAdage();

            dataGridViewTroop.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(191, 87, 27);
            dataGridViewTroop.EnableHeadersVisualStyles = false;
            dataGridViewPatrols.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(191, 87, 27);
            dataGridViewPatrols.EnableHeadersVisualStyles = false;
            dataGridViewMasters.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(191, 87, 27);
            dataGridViewMasters.EnableHeadersVisualStyles = false;
            dataGridViewHelpers.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(191, 87, 27);
            dataGridViewHelpers.EnableHeadersVisualStyles = false;
            dataGridViewAdjutants.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(191, 87, 27);
            dataGridViewAdjutants.EnableHeadersVisualStyles = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        Image achivement(Scout s, int n)
        {
            int st = s.stage;
            switch (s.stage)
            {
                case 1:
                    switch (n)
                    {
                        case 0:
                            if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                            else return firstOpen.BackgroundImage;
                        case 1:
                            if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                            else return shawl.BackgroundImage;
                        default:
                            return transparent.BackgroundImage;
                    }
                case 2:
                    switch (n)
                    {
                        case 0:
                            if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                            else return firstGive.BackgroundImage;
                        case 1:
                            if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                            else return cross.BackgroundImage;
                        case 2:
                            if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                            else return PZinvite.BackgroundImage;
                        case 3:
                            if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                            else return ZSinvite.BackgroundImage;
                        default:
                            return transparent.BackgroundImage;
                    }
                case 3:
                    if (s.isRover)
                    {
                        switch (n)
                        {
                            case 0:
                                if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                                else return secondOpen.BackgroundImage;
                            case 1:
                                if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                                else return ZSGiven.BackgroundImage;
                            default:
                                return transparent.BackgroundImage;
                        }
                    }
                    else
                    {
                        switch (n)
                        {
                            case 0:
                                if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                                else return secondOpen.BackgroundImage;
                            case 1:
                                if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                                else return brownMaster.BackgroundImage;
                            case 2:
                                if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                                else return PZGiven.BackgroundImage;
                            case 3:
                                if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                                else return PPOpen.BackgroundImage;
                            default:
                                return transparent.BackgroundImage;
                        }
                    }
                case 4:
                    if (s.isRover)
                    {
                        switch (n)
                        {
                            case 0:
                                if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                                else return secondGiven.BackgroundImage;
                            case 1:
                                if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                                else return epaulet.BackgroundImage;
                            default:
                                return transparent.BackgroundImage;
                        }
                    }
                    else
                    {
                        switch (n)
                        {
                            case 0:
                                if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                                else return secondGiven.BackgroundImage;
                            case 1:
                                if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                                else return greenAdjutant.BackgroundImage;
                            case 2:
                                if (s.achivement[st - 1, n]) return pictureChecked.BackgroundImage;
                                else return PPGiven.BackgroundImage;
                            default:
                                return transparent.BackgroundImage;
                        }
                    }
                case 5:
                    return trophy.BackgroundImage;
                default:
                    return null;
            }
        }
        
        string translate(bool text)
        {
            if (text) return "TAK";
            else return "NIE";
        }

        void updateTables()
        {
            dataGridViewTroop.Rows.Clear();
            dataGridViewPatrols.Rows.Clear();
            dataGridViewMasters.Rows.Clear();
            dataGridViewHelpers.Rows.Clear();
            dataGridViewAdjutants.Rows.Clear();

            int i = 0;
            foreach (Scout s in game.scoutTroop.Members)
            {
                dataGridViewTroop.Rows.Add(s.name, s.age, s.stage, s.ageSameStage, translate(s.isInstructor),
                    translate(s.isRover), achivement(s, 0), achivement(s, 1), achivement(s, 2), achivement(s, 3), translate(s.isBoss), translate(s.isAdjutant), translate(s.isPatrolMaster),
                    translate(s.isPatrolHelper), translate(s.isPatrolMember), i);
                i++;
            }

            i = 0;
            foreach (Patrol p in game.scoutTroop.Patrols)
            {
                string masterName = "";
                string helperName = "";
                if (p.patrolMaster != null) masterName = p.patrolMaster.name;
                if (p.patrolHelper != null) helperName = p.patrolHelper.name;
                dataGridViewPatrols.Rows.Add(p.name, masterName, helperName, i);
                i++;
            }

            i = 0;
            foreach (Scout s in game.scoutTroop.Adjutants)
            {
                dataGridViewAdjutants.Rows.Add(s.name, i);
                i++;
            }

            i = 0;
            foreach (Scout s in game.scoutTroop.PatrolMasters)
            {
                dataGridViewMasters.Rows.Add(s.name, i);
                i++;
            }

            i = 0;
            foreach (Scout s in game.scoutTroop.PatrolHelpers)
            {
                dataGridViewHelpers.Rows.Add(s.name, i);
                i++;
            }

           


        }

        private void ProsectTroop_Shown(object sender, EventArgs e)
        {
            updateTables();
        }

        private void removePatrol_Click(object sender, EventArgs e)
        {
            int indexPatrolS = dataGridViewPatrols.SelectedRows[0].Index;
            //int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;

            Patrol p = game.scoutTroop.Patrols[indexPatrolS];
            //Scout s = game.scoutTroop.Members[indexScoutS];
            game.scoutTroop.removePatrol(p);
            updateTables();
        }

        private void addPatrol_Click(object sender, EventArgs e)
        {
            game.scoutTroop.addNewPatrol("Żbiki");
            updateTables();
        }

        private void removeMaster_Click(object sender, EventArgs e)
        {
            int indexPatrolS = dataGridViewPatrols.SelectedRows[0].Index;
            //int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;

            Patrol p = game.scoutTroop.Patrols[indexPatrolS];
            //Scout s = game.scoutTroop.Members[indexScoutS];
            game.scoutTroop.removePatrol(p);
            updateTables();
        }

        private void makeMaster_Click(object sender, EventArgs e)
        {
            int indexPatrolS = dataGridViewPatrols.SelectedRows[0].Index;
            int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;

            Patrol p = game.scoutTroop.Patrols[indexPatrolS];
            Scout s = game.scoutTroop.Members[indexScoutS];
            game.scoutTroop.makeMaster(s, p);
            updateTables();
        }

        private void removeAdjutant_Click(object sender, EventArgs e)
        {
            
            int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;

           
            Scout s = game.scoutTroop.Members[indexScoutS];
            game.scoutTroop.removeFromAdjutants(s);
            updateTables();
        }

        private void makeAdjutant_Click(object sender, EventArgs e)
        {
            int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;


            Scout s = game.scoutTroop.Members[indexScoutS];
            game.scoutTroop.makeAdjutant(s);
            updateTables();
        }

        private void removeFromPatrol_Click(object sender, EventArgs e)
        {
            int indexPatrolS = dataGridViewPatrols.SelectedRows[0].Index;
            int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;

            Patrol p = game.scoutTroop.Patrols[indexPatrolS];
            Scout s = game.scoutTroop.Members[indexScoutS];
            game.scoutTroop.removeFromPatrol(s, p);
            updateTables();

        }

        private void addToPatrol_Click(object sender, EventArgs e)
        {
            int indexPatrolS = dataGridViewPatrols.SelectedRows[0].Index;
            int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;

            Patrol p = game.scoutTroop.Patrols[indexPatrolS];
            Scout s = game.scoutTroop.Members[indexScoutS];
            game.scoutTroop.addToPatrol(s, p);
            updateTables();
        }

        private void makeHelper_Click(object sender, EventArgs e)
        {
            int indexPatrolS = dataGridViewPatrols.SelectedRows[0].Index;
            int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;

            Patrol p = game.scoutTroop.Patrols[indexPatrolS];
            Scout s = game.scoutTroop.Members[indexScoutS];
            game.scoutTroop.makeHelper(s, p);
            updateTables();
        }

        private void removeHelper_Click(object sender, EventArgs e)
        {
            int indexPatrolS = dataGridViewPatrols.SelectedRows[0].Index;
            int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;

            Patrol p = game.scoutTroop.Patrols[indexPatrolS];
            Scout s = game.scoutTroop.Members[indexScoutS];
            game.scoutTroop.removeHelper(s, p);
            updateTables();
        }

        private void removeMember_Click(object sender, EventArgs e)
        {
            
            int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;

          
            Scout s = game.scoutTroop.Members[indexScoutS];
            game.scoutTroop.removeScout(s);
            updateTables();
        }

        private void buttonepaulet_Click(object sender, EventArgs e)
        {

        }

        private void PPstart_Click(object sender, EventArgs e)
        {
            if (game.scoutTroop.PP.age == 0)
            {
                if (game.scoutTroop.PP.isStarted)
                {
                    game.scoutTroop.PP.isEntryAllowed = true;
                    int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;
                    Scout s = game.scoutTroop.Members[indexScoutS];
                    game.scoutTroop.PP.addStudent(s);
                    game.scoutTroop.PP.start();
                    game.scoutTroop.actionPoints -= 2; 
                }
                else
                {
                    game.scoutTroop.PP.start();
                    game.scoutTroop.PP.isEntryAllowed = true;
                    int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;
                    Scout s = game.scoutTroop.Members[indexScoutS];
                    game.scoutTroop.PP.addStudent(s);
                    game.scoutTroop.actionPoints -= 5;
                }

                
            }
            else
            {
                MessageBox.Show("Nie możesz wysłać ludzi do trwającego już kursu! :(", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void PZstart_Click(object sender, EventArgs e)
        {
            if (game.scoutTroop.PZ.age == 0)
            {
                if (game.scoutTroop.PZ.isStarted)
                {
                    game.scoutTroop.PZ.isEntryAllowed = true;
                    int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;
                    Scout s = game.scoutTroop.Members[indexScoutS];
                    game.scoutTroop.PZ.addStudent(s);
                    game.scoutTroop.PZ.start();
                    game.scoutTroop.actionPoints -= 2;
                }
                else
                {
                    game.scoutTroop.PZ.start();
                    game.scoutTroop.PZ.isEntryAllowed = true;
                    int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;
                    Scout s = game.scoutTroop.Members[indexScoutS];
                    game.scoutTroop.PZ.addStudent(s);
                    game.scoutTroop.actionPoints -= 5;
                }


            }
            else
            {
                MessageBox.Show("Nie możesz wysłać ludzi do trwającego już kursu! :(", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ZSstart_Click(object sender, EventArgs e)
        {
            if (game.scoutTroop.ZS.age == 0)
            {
                if (game.scoutTroop.ZS.isStarted)
                {
                    game.scoutTroop.ZS.isEntryAllowed = true;
                    int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;
                    Scout s = game.scoutTroop.Members[indexScoutS];
                    game.scoutTroop.ZS.addStudent(s);
                    game.scoutTroop.ZS.start();
                    game.scoutTroop.actionPoints -= 2;
                }
                else
                {
                    game.scoutTroop.ZS.start();
                    game.scoutTroop.ZS.isEntryAllowed = true;
                    int indexScoutS = dataGridViewTroop.SelectedRows[0].Index;
                    Scout s = game.scoutTroop.Members[indexScoutS];
                    game.scoutTroop.ZS.addStudent(s);
                    game.scoutTroop.actionPoints -= 5;
                }


            }
            else
            {
                MessageBox.Show("Nie możesz wysłać ludzi do trwającego już kursu! :(", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
