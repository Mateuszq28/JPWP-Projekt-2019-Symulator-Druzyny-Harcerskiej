﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public partial class home : Form
    {
        public Game game = new Game();
        DrawingAndDisplay drawAndDisp = new DrawingAndDisplay();
        public int timeSeconds;
        Scout blankScout = new Scout("");
        Scout scoutHover = null;
        Scout scoutLastHover = null;
        Scout scoutLastClick = null;
        int mouseX = 0;
        int mouseY = 0;
        int orderNum = 1;

        public home()
        {
            InitializeComponent();
            blankScout.stage = 6;
        }


        void infoConstSet()
        {
            //shawl and scout troop name
            labelName.Text = game.scoutTroop.nameNum + " " + game.scoutTroop.name;
            labelName.Font = new Font("Verdana", (float)9.75, FontStyle.Bold);
            labelName.Left = (200 - labelName.Size.Width) / 2;
            labelName.Visible = false;
            drawAndDisp.drawShawl(panelSide, game.scoutTroop, labelName);
            //timer
            labelTimer.Text = "00:00";
            timeSeconds = 0;
            timer1.Start();
        }

        void infoUpdate()
        {
            //Labels texts
            labelPoints.Text = "Punkty właściwe: " + game.scoutTroop.points;
            labelMemCount.Text = "Liczba członków: " + game.scoutTroop.membersCounter;
            labelActionPoints.Text = "Punkty rozwoju: " + game.scoutTroop.actionPoints;
            labelAge.Text = "Wiek drużyny: " + game.scoutTroop.age;

            //Warning Colors on labels
            if (game.scoutTroop.age >= game.ageLimit - 1)
                labelAge.ForeColor = Color.Red;
            if (game.scoutTroop.actionPoints < 1)
                labelActionPoints.ForeColor = Color.Red;
        }

        public void setDeckImage(bool isMaleTeam)
        {
            if (isMaleTeam)
            {
                Card1.BackgroundImage = MAN1.BackgroundImage;
                Card2.BackgroundImage = MAN2.BackgroundImage;
                Card3i.BackgroundImage = MAN3i.BackgroundImage;
                Card3r.BackgroundImage = MAN3r.BackgroundImage;
                Card4i.BackgroundImage = MAN4i.BackgroundImage;
                Card4r.BackgroundImage = MAN4r.BackgroundImage;
                Card5i.BackgroundImage = MAN5i.BackgroundImage;
                Card5r.BackgroundImage = MAN5r.BackgroundImage;
            }
            else
            {
                Card1.BackgroundImage = GIRL1.BackgroundImage;
                Card2.BackgroundImage = GIRL2.BackgroundImage;
                Card3i.BackgroundImage = GIRL3i.BackgroundImage;
                Card3r.BackgroundImage = GIRL3r.BackgroundImage;
                Card4i.BackgroundImage = GIRL4i.BackgroundImage;
                Card4r.BackgroundImage = GIRL4r.BackgroundImage;
                Card5i.BackgroundImage = GIRL5i.BackgroundImage;
                Card5r.BackgroundImage = GIRL5r.BackgroundImage;
            }

            drawAndDisp.setDeckImage(Card1.BackgroundImage, Card2.BackgroundImage, Card3i.BackgroundImage, Card3r.BackgroundImage, Card4i.BackgroundImage, Card4r.BackgroundImage, Card5i.BackgroundImage, Card5r.BackgroundImage);
        }

        void startNewGame()
        {
            FormStartGame formStart = new FormStartGame(game);
            formStart.ShowDialog();

            if (game.isStarted == true)
            {
                setDeckImage(game.scoutTroop.isMaleTeam);
                game.reset();
                infoConstSet();
                infoUpdate();
                pictureBoxBuforing.Visible = false;
                MessageBox.Show(game.starterPack(), "POZYCJA STARTOWA", MessageBoxButtons.OK, MessageBoxIcon.Information);
                scoutLastClick = game.scoutTroop.Members[0];
                scoutLastHover = game.scoutTroop.Members[0];
                infoUpdate();
                previewCard(game.scoutTroop.Members[0]);
                game.playRound();
                infoUpdate();
                drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
            }
        }

        private void buttonNewGame_Click(object sender, EventArgs e)
        {
            if (game.isStarted == false)
            {
                startNewGame();
            }
            else
            {
                game.isRunning = false;
                pictureBoxBuforing.Visible = true;

                //Restarter restarter = new Restarter(game);
                //restarter.ShowDialog();
                DialogResult result = MessageBox.Show("Czy na pewno chcesz ropocząć grę od nowa ?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes) game.isStarted = false;
                else game.isStarted = true;

                if (game.isRunning == false && game.isStarted == false)
                {
                    labelTimer.Text = "00:00";
                    unviewCard(scoutLastClick);
                    startNewGame();
                }
                else
                {
                    pictureBoxBuforing.Visible = false;
                    drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
                }
            }
        }

        void viewCardDescription(Scout s)
        {
            int stage = s.stage;

            //Name
            labelAlias.Text = s.name + " " + toRoman(stage);
            //age (Staż)
            if (stage < 5)
            {
                int warningCounter;
                if (stage > 2)
                {
                    warningCounter = 5 - (int)(2 * s.ageSameStage);
                }
                else
                {
                    warningCounter = 3 - (int)(2 * s.ageSameStage);
                }
                labelExp.Text = "Staż: " + s.age.ToString("0.#") + " (" + toRoman(warningCounter) + ")";

                if (warningCounter == 2) labelExp.ForeColor = Color.Yellow;
                if (warningCounter == 1) labelExp.ForeColor = Color.Red;
            }
            else
            {
                labelExp.Text = "Staż: " + s.age.ToString("0.#");
                labelExp.ForeColor = Color.White;
            }
        }


        void viewCard(Scout s)
        {
            bool state = true;
            cardFrame.Visible = state;
            bool isInstructor = s.isInstructor;

            switch (s.stage)
            {
                case 1:
                    card11.Visible = state;
                    card12.Visible = state;
                    if (s.achivement[0, 0]) card11.BackgroundImage = checkSymbol.BackgroundImage;
                    if (s.achivement[0, 1]) card12.BackgroundImage = checkSymbol.BackgroundImage;
                    break;
                case 2:
                    card21.Visible = state;
                    card22.Visible = state;
                    card23.Visible = state;
                    card24.Visible = state;
                    if (s.achivement[1, 0]) card21.BackgroundImage = checkSymbol.BackgroundImage;
                    if (s.achivement[1, 1]) card22.BackgroundImage = checkSymbol.BackgroundImage;
                    if (s.achivement[1, 2]) card23.BackgroundImage = checkSymbol.BackgroundImage;
                    if (s.achivement[1, 3]) card24.BackgroundImage = checkSymbol.BackgroundImage;
                    break;
                case 3:
                    if (isInstructor)
                    {
                        card3i1.Visible = state;
                        card3i2.Visible = state;
                        card3i3.Visible = state;
                        card3i4.Visible = state;
                        if (s.achivement[2, 0]) card3i1.BackgroundImage = checkSymbol.BackgroundImage;
                        if (s.achivement[2, 1]) card3i2.BackgroundImage = checkSymbol.BackgroundImage;
                        if (s.achivement[2, 2]) card3i3.BackgroundImage = checkSymbol.BackgroundImage;
                        if (s.achivement[2, 3]) card3i4.BackgroundImage = checkSymbol.BackgroundImage;
                    }
                    else
                    {
                        card3r1.Visible = state;
                        card3r2.Visible = state;
                        if (s.achivement[2, 0]) card3r1.BackgroundImage = checkSymbol.BackgroundImage;
                        if (s.achivement[2, 1]) card3r2.BackgroundImage = checkSymbol.BackgroundImage;
                    }
                    break;
                case 4:
                    if (isInstructor)
                    {
                        card4i1.Visible = state;
                        card4i2.Visible = state;
                        card4i3.Visible = state;
                        if (s.achivement[3, 0]) card4i1.BackgroundImage = checkSymbol.BackgroundImage;
                        if (s.achivement[3, 1]) card4i2.BackgroundImage = checkSymbol.BackgroundImage;
                        if (s.achivement[3, 2]) card4i3.BackgroundImage = checkSymbol.BackgroundImage;
                    }
                    else
                    {
                        card4r1.Visible = state;
                        card4r2.Visible = state;
                        if (s.achivement[3, 0]) card4r1.BackgroundImage = checkSymbol.BackgroundImage;
                        if (s.achivement[3, 1]) card4r2.BackgroundImage = checkSymbol.BackgroundImage;
                    }
                    break;
                case 5:
                    card5.Visible = state;
                    break;
                default:
                    break;
            }
        }


        void unviewCard(Scout s)
        {
            bool state = false;
            cardFrame.Visible = state;
            bool isInstructor = s.isInstructor;

            switch (s.stage)
            {
                case 1:
                    card11.Visible = state;
                    card12.Visible = state;
                    card11.BackgroundImage = Istopien.BackgroundImage;
                    card12.BackgroundImage = chusta.BackgroundImage;
                    break;
                case 2:
                    card21.Visible = state;
                    card22.Visible = state;
                    card23.Visible = state;
                    card24.Visible = state;
                    card21.BackgroundImage = Izdany.BackgroundImage;
                    card22.BackgroundImage = krzyz.BackgroundImage;
                    card23.BackgroundImage = PZproba.BackgroundImage;
                    card24.BackgroundImage = ZSproba.BackgroundImage;
                    break;
                case 3:
                    if (isInstructor)
                    {
                        card3i1.Visible = state;
                        card3i2.Visible = state;
                        card3i3.Visible = state;
                        card3i4.Visible = state;
                        card3i1.BackgroundImage = IIstopien.BackgroundImage;
                        card3i2.BackgroundImage = brazowySznur.BackgroundImage;
                        card3i3.BackgroundImage = PZzdany.BackgroundImage;
                        card3i4.BackgroundImage = PPproba.BackgroundImage;
                    }
                    else
                    {
                        card3r1.Visible = state;
                        card3r2.Visible = state;
                        card3r1.BackgroundImage = IIzdany.BackgroundImage;
                        card3r2.BackgroundImage = ZSzdany.BackgroundImage;
                    }
                    break;
                case 4:
                    if (isInstructor)
                    {
                        card4i1.Visible = state;
                        card4i2.Visible = state;
                        card4i3.Visible = state;
                        card4i1.BackgroundImage = IIzdany.BackgroundImage;
                        card4i2.BackgroundImage = zielonySznur.BackgroundImage;
                        card4i3.BackgroundImage = PPzdany.BackgroundImage;
                    }
                    else
                    {
                        card4r1.Visible = state;
                        card4r2.Visible = state;
                        card4r1.BackgroundImage = IIzdany.BackgroundImage;
                        card4r2.BackgroundImage = pagon.BackgroundImage;
                    }
                    break;
                case 5:
                    card5.Visible = state;
                    break;
                default:
                    break;
            }
        }

        void unviewCard()
        {
            bool state = false;
            cardFrame.Visible = state;
            card11.Visible = state;
            card12.Visible = state;
            card11.BackgroundImage = Istopien.BackgroundImage;
            card12.BackgroundImage = chusta.BackgroundImage;
            card21.Visible = state;
            card22.Visible = state;
            card23.Visible = state;
            card24.Visible = state;
            card21.BackgroundImage = Izdany.BackgroundImage;
            card22.BackgroundImage = krzyz.BackgroundImage;
            card23.BackgroundImage = PZproba.BackgroundImage;
            card24.BackgroundImage = ZSproba.BackgroundImage;
            card3i1.Visible = state;
            card3i2.Visible = state;
            card3i3.Visible = state;
            card3i4.Visible = state;
            card3i1.BackgroundImage = IIstopien.BackgroundImage;
            card3i2.BackgroundImage = brazowySznur.BackgroundImage;
            card3i3.BackgroundImage = PZzdany.BackgroundImage;
            card3i4.BackgroundImage = PPproba.BackgroundImage;
            card3r1.Visible = state;
            card3r2.Visible = state;
            card3r1.BackgroundImage = IIzdany.BackgroundImage;
            card3r2.BackgroundImage = ZSzdany.BackgroundImage;
            card4i1.Visible = state;
            card4i2.Visible = state;
            card4i3.Visible = state;
            card4i1.BackgroundImage = IIzdany.BackgroundImage;
            card4i2.BackgroundImage = zielonySznur.BackgroundImage;
            card4i3.BackgroundImage = PPzdany.BackgroundImage;
            card4r1.Visible = state;
            card4r2.Visible = state;
            card4r1.BackgroundImage = IIzdany.BackgroundImage;
            card4r2.BackgroundImage = pagon.BackgroundImage;
            card5.Visible = state;
        }

        void previewCard(Scout s)
        {
            int stage = s.stage;

            viewCardDescription(s);

            //PictureBox Podglad0
            string letter;
            string nameCard;
            if (s.isInstructor) letter = "i";
            else if (s.isRover) letter = "r";
            else letter = "";
            nameCard = stage + letter;
            switch (nameCard)
            {
                case "1":
                    picturePodglad0.BackgroundImage = Card1.BackgroundImage;
                    break;
                case "2":
                    picturePodglad0.BackgroundImage = Card2.BackgroundImage;
                    break;
                case "3i":
                    picturePodglad0.BackgroundImage = Card3i.BackgroundImage;
                    break;
                case "3r":
                    picturePodglad0.BackgroundImage = Card3r.BackgroundImage;
                    break;
                case "4i":
                    picturePodglad0.BackgroundImage = Card4i.BackgroundImage;
                    break;
                case "4r":
                    picturePodglad0.BackgroundImage = Card4r.BackgroundImage;
                    break;
                case "5i":
                    picturePodglad0.BackgroundImage = Card5i.BackgroundImage;
                    break;
                case "5r":
                    picturePodglad0.BackgroundImage = Card5r.BackgroundImage;
                    break;
                default:
                    break;
            }
        }

        string toRoman(int num)
        {
            string rNum;
            switch (num)
            {
                case 1:
                    rNum = "I";
                    break;
                case 2:
                    rNum = "II";
                    break;
                case 3:
                    rNum = "III";
                    break;
                case 4:
                    rNum = "IV";
                    break;
                case 5:
                    rNum = "V";
                    break;
                default:
                    rNum = "";
                    break;
            }
            return rNum;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Floor_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void buttonNewGame_MouseEnter(object sender, EventArgs e)
        {
            buttonNewGame.BackColor = Color.FromArgb(194, 210, 242);
        }

        private void buttonNewGame_MouseLeave(object sender, EventArgs e)
        {
            buttonNewGame.BackColor = Color.FromArgb(81, 118, 166);
            
        }

        private void pictureLogo_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://lesnaszkolka.org");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (game.scoutTroop.actionPoints > 2)
            {
                Random rnd = new Random();
                int los = rnd.Next(6) + 1;
                game.scoutTroop.actionPoints += los - 2;
                MessageBox.Show("Wylosowałeś " + los + ". Punkty zostały naliczone", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                infoUpdate();
            }
            else
                MessageBox.Show("Masz za mało punktó na biwak :(", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonDruzyna_MouseEnter(object sender, EventArgs e)
        {
            buttonDruzyna.BackColor = Color.FromArgb(194, 210, 242);
        }

        private void buttonAkcje_MouseEnter(object sender, EventArgs e)
        {
            buttonAkcje.BackColor = Color.FromArgb(194, 210, 242);
        }

        private void buttonKursy_MouseEnter(object sender, EventArgs e)
        {
            buttonKursy.BackColor = Color.FromArgb(194, 210, 242);
        }

        private void buttonObrzed_MouseEnter(object sender, EventArgs e)
        {
            buttonPolrocze.BackColor = Color.FromArgb(194, 210, 242);
        }

        private void buttonDruzyna_MouseLeave(object sender, EventArgs e)
        {
            buttonDruzyna.BackColor = Color.FromArgb(81, 118, 166);
        }

        private void buttonAkcje_MouseLeave(object sender, EventArgs e)
        {
            buttonAkcje.BackColor = Color.FromArgb(81, 118, 166);
        }

        private void buttonKursy_MouseLeave(object sender, EventArgs e)
        {
            buttonKursy.BackColor = Color.FromArgb(81, 118, 166);
        }

        private void buttonObrzed_MouseLeave(object sender, EventArgs e)
        {
            buttonPolrocze.BackColor = Color.FromArgb(81, 118, 166);
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (game.isRunning == true)
            {
                timeSeconds++;
                var timespan = TimeSpan.FromSeconds(timeSeconds);
                labelTimer.Text = timespan.ToString(@"mm\:ss");
            }
        }

        private void pictureBoxStop_Click(object sender, EventArgs e)
        {
            if (game.isRunning)
            {
                game.isRunning = false;
                pictureBoxBuforing.Visible = true;
                MessageBox.Show("Naciśnij OK, aby wrócić do gry.", "Czas został zatrzymany!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                pictureBoxBuforing.Visible = false;
                drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
                game.isRunning = true;
            }
        }


        private void buttonPolrocze_Click(object sender, EventArgs e)
        {
            if (game.isRunning == true)
            {
                DiceRoller diceRoll = new DiceRoller(game);
                diceRoll.ShowDialog();
                infoUpdate();
                double newPoints = game.endRound();
                infoUpdate();

                if (game.isRunning == true)
                {
                    MessageBox.Show("Twoi harcerze wygenerowali " + newPoints + " Punktów Rozwoju (PR).", "Rozpoczęto Nowe Półrocze!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (game.scoutTroop.removeRaport != "")
                        MessageBox.Show(game.scoutTroop.removeRaport, "Przykre wieści", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    game.playRound();
                    infoUpdate();
                    drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
                }
            }
            else
                infoUpdate();
        }

        private void panelMain_MouseMove(object sender, MouseEventArgs e)
        {
            scoutHover = drawAndDisp.findPerson(e.X, e.Y);
            if (scoutHover != null && scoutHover != blankScout)
            {
                previewCard(scoutHover);
                mouseX = e.X;
                mouseY = e.Y;
                scoutLastHover = drawAndDisp.findPerson(mouseX, mouseY);
            }
        }

        private void panelMain_Click(object sender, EventArgs e)
        {
            if (scoutHover != null && scoutHover != blankScout)
            {
                unviewCard(scoutLastClick);
                scoutLastClick = drawAndDisp.findPerson(mouseX, mouseY);
                viewCard(scoutLastClick);
            }
            else
            {
                unviewCard(scoutLastClick);
            }
        
        }

        private void card12_MouseClick(object sender, MouseEventArgs e)
        {
            //shawlgiving
            //chustowanie
            if (game.isRunning == true)
            {
                if (scoutLastClick.achivement[0, 1] == false)
                {
                    if (game.shawlGiving == false)
                    {
                        if (game.scoutTroop.actionPoints >= 2)
                        {
                            game.scoutTroop.actionPoints -= 2;
                            if (game.scoutTroop.isMaleTeam)
                                MessageBox.Show("Zapas starczy Ci na całe półrocze!", "KUPIŁEŚ CHUSTY", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            else
                                MessageBox.Show("Zapas starczy Ci na całe półrocze!", "KUPIŁAŚ CHUSTY", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            game.shawlGiving = true;
                        }
                        else
                        {
                            MessageBox.Show("Masz za mało pieniędzy, aby kupić chusty :(", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        if (game.scoutTroop.actionPoints >= 1)
                        {
                            game.scoutTroop.actionPoints -= 1;
                            if (game.scoutTroop.isMaleTeam)
                                MessageBox.Show(scoutLastClick.name + " właśnie został przyjęty w poczetek członków drużyny!", "Rozkaz S" + orderNum);
                            else
                                MessageBox.Show(scoutLastClick.name + " właśnie został przyjęty w poczetek członków drużyny!", "Rozkaz S" + orderNum);
                            orderNum++;
                            scoutLastClick.achivement[0, 1] = true;
                            if (scoutLastClick.checkIfPromotion())
                            {
                                MessageBox.Show(scoutLastClick.name + " pnie się na szczeblach harcerskiej kariery!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                unviewCard();
                            }
                            drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
                            viewCard(scoutLastClick);
                        }
                        else
                        {
                            MessageBox.Show("Masz jeszcze chusty, ale skończyły się pochodnie :(", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(scoutLastClick.name + " nosi już barwy drużyny z Dumą!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                infoUpdate();
            }
        }

        private void card11_Click(object sender, EventArgs e)
        {
            //firstGradeOpen
            //Otwarcie I stopnia
            if (game.isRunning == true)
            {
                if (scoutLastClick.achivement[0, 0] == false)
                {
                    if (game.firstGradeOpen == false)
                    {
                        if (game.scoutTroop.actionPoints >= 2)
                        {
                            game.scoutTroop.actionPoints -= 2;
                            MessageBox.Show("Otwieram próbę na I stopień harcerski następującym druhom i druhnom...", "Rozkaz L" + orderNum);
                            game.firstGradeOpen = true;
                            orderNum++;
                        }
                        else
                        {
                            MessageBox.Show("Ah, skończyły się kartki na rozkazy...\nMam nadzieję, że masz wystarczająco PR, aby je kupić?", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        if (game.scoutTroop.actionPoints >= 1)
                        {
                            game.scoutTroop.actionPoints -= 1;
                            if (game.scoutTroop.isMaleTeam)
                                MessageBox.Show("Otwieram próbę na stopień młodzika druhowi \"" + scoutLastClick.name + "\".", "Rozkaz L" + orderNum);
                            else
                                MessageBox.Show("Otwieram próbę na stopień ochotniczki druhnie \"" + scoutLastClick.name + "\".", "Rozkaz L" + orderNum);
                            orderNum++;
                            scoutLastClick.achivement[0, 0] = true;
                            if (scoutLastClick.checkIfPromotion())
                            {
                                if (game.scoutTroop.isMaleTeam)
                                    MessageBox.Show(scoutLastClick.name + " się postrzał...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                else
                                    MessageBox.Show(scoutLastClick.name + " się postrzała...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                unviewCard();
                            }
                            drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
                            viewCard(scoutLastClick);
                        }
                        else
                        {
                            MessageBox.Show("Mamy kartki, ale gdzie jest długopis?", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(scoutLastClick.name + " ma już otwarty I stopień!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                infoUpdate();
            }
        }

        private void card21_Click(object sender, EventArgs e)
        {
            //firstGradeClose
            //Zamknięcie I stopnia
            if (game.isRunning == true)
            {
                if (scoutLastClick.achivement[1, 0] == false)
                {
                    if (game.firstGradeGiving == false)
                    {
                        if (game.scoutTroop.actionPoints >= 2)
                        {
                            game.scoutTroop.actionPoints -= 2;
                            MessageBox.Show("Zamykam z wynikiem pozytywnym próbę na I stopień harcerski następującym druhom i druhnom...", "Rozkaz L" + orderNum);
                            game.firstGradeGiving = true;
                            orderNum++;
                        }
                        else
                        {
                            MessageBox.Show("Ah, skończyły się kartki na rozkazy...\nMam nadzieję, że masz wystarczająco PR, aby je kupić?", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        if (game.scoutTroop.actionPoints >= 1)
                        {
                            game.scoutTroop.actionPoints -= 1;
                            if (game.scoutTroop.isMaleTeam)
                                MessageBox.Show("Zamykam zwynikiem pozytywnym próbę na stopień młodzika druhowi \"" + scoutLastClick.name + "\".", "Rozkaz L" + orderNum);
                            else
                                MessageBox.Show("Zamykam zwynikiem pozytywnym próbę na stopień ochotniczki druhnie \"" + scoutLastClick.name + "\".", "Rozkaz L" + orderNum);
                            orderNum++;
                            scoutLastClick.achivement[1, 0] = true;
                            if (scoutLastClick.checkIfPromotion())
                            {
                                if (game.scoutTroop.isMaleTeam)
                                    MessageBox.Show(scoutLastClick.name + " się postrzał...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                else
                                    MessageBox.Show(scoutLastClick.name + " się postrzała...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                unviewCard();
                            }
                            drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
                            viewCard(scoutLastClick);
                        }
                        else
                        {
                            MessageBox.Show("Mamy kartki, ale gdzie jest długopis?", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(scoutLastClick.name + " ma już I stopień!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                infoUpdate();
            }
        }

        void openSecondGrade()
        {
            //secondGradeOpen
            //Otwarcie II stopnia
            if (game.isRunning == true)
            {
                if (scoutLastClick.achivement[2, 0] == false)
                {
                    if (game.secondGradeOpen == false)
                    {
                        if (game.scoutTroop.actionPoints >= 3)
                        {
                            game.scoutTroop.actionPoints -= 3;
                            MessageBox.Show("Otwieram próbę na II stopień harcerski następującym druhom i druhnom...", "Rozkaz L" + orderNum);
                            game.secondGradeOpen = true;
                            orderNum++;
                        }
                        else
                        {
                            MessageBox.Show("Ah, skończyły się kartki na rozkazy...\nMam nadzieję, że masz wystarczająco PR, aby je kupić?", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        if (game.scoutTroop.actionPoints >= 2)
                        {
                            game.scoutTroop.actionPoints -= 2;
                            if (game.scoutTroop.isMaleTeam)
                                MessageBox.Show("Otwieram próbę na stopień wywiadowcy druhowi \"" + scoutLastClick.name + "\".", "Rozkaz L" + orderNum);
                            else
                                MessageBox.Show("Otwieram próbę na stopień tropicielki druhnie \"" + scoutLastClick.name + "\".", "Rozkaz L" + orderNum);
                            orderNum++;
                            scoutLastClick.achivement[2, 0] = true;
                            if (scoutLastClick.checkIfPromotion())
                            {
                                if (game.scoutTroop.isMaleTeam)
                                    MessageBox.Show(scoutLastClick.name + " się postrzał...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                else
                                    MessageBox.Show(scoutLastClick.name + " się postrzała...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                unviewCard();
                            }
                            drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
                            viewCard(scoutLastClick);
                        }
                        else
                        {
                            MessageBox.Show("Mamy kartki, ale gdzie jest długopis?", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(scoutLastClick.name + " ma już otwarty II stopień!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                infoUpdate();
            }
        }

        private void card3i1_Click(object sender, EventArgs e)
        {
            openSecondGrade();
        }

        private void card3r1_Click(object sender, EventArgs e)
        {
            openSecondGrade();
        }

        void giveSecondGrade()
        {
            //secondGradeClose
            //Zamknięcie II stopnia
            if (game.isRunning == true)
            {
                if (scoutLastClick.achivement[3, 0] == false)
                {
                    if (game.secondGradeGiving == false)
                    {
                        if (game.scoutTroop.actionPoints >= 3)
                        {
                            game.scoutTroop.actionPoints -= 3;
                            MessageBox.Show("Zamykam z wynikiem pozytywnym próbę na II stopień harcerski następującym druhom i druhnom...", "Rozkaz L" + orderNum);
                            game.secondGradeGiving = true;
                            orderNum++;
                        }
                        else
                        {
                            MessageBox.Show("Ah, skończyły się kartki na rozkazy...\nMam nadzieję, że masz wystarczająco PR, aby je kupić?", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        if (game.scoutTroop.actionPoints >= 2)
                        {
                            game.scoutTroop.actionPoints -= 2;
                            if (game.scoutTroop.isMaleTeam)
                                MessageBox.Show("Zamykam zwynikiem pozytywnym próbę na stopień wywiadowcy druhowi \"" + scoutLastClick.name + "\".", "Rozkaz L" + orderNum);
                            else
                                MessageBox.Show("Zamykam zwynikiem pozytywnym próbę na stopień tropicielki druhnie \"" + scoutLastClick.name + "\".", "Rozkaz L" + orderNum);
                            orderNum++;
                            scoutLastClick.achivement[3, 0] = true;
                            if (scoutLastClick.checkIfPromotion())
                            {
                                if (game.scoutTroop.isMaleTeam)
                                    MessageBox.Show(scoutLastClick.name + " się postrzał...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                else
                                    MessageBox.Show(scoutLastClick.name + " się postrzała...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                unviewCard();
                            }
                            drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
                            viewCard(scoutLastClick);
                        }
                        else
                        {
                            MessageBox.Show("Mamy kartki, ale gdzie jest długopis?", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(scoutLastClick.name + " ma już II stopień!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                infoUpdate();
            }
        }

        private void card4i1_Click(object sender, EventArgs e)
        {
            giveSecondGrade();
        }

        private void card4r1_Click(object sender, EventArgs e)
        {
            giveSecondGrade();
        }

        private void card5_Click(object sender, EventArgs e)
        {
            if (game.isRunning == true)
            {
                if (game.scoutTroop.isMaleTeam)
                    MessageBox.Show(scoutLastClick.name + " jest już samodzielny :)", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show(scoutLastClick.name + " jest już samodzielna :)", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void card22_Click(object sender, EventArgs e)
        {
            //crossgiving
            //krzyżowanie
            if (game.isRunning == true)
            {
                if (scoutLastClick.achivement[1, 1] == false)
                {
                    if (game.crossGiving == false)
                    {
                        if (game.scoutTroop.actionPoints >= 3)
                        {
                            game.scoutTroop.actionPoints -= 3;
                            if (game.scoutTroop.isMaleTeam)
                                MessageBox.Show("Zapas starczy Ci na całe półrocze!", "KUPIŁEŚ KRZYŻE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            else
                                MessageBox.Show("Zapas starczy Ci na całe półrocze!", "KUPIŁAŚ KRZYŻE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            game.crossGiving = true;
                        }
                        else
                        {
                            MessageBox.Show("Masz za mało pieniędzy, aby kupić krzyże :(", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        if (game.scoutTroop.actionPoints >= 1)
                        {
                            game.scoutTroop.actionPoints -= 1;
                            if (game.scoutTroop.isMaleTeam)
                                MessageBox.Show(scoutLastClick.name + " został dopuszczony do złożenia przyżeczenia harcerskiego.", "Rozkaz S" + orderNum);
                            else
                                MessageBox.Show(scoutLastClick.name + " została dopuszczona do złożenia przyżeczenia harcerskiego.", "Rozkaz S" + orderNum);
                            orderNum++;
                            scoutLastClick.achivement[1, 1] = true;
                            if (scoutLastClick.checkIfPromotion())
                            {
                                MessageBox.Show(scoutLastClick.name + " pnie się na szczeblach harcerskiej kariery!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                unviewCard();
                            }
                            drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
                            viewCard(scoutLastClick);
                        }
                        else
                        {
                            MessageBox.Show("Masz jeszcze krzyże, ale skończyły się znicze :(", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                else
                {
                    if (game.scoutTroop.isMaleTeam)
                        MessageBox.Show(scoutLastClick.name + " złożył już przyżeczenie harcerskie. Krzyż dumnie mieni się na jego piersi!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show(scoutLastClick.name + " złożyła już przyżeczenie harcerskie.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                infoUpdate();
            }
        }

        private void card4r2_Click(object sender, EventArgs e)
        {
            //epauletteGiving
            //Pagon wędrowniczy
            if (game.isRunning == true)
            {
                if (scoutLastClick.achivement[3, 1] == false)
                {
                    if (game.epauletGiving == false)
                    {
                        if (game.scoutTroop.actionPoints >= 5)
                        {
                            game.scoutTroop.actionPoints -= 5;
                            if (game.scoutTroop.isMaleTeam)
                                MessageBox.Show("Obrzęd przygotowany. Twoją drużynę wkrótce zasilą nowi wędrownicy.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            else
                                MessageBox.Show("Obrzęd przygotowany. Twoją drużynę wkrótce zasilą nowe wędrowniczki.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            game.epauletGiving = true;
                        }
                        else
                        {
                            MessageBox.Show("Pogoda nie pozwoliła na obrzęd :(", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        if (game.scoutTroop.actionPoints >= 2)
                        {
                            game.scoutTroop.actionPoints -= 2;
                            if (game.scoutTroop.isMaleTeam)
                                MessageBox.Show(scoutLastClick.name + " został dopuszczony do grona wędrowników.", "Rozkaz S" + orderNum);
                            else
                                MessageBox.Show(scoutLastClick.name + " została dopuszczona do grona wędrowniczek.", "Rozkaz S" + orderNum);
                            orderNum++;
                            scoutLastClick.achivement[3, 1] = true;
                            if (scoutLastClick.checkIfPromotion())
                            {
                                MessageBox.Show(scoutLastClick.name + " pnie się na szczeblach harcerskiej kariery!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                unviewCard();
                            }
                            drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
                            viewCard(scoutLastClick);
                        }
                        else
                        {
                            MessageBox.Show("Masz za mało pagonów :(", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                else
                {
                    MessageBox.Show(scoutLastClick.name + " jest już członkiem jednostki wędrowniczej.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                infoUpdate();
            }
        }

        private void buttonDruzyna_Click(object sender, EventArgs e)
        {
            ProsectTroop prospect = new ProsectTroop(game);
            prospect.ShowDialog();
            infoUpdate();
            drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
        }

        private void buttonKursy_Click(object sender, EventArgs e)
        {
            if (game.scoutTroop.actionPoints > 6)
            {
                Random rnd = new Random();
                int los = rnd.Next(3) + 1;
                game.scoutTroop.actionPoints -= 6;
                int num;
                switch (los)
                {
                    case 1:
                        num = 6;
                        break;
                    case 2:
                        num = 8;
                        break;
                
                    default:
                        num = 10;
                        break;
                }
                MessageBox.Show("Na nabór przyszło " + num + "osób.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                game.scoutTroop.addScout(num);
                drawAndDisp.drawScoutTroop(panelMain, game.scoutTroop);
                infoUpdate();
            }
            else
                MessageBox.Show("Masz za mało punktó na nabór :(", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
