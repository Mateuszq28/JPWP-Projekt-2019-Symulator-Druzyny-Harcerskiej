﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public class Game
    {
        public ScoutTroop scoutTroop = new ScoutTroop();
        public bool isStarted = false;
        public bool isRunning = false;
        public int ageLimit = 10;
        string [] adage = {"Załóż mundur i przypnij lilijkę", "Czapkę na bakier włóż!", "W szeregu stań, wśród harcerzy", "I razem z nami w świat rusz"};

        //events
        public bool shawlGiving = false;
        public bool firstGradeOpen = false;
        public bool secondGradeOpen = false;
        public bool epauletGiving = false;
        public bool crossGiving = false;
        public bool firstGradeGiving = false;
        public bool secondGradeGiving = false;
        public bool makePatrolHelpers = false;
        public bool makeAdjutants = false;
        public bool makePatrolMasters = false;
        public bool makePatrols = false;



        /// <summary>
        /// Reset game
        /// </summary>
        public void reset()
        {
            scoutTroop.reset();
            isStarted = true;
            isRunning = true;
            MyTest.nameSystemTest(scoutTroop);
            MyTest.freeActionPoints(scoutTroop);
        }

        /// <summary>
        /// Ends game
        /// </summary>
        void endGame()
        {
            isRunning = false;
            isStarted = false;
            Restarter restarter = new Restarter(this);
            restarter.Show();
        }

        /// <summary>
        /// Ends round
        /// </summary>
        public double endRound()
        {
            double newPoints;
            newPoints = scoutTroop.scoutsGeneratePoints();
            scoutTroop.addAge();
            scoutTroop.removeOldScouts();
            scoutTroop.countPoints();

            if (scoutTroop.age > ageLimit)
            {
                endGame();
            }

            return newPoints;
        }

        /// <summary>
        /// Plays round
        /// </summary>
        public void playRound()
        {
            shawlGiving = false;
            firstGradeOpen = false;
            secondGradeOpen = false;
            epauletGiving = false;
            crossGiving = false;
            firstGradeGiving = false;
            secondGradeGiving = false;
            makePatrolHelpers = false;
            makeAdjutants = false;
            makePatrolMasters = false;
            makePatrols = false;
            scoutTroop.PZ.isEntryAllowed = false;
            scoutTroop.PP.isEntryAllowed = false;
            scoutTroop.ZS.isEntryAllowed = false;
        }

        /// <summary>
        /// Set start ScoutTroop (New game)
        /// </summary>
        public string starterPack()
        {
            Random rnd = new Random();
            int startOption = rnd.Next(3);
            string message;

            switch (startOption)
            {
                case 0:
                    if (scoutTroop.isMaleTeam)
                        message = "Jednostka ma drużynowego (Instruktor Starszy), przybocznego (Instruktor Starszy), " +
                        "dwóch zastępowych (Instruktor) i dwóch podzastępowych (Młody Instruktor).";
                    else
                        message = "Jednostka ma drużynową (Instruktor Starszy), przyboczną (Instruktor Starszy), " +
                        "dwie zastępowe (Instruktor) i dwie podzastępowe (Młody Instruktor).";
                    //boss
                    scoutTroop.addScout(1);
                    scoutTroop.Members[0].name = scoutTroop.boss;
                    scoutTroop.makeBoss(scoutTroop.Members[0]);
                    //another scouts
                    scoutTroop.addScout(5);
                    //adjutant
                    scoutTroop.Members[1].isInstructor = true;
                    scoutTroop.Members[1].stage = 5;
                    scoutTroop.makeAdjutant(scoutTroop.Members[1]);
                    //patrol masters
                    scoutTroop.Members[2].isInstructor = true;
                    scoutTroop.Members[2].stage = 4;
                    scoutTroop.Members[3].isInstructor = true;
                    scoutTroop.Members[3].stage = 4;
                    scoutTroop.addNewPatrol("Rosomaki");
                    scoutTroop.addNewPatrol("Śnieżnobiałe Wilki");
                    scoutTroop.makeMaster(scoutTroop.Members[2], scoutTroop.Patrols[0]);
                    scoutTroop.makeMaster(scoutTroop.Members[3], scoutTroop.Patrols[1]);
                    //patrol helpers
                    scoutTroop.Members[4].isInstructor = true;
                    scoutTroop.Members[4].stage = 3;
                    scoutTroop.Members[5].isInstructor = true;
                    scoutTroop.Members[5].stage = 3;
                    scoutTroop.makeHelper(scoutTroop.Members[4], scoutTroop.Patrols[0]);
                    scoutTroop.makeHelper(scoutTroop.Members[5], scoutTroop.Patrols[1]);
                    break;
                case 1:
                    if (scoutTroop.isMaleTeam)
                        message = "Jednostka ma drużynowego (Instruktor Starszy) i dwóch zastępowych (Instruktor).";
                    else
                        message = "Jednostka ma drużynową (Instruktor Starszy) i dwie zastępowe (Instruktor).";
                    //boss
                    scoutTroop.addScout(1);
                    scoutTroop.Members[0].name = scoutTroop.boss;
                    scoutTroop.makeBoss(scoutTroop.Members[0]);
                    //another scouts
                    scoutTroop.addScout(2);
                    //patrol masters
                    scoutTroop.Members[1].isInstructor = true;
                    scoutTroop.Members[1].stage = 4;
                    scoutTroop.Members[2].isInstructor = true;
                    scoutTroop.Members[2].stage = 4;
                    scoutTroop.addNewPatrol("Rosomaki");
                    scoutTroop.addNewPatrol("Śnieżnobiałe Wilki");
                    scoutTroop.makeMaster(scoutTroop.Members[1], scoutTroop.Patrols[0]);
                    scoutTroop.makeMaster(scoutTroop.Members[2], scoutTroop.Patrols[1]);
                    break;
                default:
                    if (scoutTroop.isMaleTeam)
                        message = "Jednostka ma drużynowego (Instruktor Starszy) i przybocznego (Instruktor).";
                    else
                        message = "Jednostka ma drużynową (Instruktor Starszy) i przyboczną (Instruktor).";
                    //boss
                    scoutTroop.addScout(1);
                    scoutTroop.Members[0].name = scoutTroop.boss;
                    scoutTroop.makeBoss(scoutTroop.Members[0]);
                    //another scouts
                    scoutTroop.addScout(1);
                    //adjutant
                    scoutTroop.Members[1].isInstructor = true;
                    scoutTroop.Members[1].stage = 4;
                    scoutTroop.makeAdjutant(scoutTroop.Members[1]);
                    break;
            }

            scoutTroop.countPoints();
            return message;
        }

        /// <summary>
        /// Generate random header
        /// </summary>
        public String randomAdage()
        {
            Random rnd = new Random();
            int index = rnd.Next(adage.Length);
            return adage[index];
        }

    }
}
