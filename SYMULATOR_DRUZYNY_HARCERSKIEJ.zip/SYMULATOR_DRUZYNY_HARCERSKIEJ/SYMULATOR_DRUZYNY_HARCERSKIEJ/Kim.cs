﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public class Kim
    {
        string name;
        public double age;
        public bool isStarted = false;
        public bool isEntryAllowed = false;
        public List<Scout> Students = new List<Scout>();

        public Kim(string name)
        {
            this.name = name;
        }

        /// <summary>
        /// Add new scout to this course
        /// </summary>
        public bool addStudent(Scout s)
        {
            if (isEntryAllowed && age == 0 && !Students.Contains(s))
            {
                Students.Add(s);

                if (name == "PZ")
                {
                      s.isOnPZ = true;
                      s.achivement[1, 2] = true;
                }
                else if (name == "PP")
                {
                      s.isOnPP = true;
                      s.achivement[2, 3] = true;
                }
                else if (name == "ZS")
                {
                      s.isOnZS = true;
                      s.achivement[1, 3] = true;
                }

                return true;
            }
            return false;
        }

        /// <summary>
        /// Ends course
        /// </summary>
        public void end()
        {
            if (name == "PZ")
            {
                foreach (Scout s in Students)
                {
                    s.isOnPZ = false;
                    s.certificatePZ = true;
                    s.achivement[2, 2] = true;
                }
            }
            else if (name == "PP")
            {
                foreach (Scout s in Students)
                {
                    s.isOnPP = false;
                    s.certificatePP = true;
                    s.achivement[3, 2] = true;
                }
            }
            else
            {
                foreach (Scout s in Students)
                {
                    s.isOnZS = false;
                    s.certificateZS = true;
                    s.achivement[2, 1] = true;
                }
            }

            Students.Clear();
            isStarted = false;
            isEntryAllowed = false;
            age = 0;
        }

        /// <summary>
        /// Add age to this course
        /// </summary>
        public bool addAge()
        {
            if (isStarted)
            {
                age += 0.5;

                if (name == "PZ")
                {
                    foreach (Scout s in Students)
                    {
                        s.howLongPZ += 0.5;
                    }
                }
                else if (name == "PP")
                {
                    foreach (Scout s in Students)
                    {
                        s.howLongPP += 0.5;
                    }
                }
                else
                {
                    foreach (Scout s in Students)
                    {
                        s.howLongZS += 0.5;
                    }
                }

                if (age >= 1)
                    end();

                return true;
            }
            return false;
        }

        /// <summary>
        /// Starts new course
        /// </summary>
        public bool start()
        {
            if (!isStarted)
            {
                age = 0;
                isStarted = true;

                if (name == "PZ")
                {
                    foreach (Scout s in Students)
                    {
                        s.isOnPZ = true;
                        s.achivement[1, 2] = true;
                    }
                }
                else if (name == "PP")
                {
                    foreach (Scout s in Students)
                    {
                        s.isOnPP = true;
                        s.achivement[2, 3] = true;
                    }
                }
                else if (name == "ZS")
                {
                    foreach (Scout s in Students)
                    {
                        s.isOnZS = true;
                        s.achivement[1, 3] = true;
                    }
                }

                return true;
            }
            return false;
        }

    }

    
}
