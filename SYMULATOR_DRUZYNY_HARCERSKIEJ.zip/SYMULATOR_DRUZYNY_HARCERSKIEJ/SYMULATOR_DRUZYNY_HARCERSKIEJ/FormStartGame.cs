﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SYMULATOR_DRUZYNY_HARCERSKIEJ
{
    public partial class FormStartGame : Form
    {
        Game game;
        public FormStartGame(Game game)
        {
            InitializeComponent();
            this.game = game;
            this.Text = game.randomAdage();
        }

        private void FormStartGame_Load(object sender, EventArgs e)
        {

        }

        //Updates colors in comboBoxes
        private void colorsUpdate()
        {
            button1.BackColor = colorDialog1.Color;
            button2.BackColor = colorDialog2.Color;

            if (comboLeftHigh.SelectedIndex == 1) comboLeftHigh.BackColor = colorDialog2.Color;
            else comboLeftHigh.BackColor = colorDialog1.Color;
       
            if (comboRightHigh.SelectedIndex == 1) comboRightHigh.BackColor = colorDialog2.Color;
            else comboRightHigh.BackColor = colorDialog1.Color;
       
            if (comboLeftMiddle.SelectedIndex == 0) comboLeftMiddle.BackColor = colorDialog1.Color;
            else comboLeftMiddle.BackColor = colorDialog2.Color;
       
            if (comboRightMiddle.SelectedIndex == 0) comboRightMiddle.BackColor = colorDialog1.Color;
            else comboRightMiddle.BackColor = colorDialog2.Color;
       
            if (comboLeftDown.SelectedIndex == 1) comboLeftDown.BackColor = colorDialog2.Color;
            else comboLeftDown.BackColor = colorDialog1.Color;
       
            if (comboRightDown.SelectedIndex == 1) comboRightDown.BackColor = colorDialog2.Color;
            else comboRightDown.BackColor = colorDialog1.Color;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void Floor_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button3_MouseEnter(object sender, EventArgs e)
        {
            buttonStworz.BackColor = Color.FromArgb(194, 210, 242);
        }

        private void buttonStworz_MouseLeave(object sender, EventArgs e)
        {
            buttonStworz.BackColor = Color.FromArgb(81, 118, 166);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            colorsUpdate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            colorDialog2.ShowDialog();
            colorsUpdate();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
                labelBoss.Text = "Drużynowy";
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                labelBoss.Text = "Drużynowa";
        }

        private void buttonStworz_Click(object sender, EventArgs e)
        {
            game.scoutTroop.name = textBoxName.Text;
            game.scoutTroop.nameNum = numericNum.Value;
            game.scoutTroop.isMaleTeam = !radioButton1.Checked;
            game.scoutTroop.boss = textBoxBoss.Text;

            if (comboLeftHigh.SelectedIndex == 1) game.scoutTroop.color[0] = colorDialog2.Color;
            else game.scoutTroop.color[0] = colorDialog1.Color;

            if (comboRightHigh.SelectedIndex == 1) game.scoutTroop.color[1] = colorDialog2.Color;
            else game.scoutTroop.color[1] = colorDialog1.Color;

            if (comboLeftMiddle.SelectedIndex == 0) game.scoutTroop.color[2] = colorDialog1.Color;
            else game.scoutTroop.color[2] = colorDialog2.Color;

            if (comboRightMiddle.SelectedIndex == 0) game.scoutTroop.color[3] = colorDialog1.Color;
            else game.scoutTroop.color[3] = colorDialog2.Color;

            if (comboLeftDown.SelectedIndex == 1) game.scoutTroop.color[4] = colorDialog2.Color;
            else game.scoutTroop.color[4] = colorDialog1.Color;

            if (comboRightDown.SelectedIndex == 1) game.scoutTroop.color[5] = colorDialog2.Color;
            else game.scoutTroop.color[5] = colorDialog1.Color;

            game.isStarted = true;
            this.DialogResult = DialogResult.OK;
       
        }

        private void comboLeftHigh_SelectedIndexChanged(object sender, EventArgs e)
        {
            colorsUpdate();
        }

        private void comboRightHigh_SelectedIndexChanged(object sender, EventArgs e)
        {
            colorsUpdate();
        }

        private void comboLeftMiddle_SelectedIndexChanged(object sender, EventArgs e)
        {
            colorsUpdate();
        }

        private void comboRightMiddle_SelectedIndexChanged(object sender, EventArgs e)
        {
            colorsUpdate();
        }

        private void comboLeftDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            colorsUpdate();
        }

        private void comboRightDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            colorsUpdate();
        }
    }
}
